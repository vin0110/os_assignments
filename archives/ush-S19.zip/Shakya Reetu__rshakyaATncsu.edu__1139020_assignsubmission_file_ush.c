/**
 *  Filename: ush.c
 *  Description: ush - the micro (mu) shell command interpreter
 *  Author: Reetu Shakya
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <sys/resource.h>
#include "parse.h"

#define BUILTIN_LENGTH 12
#define PATH_BUFF 4096
#define HOST_BUFF 1024

int fds[2];
int oldfds[2];
extern char **environ;
int isInteractive;
int oldIn, oldOut, oldErr;
int input_fd, output_fd, err_fd;


char *builtinCmd[] = {
	"bg", "cd", "fg", "echo", "jobs", "kill",
	"logout", "nice", "pwd", "setenv", "unsetenv", "where"};

int builtinCd(Cmd c);
int builtinEcho(Cmd c);
int builtinLogout(Cmd c);
int builtinNice(Cmd c);
int builtinPwd();
int builtinSetenv(Cmd c);
int builtinUnsetenv(Cmd c);
int builtinWhere(Cmd c);

int isBuiltinCmd(char *cmd)
{
	int builtinIndex = 0;
	//int length = sizeof(builtinCmd)/sizeof(builtinCmd[0]);
	for( int i = 0; i < BUILTIN_LENGTH; i++ ) {
		if ( strcmp(cmd, builtinCmd[i]) == 0 ) {
			return builtinIndex = i;
		}
	}
	return -1;
}

int execBuiltin(int index, Cmd c) {
	//bg, fg, jobs, kill commands
	if( index == 0 || index == 2 || index == 4 || index == 5 ) {
		printf("bg, fg, jobs, kill not handled.\n");
		return 0;
	}
	else if(index == 1) { //cd
	    builtinCd(c);
	}
	else if(index == 3) {  //echo
	    builtinEcho(c);
	}
	else if(index == 6) { //logout
	    builtinLogout(c);
	}
	else if(index == 7) { //nice
		builtinNice(c);
	}
	else if(index == 8) { //pwd
		builtinPwd();
	}
	else if(index == 9) { //setenv
		builtinSetenv(c);
	}
	else if(index == 10) { //unsetenv
		builtinUnsetenv(c);
	}
	else if(index == 11 ) { //where
	    builtinWhere(c);
	}
}

int builtinCd(Cmd c)
{
	int status = 0;
	if (c->nargs < 2) {  //change to home directory
	    char *home;
		home = getenv("HOME");
		status = chdir(home);
	}
	else {
	    status = chdir(c->args[1]);
	}
	
	if (status < 0) {
		perror("cd:");
		return -1;
	}
	return 0;
}

int builtinNice(Cmd c)
{
	int which = PRIO_PROCESS;
	pid_t pid;
	int priority;
	int ret = 0;
	int numOfVar;

	pid = getpid();
	
	if ( c->nargs == 1 ) {  //nice with no number and command
	    priority = 4;
	    ret = setpriority(which, pid, priority);
		return ret;
	}
	else if (c->nargs == 2 || c->nargs == 3) {
		numOfVar = sscanf(c->args[1], "%d", &priority);
		// nice [[+/-]number]
		if (  c->nargs == 2 && numOfVar == 1 ) {
			ret = setpriority(which, pid, priority);
			return ret;
		}
		else { //nice [[+/-]number] [command]
		    pid = fork();
			if (pid < 0) {
				perror("Error nice: fork");
				return -1;
			}
			
			if (pid == 0) {
				if ( numOfVar == 1 ) {
					ret = setpriority(which, pid, priority);
					execvp(c->args[2], &c->args[2]);
				} else {  
					ret = setpriority(which, pid, 4);
					execvp(c->args[1], &c->args[1]);
				}
			}
			else {
				ret = setpriority(which, pid, priority);
				wait(NULL);
				if (ret > 0) {
					return 0;
				} else {
					return -1;
				}
			}
			
		}
		if ( ret < 0) {
			return -1;
		}
		
	}
	return ret;
}


int builtinWhere(Cmd c)
{
	if (c->nargs < 2) {
		return -1;
	}
	
	if (isBuiltinCmd(c->args[1]) != -1) {
		printf("%s: shell built-in command.\n", c->args[1]);
	}
	
    char path[PATH_BUFF];
	char command_path[PATH_BUFF];
	char *p1 =  getenv("PATH");
	strcpy(path, p1);
	char *token = strtok(path, ":");
	while(token != NULL ) {
		sprintf(command_path, "%s/%s", token, c->args[1]);
		token = strtok(NULL, ":");
		if( (access(command_path, F_OK) == 0)
			&& (access(command_path, X_OK))) {
			printf("%s\n", command_path);
		}
	}
	return 0;
}

int builtinEcho(Cmd c)
{
	if (c->nargs == 1) {
		printf("\n");
		return 0;
	}
	else {
	    for (int i = 1; i < c->nargs; i++) {
		    printf("%s", c->args[i]);
		    if (i == (c->nargs - 1)) {
			    printf("\n");
		    } else {
				printf(" ");
			}
	    }
	    return 0;
	}
}

int builtinLogout(Cmd c)
{ 
    exit(0); 
}

int builtinPwd()
{
    char curr_dir[PATH_BUFF];	
	if (getcwd(curr_dir, sizeof(curr_dir)) != NULL ) {
		printf("%s\n", curr_dir);
		return 0;
	}
	return -1;
}

int builtinSetenv(Cmd c)
{
	//code from https://stackoverflow.com/questions/2085302/printing-all-environment-variables-in-c-c
	//begin
	if (c->nargs == 1) { // if no arguments, print all env variables
		int i = 1;
		char *s = *environ;
		for (; s; i++) {
			printf("%s\n", s);
			s = *(environ + i);
		}
		return 0;
	}
	//end
	else if(c->nargs == 2) { //no word
		return setenv(c->args[1], "", 1);
	}
	else if(c->nargs == 3) {
		return setenv(c->args[1], c->args[2], 1);
	}
}

int builtinUnsetenv(Cmd c)
{
	if (c->nargs < 2) {
		return -1;
	}
	
	int ret;
	if(c->args[1] != NULL) {
		ret = unsetenv(c->args[1]);
		if (ret < 0) {
			perror("Error: unsetenv: ");
			return -1;
		}
		return 0;
	}
}

int numOfLines(char *filename)
{
	//reference: https://www.includehelp.com/c-programs/find-number-of-lines-in-a-file.aspx
	FILE *fp;
	char ch;
	int linesCount = 0;
	
	//open file in read more
	fp = fopen(filename,"r");

	//read character by character and check for new line	
	while((ch=fgetc(fp))!=EOF)
	{
		if(ch=='\n')
			linesCount++;
	}
	//close the file
	fclose(fp);
	return linesCount;
}

static void execCmd(Cmd c)
{
  int i;

  if ( c ) {
	// this driver understands one command
    if ( !strcmp(c->args[0], "end") ) {
      exit(0);
	}
		
		
	// execute logout 
		int builtinIndex = isBuiltinCmd(c->args[0]);
		if ( builtinIndex != -1 &&  builtinIndex == 6 ) {
			execBuiltin(builtinIndex, c);
            //printf("builtin1");			
		}
	
	//pipes
    if ( c->out == Tpipe || c->out == TpipeErr ) {
		pipe(fds);	
	}
	
	pid_t child = fork();
	
	if (child < 0) {
		fprintf(stderr, "Cannot create child process\n");
		exit(EXIT_FAILURE);
	} 
	else if ( child == 0 ) {
		
		// handle input redirect
		if ( c->in == Tin ) {
			input_fd = open( c->infile, O_RDONLY);
			dup2(input_fd, STDIN_FILENO);
			close(input_fd);
		}
		
		// handle output, error redirect
		if ( c->out == Tout || c->out == ToutErr ) {
			output_fd = open( c->outfile, O_WRONLY | O_CREAT | O_TRUNC, 0666);
			dup2( output_fd, STDOUT_FILENO );
			if ( c->out == ToutErr ) {
				dup2(output_fd, STDERR_FILENO);
			}
			close(output_fd);
		}
		
		// handle append, error to file redirect
		if ( c->out == Tapp || c->out == TappErr ) {
			output_fd = open( c->outfile, O_WRONLY | O_CREAT | O_APPEND, 0666);
			dup2( output_fd, STDOUT_FILENO );
			if ( c->out == TappErr ) {
				dup2(output_fd, STDERR_FILENO);
			}
			close(output_fd);
		}
		
		// handle input pipes, pipeErr redirects
		if ( c->in == Tpipe || c->in == TpipeErr ) {
			dup2(oldfds[0], STDIN_FILENO);
			close(oldfds[0]);
		}
		
		// handle output pipes, pipeErr redirects
		if ( c->out == Tpipe || c->out == TpipeErr) {
			dup2(fds[1], STDOUT_FILENO);
			if( c->out == TpipeErr ) {
				dup2( fds[1], STDERR_FILENO);
			}
			close(fds[1]);
		}
		
		if ( c->in == Tpipe || c->in == TpipeErr ) {
			close(oldfds[1]);
		}
		
		if ( c->out == Tpipe || c->out == TpipeErr ) {
			close(fds[0]);
		}
		
		// execute builtin commands
		int builtinIndex = isBuiltinCmd(c->args[0]);
		if ( builtinIndex != -1 ) {
			execBuiltin(builtinIndex, c);
            //printf("builtin pipe");			
			exit(0);
		}
		
		execvp( c->args[0], c->args);
		
		switch (errno) {
			case EACCES:
			  fprintf(stderr, "permission denied\n");
			  break;
			case ENOENT:
			  fprintf(stderr, "command not found\n");
			  break;
			default:
			  break;
		}
		exit(EXIT_FAILURE);
	} else {
	  wait(NULL);
	  if (c->in == Tpipe) {
	    close(oldfds[0]);
	  }
	  if (c->out == Tpipe) {
		oldfds[0] = fds[0];
		oldfds[1] = fds[1];
		close(fds[1]);
	  }	
	}
  } 
}

static void execPipe(Pipe p)
{
  int i = 0;
  Cmd c;

  if ( p == NULL )
    return;

 // printf("Begin pipe%s\n", p->type == Pout ? "" : " Error");
  for ( c = p->head; c != NULL; c = c->next ) {
   // printf("  Cmd #%d: ", ++i);
    execCmd(c);
  }
 // printf("End pipe\n");
  execPipe(p->next);
}


int main(int argc, char *argv[])
{
  Pipe p;
  char host[HOST_BUFF];
  host[HOST_BUFF - 1] = '\0';
  gethostname(host, sizeof(host)); // for the prompt
  isInteractive = isatty(STDIN_FILENO); // check if stdin is in terminal
  
  setbuf(stdin, NULL);
  setbuf(stdout, NULL);
  setbuf(stderr, NULL);
  
  //handle config file ./ushrc
  char ushrc_path[HOST_BUFF];
  int config_fd;
  int line_count;
  sprintf(ushrc_path, "%s/.ushrc", getenv("HOME"));
 
  if ((access(ushrc_path, F_OK | R_OK)) == 0) {
	  //printf(".ushrc");
	  line_count = numOfLines(ushrc_path);
      config_fd = open(ushrc_path, O_RDONLY);
	  oldIn = dup(STDIN_FILENO);  // save the old stdin fd
	  fcntl(oldIn, FD_CLOEXEC);
	  dup2(config_fd, STDIN_FILENO);
	  close(config_fd);
	  
	  while(line_count > 0) {
		  p = parse();
		  execPipe(p);
		  freePipe(p);
		  line_count--;
	  }
	  dup2(oldIn, STDIN_FILENO);
	  close(oldIn);
  } 
  //else {
	  // printf("%s\n", ushrc_path);
  //}
  
  //handle shell
  while ( 1 ) {
	  if (isInteractive == 1) {
		  printf("%s%% ", host);
	  }
	  p = parse();
	  execPipe(p);
	  freePipe(p);
  }
}
