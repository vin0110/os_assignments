#include <glob.h>

#define VERBOSE 0
#define INPUT_BUFFER_SIZE 10000
#define LINE_BUFFER_SIZE 1024
#define READ 4
#define WRITE 2
#define EXEC 1
#define ACCESS_ALLOWED 1
#define ACCESS_DENIED -1

char* ptrace_read_string(int pid, char* addr);

int lookup(char* filename, glob_t *glob_results, int* permissions);

int load_config(char* config_file, glob_t *glob_results, int* permissions);

int handle_arguments(int argc, char** argv, char** config_file, int* command_index);

char* to_absolute_cwd(char* input);
