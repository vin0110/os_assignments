// Functions in this file deal with system calls

#include "syscalls.h"
#include "fend.h"

#include <glob.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ptrace.h>
#include <sys/user.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <linux/limits.h>

char* ptrace_read_string(int pid, char* addr){
        char string_buffer[INPUT_BUFFER_SIZE] = {0};
        char* retval;
        int i;
        char character;
        for(i = 0; i < INPUT_BUFFER_SIZE; i++){
                character = ptrace(PTRACE_PEEKDATA, pid, addr+i, 0);
                if(character == 0){
                        break;
                }
                string_buffer[i] = character;
        }
        retval = calloc(i+1, sizeof(char));
        strcpy(retval, string_buffer);
        return retval;
}

// execute permission on all prefix directories
int check_path(char* pathname, glob_t *glob_results, int* permissions){
	if(VERBOSE){
		puts("RESOLVING PATH");
	}
	char prefix[PATH_MAX] = {0};
	int index = 0;
	int access =ACCESS_DENIED;
	int decision;
	// make it check the root directory
	prefix[0] = pathname[0];
	while(pathname[index] != '\0'){
		while(	(pathname[index] != '/') && 
			(pathname[index] != '\0')){
			prefix[index] = pathname[index];
			index++;
		}
		if(pathname[index] != '/'){
			break;
		}
		access = lookup(prefix, glob_results, permissions);
		decision = determine_access(EXEC, access);
		if(decision == ACCESS_DENIED){
			if(VERBOSE){
				printf("Recursive resolver: access denied for prefix %s\n", prefix);
			}
			return ACCESS_DENIED;
		}
		prefix[index] = pathname[index];
		index++;	
	}
	return ACCESS_ALLOWED;
}

int determine_access(int requested_access, int config_access){
        if((config_access == -1) || (requested_access == 0)){
                return ACCESS_ALLOWED;
        }
	if((requested_access & READ) == READ){
		if((config_access & READ) != READ){
			return ACCESS_DENIED;
		}
	}
	if((requested_access & WRITE) == WRITE){
		if((config_access & WRITE) != WRITE){
			return ACCESS_DENIED;
		}
	}
	if((requested_access & EXEC) == EXEC){
		if((config_access & EXEC) != EXEC){
			return ACCESS_DENIED;
		}
	}
        return ACCESS_ALLOWED;
}


/* ipython metaprogramming
 * syscalls = !cat syscalls.txt | cut -d ' ' -f 2
 * for i in syscalls: print('\t\tcase {} :\n\t\t\tif(VERBOSE){{\n\t\t\t\tputs("{}");\n\t\t\t}}\n\t\t\tbreak;'.format(i,i))
 */
int handle_syscall(int pid, void* regs, glob_t *glob_results, int *permissions){
	long syscall 	= ((struct user_regs_struct*)regs)->orig_rax;
	long rdi 	= ((struct user_regs_struct*)regs)->rdi;
	long rsi 	= ((struct user_regs_struct*)regs)->rsi;
	long rdx 	= ((struct user_regs_struct*)regs)->rdx;
	// long r10 	= ((struct user_regs_struct*)regs)->r10;
	// long r8  	= ((struct user_regs_struct*)regs)->r8;
	// long r9  	= ((struct user_regs_struct*)regs)->r9;
        char* filename;
	char* filename2	= NULL;
	long fn_reg = 0;
        int config_access;
	char syscall_name[50] = {0};
	int requested_access = 0;
	int path_access;
	int decision;
        switch(syscall){
                case SYS_OPEN :
			strcpy(syscall_name, "SYS_OPEN");
			fn_reg = rdi;
			if(((int)rsi & O_RDONLY) == O_RDONLY){
				requested_access = READ;
			}
			if(((int)rsi & O_WRONLY) == O_WRONLY){
				requested_access = WRITE;
			}
			if(((int)rsi & O_RDWR) == O_RDWR){
				requested_access = WRITE | READ;
			}
                        break;
                case SYS_ACCESS :
			strcpy(syscall_name, "SYS_ACCESS");
			fn_reg = rdi;
			if((int)rsi == F_OK){
				requested_access = 0;
			}
			else{
				if(((int)rsi & R_OK) == R_OK){
					requested_access = requested_access | READ;
				}
				if(((int)rsi & W_OK) == W_OK){
					requested_access = requested_access | WRITE;
				}
				if(((int)rsi & X_OK) == X_OK){
					requested_access = requested_access | EXEC;
				}
			}
                        break;
                case SYS_OPENAT :
			strcpy(syscall_name, "SYS_OPENAT");
			fn_reg = rsi;
			requested_access = READ;
                        if(((int)rdx & O_WRONLY) != 0){
				puts("Write requested");
                                requested_access = WRITE;
                        }
                        if(((int)rdx & O_RDWR) != 0){
				puts("W/R requested");
                                requested_access = WRITE | READ;
                        }
                        break;
                default:
			if(VERBOSE){
				printf("[-] Syscall %li not caught\n", syscall);			
			}
                        return ACCESS_ALLOWED;
        }
	filename = ptrace_read_string(pid, (char*) fn_reg);
	filename = to_absolute_cwd(filename);
	config_access = lookup(filename, glob_results, permissions);
	decision = determine_access(requested_access, config_access);
	path_access = check_path(filename, glob_results, permissions);
	if(path_access == ACCESS_DENIED){
		if(VERBOSE){
			puts("Prefix directory had no EXEC permission");
		}
		decision = ACCESS_DENIED;
	}
	if(VERBOSE){
		printf("[+] SYSCALL %li -> %s\n", syscall, syscall_name);
		printf("\t[+] Filename: %s\n", filename);
		if(filename2 != NULL){
			printf("\t[+] Filename2: %s\n", filename2);
		}
		printf("\t[+] Requested Access: %d\n", requested_access);
		printf("\t[+] Config Access: %d\n", config_access);
		if(decision == ACCESS_ALLOWED){
			printf("\t[+] ACCESS ALLOWED\n");
		}
		else{
			printf("\t[-] ACCESS DISALLOWED\n");
		}
	}
        return decision;
}
