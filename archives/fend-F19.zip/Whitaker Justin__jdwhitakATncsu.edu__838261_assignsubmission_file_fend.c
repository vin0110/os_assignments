/* 	fend - A simple sandbox.
 *
 *  	Written by Justin Whitaker
 *  	Copyright Dr. Vincent Freeh, NC State University
 *  	January 8 2018
 *
 *  	syscalls enumerated through the following shell commands:
 *
 *  	jdwhitak@ubuntu:~$ man 2 syscalls > syscalls.txt
 *  	jdwhitak@ubuntu:~$ vim syscalls.txt # to remove lines outside of the table
 *  	jdwhitak@ubuntu:~$ cat syscalls.txt | cut -d ' ' -f 8 > tmp.txt; mv tmp.txt syscalls.txt
 *  	jdwhitak@ubuntu:~$ cat syscalls.txt | grep -e "^[^\(]*" -o > tmp.txt; mv tmp.txt syscalls.txt
 *  	jdwhitak@ubuntu:~$ cat syscalls.txt | xargs man 2 | grep "const char \*pathname\|int fd\|int dirfd" | cut -d ' ' -f 9 | cut -d '(' -f 1 > file_syscalls.txt
 *  	jdwhitak@ubuntu:~$ cat file_syscalls.txt | grep -v "^$" | sort -u > syscalls.txt; rm file_syscalls.txt
 *
*/

#define _DEFAULT_SOURCE

#include "fend.h"
#include "syscalls.h"
#include <signal.h>
#include <assert.h>
#include <glob.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ptrace.h>
#include <sys/user.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <limits.h>
#include <linux/limits.h>

char* usage = "\nUsage:\n\tfend [-c config] <command [args ...]>\n\nwhere config is an optional configuration file and command is the program the is being sandboxed.\nIf the config file option is not given, the program will look for a file named .fendrc first in the current working directory and second in the user's home directory.\nIf none are found, fend will exit with the message \"Must provide a config file.\"\n";

/*
 * // uses example of how to capture out from exec from https://stackoverflow.com/questions/7292642/grabbing-output-from-exec
// readlink /proc/self/fd/<dirfd>
char* dirfd_to_dirname(int dirfd)
	char* readlink_arg = calloc(LINE_BUFFER_SIZE, sizeof(char));
	sprintf(readlink_arg, "/proc/self/fd/%d", dirfd);
	execlp("readlink", readlink_arg);	
}
*/

char* to_absolute_root(char* input){
        // if not absolute already
        if((input[0] != '/') && (input[0] != '~')){
                char *output = calloc(PATH_MAX, sizeof(char));
		char *tmp = calloc(PATH_MAX, sizeof(char));
                strcat(tmp, "/");
                strcat(tmp, input);
		realpath(tmp, output);
		free(tmp);
                return output;
        }
        else{
                return input;
        }
}

char* to_absolute_cwd(char* input){
        // if not absolute already
        if(input[0] != '/') {
		char *output = calloc(PATH_MAX, sizeof(char));
                char *tmp = calloc(PATH_MAX, sizeof(char));
		getcwd(tmp, sizeof(char) * PATH_MAX);
                strcat(tmp, "/");
		if(input[0] == '~'){
			strcat(tmp, input+1);
		}
		else{
			strcat(tmp, input);
		}
                realpath(tmp, output);
                free(tmp);
		return output;
        }
        else{
		return input;
        }
}


// return -1 if no match
int lookup(char* filename, glob_t *glob_results, int* permissions){
	int index = glob_results->gl_pathc - 1;
	char *cwd = calloc(PATH_MAX, sizeof(char));
	filename = to_absolute_cwd(filename);
	while(index >= 0){
		if(strcmp((glob_results->gl_pathv)[index], filename) == 0){
			if(VERBOSE){
				printf("[+] Matched %s at index %d with permissions %i\n", filename, index, permissions[index]);
			}
			free(cwd);
			return permissions[index];
		}
		index--;
	}
	if(VERBOSE){
		printf("[-] Filename %s not matched\n", filename);
	}
	free(cwd);
	return -1;
}

/* Either
 * 1) load from the command line
 * 2) load .fendrc from cwd or
 * 3) load .fendrc from home directory
 */
int load_config(char* config_file, glob_t *glob_results, int* permissions){
	int permissions_size = INPUT_BUFFER_SIZE;
	FILE* file;
	char INPUT_BUFFER[INPUT_BUFFER_SIZE] = {0};
	char LINE_BUFFER[LINE_BUFFER_SIZE] = {0};
	char FILENAME_BUFFER[LINE_BUFFER_SIZE] = {0};
	char perm_r = 0;
	char perm_w = 0;
	char perm_x = 0;
	int perm_index = 0;
	int bitmask = 0;
	int prior_glob_matches;
	int current_glob_matches;
	// https://stackoverflow.com/questions/298510/how-to-get-the-current-directory-in-a-c-program
	if(VERBOSE){
		printf("[+] Reading configuration file \"%s\"\n", config_file);
	}
	if ((file = fopen(config_file, "r"))){
		fread(INPUT_BUFFER, sizeof(char), INPUT_BUFFER_SIZE, file);
		fclose(file);
		glob("", GLOB_MARK, NULL, glob_results);
		int index = 0;
		int line_index = 0;
		// line by line, read filenames and permissions
		while(INPUT_BUFFER[index] != '\0'){
			// copy line from input buffer to line buffer
			while((index < INPUT_BUFFER_SIZE) && 
					(line_index < LINE_BUFFER_SIZE) &&
					(INPUT_BUFFER[index] != '\0') &&
					(INPUT_BUFFER[index] != '\n')){
				LINE_BUFFER[line_index] = INPUT_BUFFER[index];
				line_index++;
				index++;
			}
			LINE_BUFFER[line_index] = '\0';
			// scan in values
			memset(FILENAME_BUFFER, '\0', LINE_BUFFER_SIZE);
			perm_r = 0;
			perm_w = 0;
			perm_x = 0;
			bitmask = 0;
			sscanf(LINE_BUFFER, "%c%c%c %s",
					&perm_r, &perm_w, &perm_x, FILENAME_BUFFER);
			memset(LINE_BUFFER, '\0', LINE_BUFFER_SIZE);
			line_index = 0;
			index++;
			char* filename;
			if(FILENAME_BUFFER[0] == '*'){
				filename = to_absolute_root(FILENAME_BUFFER);
			}
			else{
				filename = to_absolute_cwd(FILENAME_BUFFER);
			}
			glob(filename, GLOB_TILDE|GLOB_APPEND, NULL, glob_results);
			current_glob_matches = glob_results->gl_pathc - prior_glob_matches;
			if(perm_r == '1'){
				bitmask = bitmask | READ;
			}	
			if(perm_w == '1'){
				bitmask = bitmask | WRITE;
			}	
			if(perm_x == '1'){
				bitmask = bitmask | EXEC;
			}	
			if(perm_index+(glob_results->gl_pathc) >= permissions_size){
				permissions_size *= 2;
				permissions = realloc(permissions, sizeof(int)*permissions_size);
			}
			memset(permissions+perm_index, bitmask, current_glob_matches);
			prior_glob_matches = glob_results->gl_pathc;
			perm_index += current_glob_matches;
		}
		return 0;
	}
	else{
		if(VERBOSE){
			perror("[-] Failed to read configuration file.\n");
		}
		exit(-1);
	}
}

int handle_arguments(int argc, char** argv, char** config_file, int* command_index){
	// not enough arguments
	if (argc < 2){
		puts(usage);
		exit(-1);
	}
	// config option
	if (strncmp(argv[1], "-c", 2) == 0){
		// not enough arguments
		if (argc < 4){
			puts(usage);
			exit(-1);
		}
		// well specified config
		else{
			*config_file = argv[2];
			*command_index = 3;
		}
	}
	// no config option
	else {
		FILE *file;
		// look in current working directory for .fendrc
		// found file
		if ((file = fopen(".fendrc", "r"))){
			fclose(file);
			*config_file = ".fendrc";
			*command_index = 1;
		}
		// did not find file in cwd
		// look in home directory for .fendrc
		else{
			char* home_directory;
			char* full_home_fname = calloc(sizeof(char), 100);
			home_directory = getenv("HOME");
			strcat(full_home_fname, home_directory);
			strcat(full_home_fname, "/.fendrc");
			if ((file = fopen(full_home_fname, "r"))){
				fclose(file);
				*config_file = full_home_fname;
				*command_index = 1;
			}
			else{
				if(VERBOSE){
					perror("[-] Did not find .fendrc in current working directory or user's home directory.\n");
				}
				puts(usage);
				exit(-1);
			}
		}
	}
	return 0;
}

int main(int argc, char** argv){
	char* config_file;
	int command_index;
	int pid;
	glob_t glob_results; 
	int* permissions = calloc(INPUT_BUFFER_SIZE, sizeof(int));

	handle_arguments(argc, argv, &config_file, &command_index);
	load_config(config_file, &glob_results, permissions);

	if(VERBOSE){
		puts("[+] Matches:");
		for(int i = 0; i < (glob_results.gl_pathc); i++){
			printf("\t%d\t%s\n", permissions[i], (glob_results.gl_pathv)[i]);
		}
	}

	pid = fork();
	/* The following section draws from:
	 * https://nullprogram.com/blog/2018/06/23/ 
	 * https://github.com/golang/go/issues/21428
	 * http://system.joekain.com/2015/06/08/debugger.html
	 */
	// CHILD
	if (pid == 0){
		ptrace(PT_TRACE_ME, 0, 0, 0);
		execvp(argv[command_index], &argv[command_index]); 
	}
	// PARENT
	else{
		struct user_regs_struct regs;
		int status;
		int access;
		waitpid(pid, 0, 0);
		ptrace(PTRACE_SETOPTIONS, pid, 0, PTRACE_O_TRACEFORK);
		while(1){
			// tell ptrace we want to catch the next syscall that the child makes
			status = ptrace(PTRACE_SYSCALL, pid, 0, 0);
			// wait for the syscall to be made
			status = waitpid(pid, 0, 0);
			if(status != pid){
				if(VERBOSE){
					printf("[-] Child exited with status %i\n", pid);
					perror("[-] ");
				}
				exit(0);
			}
			// Put the contents of the registers into the regs structure
			ptrace(PTRACE_GETREGS, pid, NULL, &regs);
			access = handle_syscall(pid, &regs, &glob_results, permissions);
			// let the syscall run & wait for return
			ptrace(PTRACE_SYSCALL, pid, 0, 0);
			waitpid(pid, 0, 0);
			if(access == ACCESS_DENIED){
				// Set the registers with whatever we want
				regs.rax = -EACCES;
				ptrace(PTRACE_SETREGS, pid, 0, &regs);
			}
		}
	}
	return 0;
}
