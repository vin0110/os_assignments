/**
   @file fend.c
   @author Reetu Shakya (rshakya)
   Fend � a simple sandbox using the ptrace system call.
   This sandbox guards all access to all files by a program.
   If an access is disallowed the offending system call will return the EACESS error code.
 */

#include <sys/ptrace.h>
#include <sys/user.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <string.h>
#include <errno.h>
#include <err.h>

typedef struct {
	pid_t child;
	const char *progname;
} sandbox;

void sandbox_kill( sandbox *sandbx ) {
	kill(sandbx->child, SIGKILL);
	wait(NULL);
	exit(EXIT_FAILURE);
}

void sandbox_handle_syscall(sandbox *sandbx)
{
  return;
}

//sandbox initialiazation
//(from toosh: https://github.com/t00sh/p-sandbox/blob/master/p-sandbox.c)
//begin
void sandbox_init( sandbox *sandbx, char **argv, char *config )
{
  pid_t child_pid;
  int status;
  
  child_pid = fork(); //initializing child
  
  if ( child_pid == -1 ) { //failure to create child
    err(EXIT_FAILURE, "Error on fork ");
  }
  
  if ( child_pid == 0 ) {  //child process
    status = ptrace( PTRACE_TRACEME, 0, NULL, NULL );  //trace the child process
    if ( status < 0 ) {
      err(EXIT_FAILURE, "Failed to PTRACE_TRACEME ");
    }
    
    status = execvp( argv[0], argv );
    if ( status < 0 ) {
      err(EXIT_FAILURE, "Failed to execv ");
    }
  }
  else {  //parent process
    sandbx->child = child_pid;
    sandbx->progname = argv[0];
  }
}

void sandbox_run( sandbox *sandbx )
{
  int status, pstatus, ch;
	pstatus = ptrace( PTRACE_SYSCALL, sandbx->child, NULL, NULL );
	if ( pstatus < 0 ) {
		if ( errno == ESRCH ) {
			waitpid( sandbx->child, &status, __WALL | WNOHANG );
			sandbox_kill( sandbx );
		} 
		else{
			exit( EXIT_FAILURE );
		}
	}
	wait( &status );
	if( WIFEXITED( status ) ){
		exit( EXIT_SUCCESS );
	}
	if( WIFSTOPPED( status ) ){
		sandbox_handle_syscall( sandbx );
	}
}
//end

int main( int argc, char **argv )
{
  FILE *fp;
  char config_path[1000];
  char home_config_path[1000];
  sandbox sandbx;
  
  // Invalid number of arguments
  if ( argc < 2 ) {
    errx( EXIT_FAILURE, "Error. Usage: %s [-c config] <command [args ...]>", argv[0] );
  }
  
  // Valid number of arguments
  if( strcmp( argv[1], "-c" ) == 0 ) {  //Look for config file
    if ( argc > 3 ) {  
	    if ( access( argv[2], F_OK ) == -1 ) {  //Config file doesn't exist
		    errx( EXIT_FAILURE, "Must provide a config file." );
	    }
	    strcpy( config_path, argv[2] );
 			sandbox_init( &sandbx, argv+3, config_path );
	  }
	  else {
	    errx( EXIT_FAILURE, "Error. Usage: %s [-c config] <command [args ...]>", argv[0] );
	  }
  }
  else {  // Look for a file named ".fendrc"
	  fp = fopen("./.fendrc", "r"); //current directory
	  if ( fp != NULL ) {
      strcpy( config_path, "./.fendrc" );
  	  sandbox_init( &sandbx, argv+1, config_path );
	  }
	  else {
	    strcpy( home_config_path, getenv( "HOME" ) );
	    strcat( home_config_path, "/.fendrc" );
	    fp = fopen( home_config_path, "r" ); //home directory
	    if ( fp != NULL ) {
	      strcpy( config_path, home_config_path );
		    sandbox_init( &sandbx, argv+1, config_path );
	    }
	    else {
	      errx( EXIT_FAILURE, "Must provide a config file." );
	    }
	  }
  }
  
  while(1) {
    sandbox_run( &sandbx );
  }
  
  return EXIT_SUCCESS;
}