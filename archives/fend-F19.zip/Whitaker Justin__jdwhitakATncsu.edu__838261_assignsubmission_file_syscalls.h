#include <glob.h>

// from blog.rchapman.org
#define SYS_OPEN        	2
#define SYS_STAT        	4
#define SYS_LSTAT		6
#define SYS_ACCESS      	21
#define SYS_EXECVE      	59
#define SYS_TRUNCATE    	76
#define SYS_CHDIR       	80
#define SYS_RENAME      	82
#define SYS_MKDIR       	83
#define SYS_RMDIR       	84
#define SYS_CREAT       	85
#define SYS_LINK        	86
#define SYS_UNLINK      	87
#define SYS_SYMLINK     	88
#define SYS_READLINK    	89 
#define SYS_CHMOD       	90
#define SYS_CHOWN       	92
#define SYS_LCHOWN      	94
#define SYS_UTIME		132
#define SYS_MKNOD       	133
#define SYS_STATFS      	137
#define SYS_PIVOT_ROOT  	155
#define SYS_CHROOT      	161
#define SYS_ACCT        	163
#define SYS_UMOUNT2     	166
#define SYS_SWAPON      	167
#define SYS_SWAPOFF     	168
#define SYS_QUOTACTL    	179
#define SYS_SETXATTR    	188
#define SYS_LSETXATTR   	189
#define SYS_GETXATTR    	191
#define SYS_LGETXATTR   	192
#define SYS_LISTXATTR   	194
#define SYS_LLISTXATTR  	195
#define SYS_REMOVEXATTR 	197
#define SYS_LREMOVEXATTR        198
#define SYS_FREMOVEXATTR        199
#define SYS_UTIMES		235
#define SYS_INOTIFY_ADD_WATCH   254
#define SYS_OPENAT              257
#define SYS_MKDIRAT             258
#define SYS_MKNODAT             259
#define SYS_FCHOWNAT            260
#define SYS_FUTIMESAT           261
#define SYS_NEWFSTATAT          262
#define SYS_UNLINKAT            263
#define SYS_RENAMEAT            264
#define SYS_LINKAT              265
#define SYS_SYMLINKAT           266
#define SYS_READLINKAT          267
#define SYS_FCHMODAT            268
#define SYS_FACCESSAT           269
#define SYS_UTIMENSAT           280
#define SYS_NAME_TO_HANDLE_AT   303
#define SYS_OPEN_BY_HANDLE_AT   304
#define SYS_EXECVEAT		322

char* ptrace_read_string(int pid, char* addr);

int handle_syscall(int pid, void* regs, glob_t *glob_results, int *permissions);

int determine_access(int requested_access, int config_access);
