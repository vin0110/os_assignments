/*
 ============================================================================
 Name        : fend.c
 Author      : Karan Gurnasinghani
 Version     : 1.0
 Copyright   : Your copyright notice
 Description : Operating System Project - "SANDBOX"
 ============================================================================
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ptrace.h>// for ptrace functionality
#include <sys/wait.h>//to implement wait
#include <sys/reg.h>// for the constants of reqisters
#include <sys/syscall.h>// for the number of the system calls
#include <sys/user.h>
#include <string.h>// strcmp and other functions
#include <glob.h> // for parsing the file
#include <errno.h> // for error no

#include <sys/stat.h>
#include <fcntl.h> //  for RD_ONLY

#include <pwd.h>

#include <sched.h>// for cloning the child process also
#include <fnmatch.h>

#define NO_PERMISSION 				0
#define EXEC_ONLY_PERMISSION 		1
#define WR_ONLY_PERMISSION 			10
#define WR_EXEC_PERMISSION 			11
#define RD_ONLY_PERMISSION 			100
#define RD_EXEC_PERMISSION 			101
#define RD_WR_PERMISSION 			110
#define ALL_PERMISSION 				111

#define BUFFER_MAX_SIZE 	2048
#define RD_WR_FLAG_MASK	0x0000000000000011

#define SLASH 				"/"
int childExePtr;

char finalFileLoc[2048];
#define CHILD_CLONE		0x00002000

int findPermission(char* fileToCheck, char* configFilename);

int main(int argc, char* argv[]) {
	FILE* configFile;
	char* filename;
	char currentWorkingDirConfig[2048]; // filename and path for config file / fendFile
	char* homeDirFend; // filename and path for .fendrc file in wroking dir

	pid_t child;
	int childStatus;
	struct user_regs_struct regValue;

	char tempOpenFilename[BUFFER_MAX_SIZE];
	char* tempFinalFile;
	char finalFile[BUFFER_MAX_SIZE];
	unsigned long long int tempRegAddr;
	unsigned long long int tempValue;

	int openFlags;
	int sysCallState = 0;
	int statSysCallState = 0;
	int mkdirSysCallState = 0;
	int creatSysCallState = 0;

	int readFlag; // for access
	int executeFlag;
	int writeFlag;
	int allowedPerm;

	int actualPermission;

	int countI;

	unsigned long long int childFileAddress;
	unsigned long long int childFileFlags;

	char wrongFile[1024] = "virus"; // for printing EACCES error
	char wrongdirectory[1024] = "ksg/123"; // for printing EACCES error

	char originalFile[2048];
	long long int originalFlags;
	int fileNameToChange;
	int dirNameToChange;

	int filenameSize;

	//Reference:  http://stackoverflow.com/questions/298510/how-to-get-the-current-directory-in-a-c-program

	if (getcwd(currentWorkingDirConfig, sizeof(currentWorkingDirConfig)) != NULL) {
//	   printf("Current working dir Config: %s\n", currentWorkingDirConfig);
	} else {
//	   perror("getcwd() error");
	}
	// reference: http://stackoverflow.com/questions/2910377/get-home-directory-in-linux-c
	if ((homeDirFend = getenv("HOME")) == NULL) {
		homeDirFend = getpwuid(getuid())->pw_dir;
	}
//		printf("Home working dir: %s\n", homeDirFend);

	if (argc >= 2) {
		if (((strcmp(argv[1], "-c")) == 0) && (argc > 2)) {
			filename = argv[2]; // -c flag given

			strcat(currentWorkingDirConfig, SLASH);
			strcat(currentWorkingDirConfig, filename);
//			printf("Final Config 1: %s\n", currentWorkingDirConfig);
			childExePtr = 3;
		} else if (((strcmp(argv[1], "-c")) == 0) && (argc == 2)) // searching .fendrc file
				{
			printf("Must provide a config file.\n");
			exit(-1);
		} else {

			strcat(currentWorkingDirConfig, SLASH);
			strcat(homeDirFend, SLASH);

			strcat(currentWorkingDirConfig, ".fendrc");
			strcat(homeDirFend, ".fendrc");

//			printf("Final Fend 1: %s\n", currentWorkingDirConfig);
//			printf("Final Fend 2: %s\n", homeDirFend);
			childExePtr = 1;
		}

	} else {
//		errno = EINVAL;
//		perror("EACCES");
		exit(-1);

	}

	/********* Checking whether config file is available or not****/

	if ((configFile = fopen(currentWorkingDirConfig, "r")) == NULL) {

		if (((configFile = fopen(homeDirFend, "r")) != NULL)
				&& (childExePtr == 1)) {
//			printf("\n I should not be here\n");
			// I got config FIle in home dir fend
			strcpy(finalFileLoc, homeDirFend);

			fclose(configFile);
		} else {
			errno = ENOENT;
			printf("Must provide a config file.\n");
			exit(-1);
		}

	} else {
		strcpy(finalFileLoc, currentWorkingDirConfig);
		fclose(configFile);
	}

	if (childExePtr == 3) // handling for ./fend -c config
			{
		if (argc <= 3) {
			exit(-1);
		}
	}

	/******* Starting the child process and monitoring system calls*******/

//	printf("\n Wrong File Strlen %ld",strlen(wrongFile));
	child = fork();
	//printf("\n The new CHild id is %d\n",child);
	if (child == 0) // child process
			{
		ptrace(PTRACE_TRACEME, 0, NULL, NULL); // to trace the process
		execvp(argv[childExePtr], &argv[childExePtr]);
	}

	else if (child > 0) // Parent Process
			{
		//	printf("\n The new CHild id is %d\n",child);
		while (1) {
			child = wait(&childStatus); // wait for child status
//			printf("Wait Child is %d\n",child);

			if (child == -1) {
				exit(0);
			}
			if (WIFEXITED(childStatus)) {
//				printf("\n Child Exited Properly\n");
//				exit(0);
			}

			if (WIFSIGNALED(childStatus)) {
//	            printf("Child exit due to signal %d\n", WTERMSIG(childStatus));
//	            exit(0);
			}

			ptrace(PTRACE_GETREGS, child, NULL, &regValue);

//			printf("SYstem Call %llu \n\n",regValue.orig_rax);
			switch (regValue.orig_rax) {

			case SYS_open:
			case SYS_openat:

				//				if (sysCallState == 0)// system call while entering
				//				{
				//					sysCallState =1;
				//				}
				if (sysCallState == 0)	// system while system call returned
						//				else
						{
					sysCallState = 1;

					// Get the Name of the file along with the argumrnts

					memset(&finalFile[0], 0, BUFFER_MAX_SIZE);

					// rdi -> contains File name while open
					// rsi -> containse file name while openat

					// Flags -> rsi in case of open
					// flags -> rdx in case of openat

					if (regValue.orig_rax == SYS_open) {
						childFileAddress = regValue.rdi;
						childFileFlags = regValue.rsi;
					} else if (regValue.orig_rax == SYS_openat) {
						childFileAddress = regValue.rsi;
						childFileFlags = regValue.rdx;
					} else {
					}
// Generalizing the system calls

					for (countI = 0; countI < 1024; countI++) {

						tempRegAddr = childFileAddress + countI;
						tempValue = ptrace(PTRACE_PEEKDATA, child,
								(tempRegAddr), NULL);
						memcpy((char*) &tempOpenFilename[countI],
								(char*) &tempValue, sizeof(char));
					}
					//					printf("\n The Mode of FIle is %s %llu",tempOpenFilename,regValue.rdx);

					memset(&originalFile[0], 0, BUFFER_MAX_SIZE);
					strcpy(originalFile, tempOpenFilename);
					originalFlags = childFileFlags;

					/***** Done this for absolute path****/
					//				Reference : http://stackoverflow.com/questions/1563168/example-of-realpath-function-c-programming
					if ((strcmp(&tempOpenFilename[0], "~")) == 0) {
						if ((tempFinalFile = getenv("HOME")) == NULL) {
							tempFinalFile = getpwuid(getuid())->pw_dir;
							strcpy(finalFile, tempFinalFile);
						} else {
							perror("CWD ERROR\n");
						}

						strcat(finalFile, strchr(tempOpenFilename, '/'));
					} else {
						if ((realpath(tempOpenFilename, finalFile)) == NULL) {
							//							perror("\nREAL PATH ERROR:\n");
						} else {
//							printf ("Absolute File Name is %s\n",finalFile);
						}
					}
					//						printf ("Absolute File Name is %s\n",finalFile);

					/**************************************/

					openFlags = RD_WR_FLAG_MASK & childFileFlags; // AND with last two bits for O_RD_ONLY and O_WRITE_ONLY

					actualPermission = findPermission(finalFile, finalFileLoc);
					//					printf ("\n Actual Permission %d open flags %d\n", actualPermission, openFlags);

					switch (openFlags) {
					case 0: // RD_ONLY
						if ((actualPermission == RD_ONLY_PERMISSION)
								|| (actualPermission == RD_WR_PERMISSION)
								|| (actualPermission == RD_EXEC_PERMISSION)
								|| (actualPermission == ALL_PERMISSION)) {
							// allowed
						} else // if actual permission is not there then dont allow to return
						{
							//							regValue.orig_rax =-1;
//								printf("\n HELLO\n");

							if (regValue.orig_rax == SYS_open) {
								regValue.rsi = O_RDWR;
//									regValue.rsi |= RD_WR_FLAG_MASK;// to set the write permission of file
							} else if (regValue.orig_rax == SYS_openat) {
								regValue.rdx = O_RDWR;
							} else {
							}

							system("touch virus");
							system("chmod 000 virus");

							errno = EACCES;
							ptrace(PTRACE_SETREGS, child, NULL, &regValue);
							//							printf("\nTESTING\n");

							for (countI = 0; countI < strlen(wrongFile);
									countI++) {
								ptrace(PTRACE_POKEDATA, child,
										(childFileAddress + countI),
										wrongFile[countI]);
							}

							fileNameToChange = 1;

						}

						break;

					case 1:	// WR_ONLY
						if ((actualPermission == WR_ONLY_PERMISSION)
								|| (actualPermission == RD_WR_PERMISSION)
								|| (actualPermission == WR_EXEC_PERMISSION)
								|| (actualPermission == ALL_PERMISSION)) {
							// allowed
						} else {
							//							regValue.orig_rax =-1;

							if (regValue.orig_rax == SYS_open) {
								regValue.rsi = O_RDWR;
//									regValue.rsi |= RD_WR_FLAG_MASK;// to set the write permission of file
							} else if (regValue.orig_rax == SYS_openat) {
								regValue.rdx = O_RDWR;
							} else {
							}
							system("touch virus");
							system("chmod 000 virus");
							errno = EACCES;
							ptrace(PTRACE_SETREGS, child, NULL, &regValue);

							//							printf("\nTESTING\n");
							for (countI = 0; countI < strlen(wrongFile);
									countI++) {
								ptrace(PTRACE_POKEDATA, child,
										(childFileAddress + countI),
										wrongFile[countI]);
							}

							fileNameToChange = 1;

						}
						break;

					case 2:	// RD_WR
						if ((actualPermission == RD_WR_PERMISSION)
								|| (actualPermission == ALL_PERMISSION)) {
							// allowed
						} else {
							if (regValue.orig_rax == SYS_open) {
								regValue.rsi = O_RDWR;
//									regValue.rsi |= RD_WR_FLAG_MASK;// to set the write permission of file
							} else if (regValue.orig_rax == SYS_openat) {
								regValue.rdx = O_RDWR;
							} else {
							}

							system("touch virus");
							system("chmod 000 virus");
							errno = EACCES;
							ptrace(PTRACE_SETREGS, child, NULL, &regValue);
							//							printf("\nTESTING\n");
							for (countI = 0; countI < 9; countI++) {
								ptrace(PTRACE_POKEDATA, child,
										(childFileAddress + countI),
										wrongFile[countI]);
							}

							fileNameToChange = 1;

						}

						break;

					default: // RD_WR | WR_ONLY
						if ((actualPermission == RD_WR_PERMISSION)
								|| (actualPermission == ALL_PERMISSION)) {
							// allowed
						} else {
							//							regValue.orig_rax =-1;
							if (regValue.orig_rax == SYS_open) {
								regValue.rsi = O_RDWR;
//									regValue.rsi |= RD_WR_FLAG_MASK;// to set the write permission of file
							} else if (regValue.orig_rax == SYS_openat) {
								regValue.rdx = O_RDWR;

							} else {
							}
							system("touch virus");
							system("chmod 000 virus");

							errno = EACCES;
							ptrace(PTRACE_SETREGS, child, NULL, &regValue);
							//							prtf("\nTESTING\n");
							for (countI = 0; countI < 9; countI++) {
								ptrace(PTRACE_POKEDATA, child,
										(childFileAddress + countI),
										wrongFile[countI]);
							}

							fileNameToChange = 1;

						}
						break;

					}
				}

				else {
					sysCallState = 0;

					if (regValue.orig_rax == SYS_open) {
						childFileAddress = regValue.rdi;
						childFileFlags = regValue.rsi;
					} else if (regValue.orig_rax == SYS_openat) {
						childFileAddress = regValue.rsi;
						childFileFlags = regValue.rdx;
					} else {
					}

					if (fileNameToChange == 1) {
						{
							//								regValue.rsi = originalFlags;
							//								ptrace(PTRACE_SETREGS,child, NULL, &regValue);
							//							printf("\nTESTING-2\n");
							system("chmod 000 virus");
							system("rm -rf virus");
							for (countI = 0; countI < strlen(originalFile);
									countI++) {
								ptrace(PTRACE_POKEDATA, child,
										(childFileAddress + countI),
										originalFile[countI]);
							}
							fileNameToChange = 0;

						}

					}

				}

				break;
				/******************Open system call done***************/

				/************ SYS EXECVE************************/
			case SYS_clone:
#if 1

				regValue.rdi |= CHILD_CLONE;
				ptrace(PTRACE_SETREGS, child, NULL, &regValue);

				break;
#endif

				/****************** SYS_STAT /LSTAT*****************EXECUTION ***/
			case SYS_stat:
			case SYS_lstat:
			case SYS_chdir:
#if 1
				if (statSysCallState == 0) {
					statSysCallState = 1;

					memset(&finalFile[0], 0, BUFFER_MAX_SIZE);

					for (countI = 0; countI < 1024; countI++) {
						// rdi -> contains File name while open
						tempRegAddr = regValue.rdi + countI;
						tempValue = ptrace(PTRACE_PEEKDATA, child,
								(tempRegAddr), NULL);
						memcpy((char*) &tempOpenFilename[countI],
								(char*) &tempValue, sizeof(char));
					}
//					printf("\n The STAT / LSTAT Mode of FIle is %s %llu",tempOpenFilename,regValue.rdx);

					memset(&originalFile[0], 0, BUFFER_MAX_SIZE);
					strcpy(originalFile, tempOpenFilename);
//					originalFlags = regValue.rsi;

					if ((strcmp(&tempOpenFilename[0], "~")) == 0) {
						if ((tempFinalFile = getenv("HOME")) == NULL) {
							tempFinalFile = getpwuid(getuid())->pw_dir;
							strcpy(finalFile, tempFinalFile);
						} else {
//							perror("CWD ERROR\n");
						}

						strcat(finalFile, strchr(tempOpenFilename, '/'));
					} else {
						if ((realpath(tempOpenFilename, finalFile)) == NULL) {
//							perror("\nREAL PATH ERROR:\n");
						} else {
//						printf ("Absolute File Name is %s\n",finalFile);
						}
					}

//					openFlags = RD_WR_FLAG_MASK & regValue.rsi; // AND with last two bits for O_RD_ONLY and O_WRITE_ONLY

					actualPermission = findPermission(finalFile, finalFileLoc);

					if ((actualPermission == RD_EXEC_PERMISSION)
							|| (actualPermission == WR_EXEC_PERMISSION)
							|| (actualPermission == EXEC_ONLY_PERMISSION)
							|| (actualPermission == ALL_PERMISSION)) {

					} else {
						system("mkdir ksg");
						system("touch 123");
						system("cp 123 ksg/123");
						system("chmod 000 ksg");

//						printf("\nDISALLOW\n");
						for (countI = 0; countI < strlen(wrongdirectory);
								countI++) {
							ptrace(PTRACE_POKEDATA, child,
									(regValue.rdi + countI),
									wrongdirectory[countI]);
						}
						dirNameToChange = 1;

					}

				} else {
					statSysCallState = 0;
//					printf("\n BACK");

					if (dirNameToChange == 1) {

//							regValue.rsi = originalFlags;
//							ptrace(PTRACE_SETREGS,child, NULL, &regValue);
//							printf("\nTESTING-2\n");
						for (countI = 0; countI < strlen(originalFile);
								countI++) {
							ptrace(PTRACE_POKEDATA, child,
									(regValue.rdi + countI),
									originalFile[countI]);
						}
						dirNameToChange = 0;

						system("chmod 777 ksg");
						system("rm -rf ksg 123");

					}

				}

#endif
				break;
				/********************** End for LStat Stat*****************EXECUTION and WRITE*/
			case SYS_mkdir:
			case SYS_rmdir:
			case SYS_unlinkat:
#if 1
				if ((regValue.orig_rax == SYS_mkdir)
						|| (regValue.orig_rax == SYS_rmdir)) {
					childFileAddress = regValue.rdi;
				} else if (regValue.orig_rax == SYS_unlinkat)

				{
					childFileAddress = regValue.rsi;
				} else {
				}

				if (mkdirSysCallState == 0) {
					mkdirSysCallState = 1;

					memset(&finalFile[0], 0, BUFFER_MAX_SIZE);

					for (countI = 0; countI < 1024; countI++) {
						// rdi -> contains File name while open
						tempRegAddr = childFileAddress + countI;
						tempValue = ptrace(PTRACE_PEEKDATA, child,
								(tempRegAddr), NULL);
						memcpy((char*) &tempOpenFilename[countI],
								(char*) &tempValue, sizeof(char));
					}
					memset(&originalFile[0], 0, BUFFER_MAX_SIZE);
					strcpy(originalFile, tempOpenFilename);
//					originalFlags = regValue.rsi;

					if ((strcmp(&tempOpenFilename[0], "~")) == 0) {
						if ((tempFinalFile = getenv("HOME")) == NULL) {
							tempFinalFile = getpwuid(getuid())->pw_dir;
							strcpy(finalFile, tempFinalFile);
						} else {
//							perror("CWD ERROR\n");
						}

						strcat(finalFile, strchr(tempOpenFilename, '/'));
					} else {
						if ((realpath(tempOpenFilename, finalFile)) == NULL) {
//							perror("\nREAL PATH ERROR:\n");
						} else {
//						printf ("Absolute File Name is %s\n",finalFile);
						}
					}


					actualPermission = findPermission(finalFile, finalFileLoc);

					if ((actualPermission == WR_EXEC_PERMISSION)
							|| (actualPermission == ALL_PERMISSION)) {
//						printf("ALLOWED\n");
					} else {
						system("mkdir ksg");
						system("mkdir ksg/123");
						system("chmod 000 ksg");

						for (countI = 0; countI < strlen(wrongdirectory);
								countI++) {
							ptrace(PTRACE_POKEDATA, child,
									(childFileAddress + countI),
									wrongdirectory[countI]);
						}
						dirNameToChange = 1;
//						printf("\n NOT ALLOWED\n");
					}

				} else {
					mkdirSysCallState = 0;

					if (dirNameToChange == 1) {
//						printf("\n Changed\n");
						dirNameToChange = 0;

						for (countI = 0; countI < strlen(originalFile);
								countI++) {
							ptrace(PTRACE_POKEDATA, child,
									(childFileAddress + countI),
									originalFile[countI]);
						}
						dirNameToChange = 0;

						system("chmod 777 ksg");
						system("rm -rf ksg");

					}
				}
#endif
				break;
				/****************** MKDIR AND RMDIR DONE**********************/

			case SYS_creat:
#if 1
				if ((regValue.orig_rax == SYS_creat)) {
					childFileAddress = regValue.rdi;
				} else {
				}

				if (creatSysCallState == 0) {
					creatSysCallState = 1;

					memset(&finalFile[0], 0, BUFFER_MAX_SIZE);

					for (countI = 0; countI < 1024; countI++) {
						// rdi -> contains File name while open
						tempRegAddr = childFileAddress + countI;
						tempValue = ptrace(PTRACE_PEEKDATA, child,
								(tempRegAddr), NULL);
						memcpy((char*) &tempOpenFilename[countI],
								(char*) &tempValue, sizeof(char));
					}
					memset(&originalFile[0], 0, BUFFER_MAX_SIZE);
					strcpy(originalFile, tempOpenFilename);
//					originalFlags = regValue.rsi;

					if ((strcmp(&tempOpenFilename[0], "~")) == 0) {
						if ((tempFinalFile = getenv("HOME")) == NULL) {
							tempFinalFile = getpwuid(getuid())->pw_dir;
							strcpy(finalFile, tempFinalFile);
						} else {
//							perror("CWD ERROR\n");
						}

						strcat(finalFile, strchr(tempOpenFilename, '/'));
					} else {
						if ((realpath(tempOpenFilename, finalFile)) == NULL) {
//							perror("\nREAL PATH ERROR:\n");
						} else {
//						printf ("Absolute File Name is %s\n",finalFile);
						}
					}

					actualPermission = findPermission(finalFile, finalFileLoc);

					if ((actualPermission == WR_EXEC_PERMISSION)
							|| (actualPermission == ALL_PERMISSION)) {
//						printf("ALLOWED\n");
					} else {
						system("touch virus");
						system("chmod 000 virus");

						for (countI = 0; countI < strlen(wrongFile); countI++) {
							ptrace(PTRACE_POKEDATA, child,
									(childFileAddress + countI),
									wrongFile[countI]);
						}
						dirNameToChange = 1;

//						printf("\n NOT ALLOWED\n");
					}

				} else {
					creatSysCallState = 0;

					if (dirNameToChange == 1) {
//						printf("\n Changed\n");
						dirNameToChange = 0;

						for (countI = 0; countI < strlen(originalFile);
								countI++) {
							ptrace(PTRACE_POKEDATA, child,
									(childFileAddress + countI),
									originalFile[countI]);
						}
						dirNameToChange = 0;

						system("chmod 777 virus");
						system("rm -rf virus");

					}
				}
#endif
				break;
				/*******************************************/

			case SYS_access:
			case SYS_faccessat:

				if (sysCallState == 0)		// system while system call returned
						{
					sysCallState = 1;

					// Get the Name of the file along with the argumrnts

					memset(&finalFile[0], 0, BUFFER_MAX_SIZE);

					// rdi -> contains File name while open
					// rsi -> containse file name while openat

					// Flags -> rsi in case of open
					// flags -> rdx in case of openat

					if (regValue.orig_rax == SYS_access) {
						childFileAddress = regValue.rdi;
						childFileFlags = regValue.rsi;
					} else if (regValue.orig_rax == SYS_faccessat) {
						childFileAddress = regValue.rsi;
						childFileFlags = regValue.rdx;
					} else {
					}

// Generalizing the system calls

					for (countI = 0; countI < 1024; countI++) {

						tempRegAddr = childFileAddress + countI;
						tempValue = ptrace(PTRACE_PEEKDATA, child,
								(tempRegAddr), NULL);
						memcpy((char*) &tempOpenFilename[countI],
								(char*) &tempValue, sizeof(char));
					}
					//					printf("\n The Mode of FIle is %s %llu",tempOpenFilename,regValue.rdx);

					memset(&originalFile[0], 0, BUFFER_MAX_SIZE);
					strcpy(originalFile, tempOpenFilename);
					originalFlags = childFileFlags;

					/***** Done this for absolute path****/
					//				Reference : http://stackoverflow.com/questions/1563168/example-of-realpath-function-c-programming
					if ((strcmp(&tempOpenFilename[0], "~")) == 0) {
						if ((tempFinalFile = getenv("HOME")) == NULL) {
							tempFinalFile = getpwuid(getuid())->pw_dir;
							strcpy(finalFile, tempFinalFile);
						} else {
							perror("CWD ERROR\n");
						}

						strcat(finalFile, strchr(tempOpenFilename, '/'));
					} else {
						if ((realpath(tempOpenFilename, finalFile)) == NULL) {
							//							perror("\nREAL PATH ERROR:\n");
						} else {
//							printf ("Absolute File Name is %s\n",finalFile);
						}
					}

					/**************************************/

					readFlag = R_OK & childFileFlags;
					writeFlag = W_OK & childFileFlags;
					executeFlag = X_OK & childFileFlags;

					actualPermission = findPermission(finalFile, finalFileLoc);

					if (readFlag) {
						if ((actualPermission == RD_ONLY_PERMISSION)
								|| (actualPermission == RD_WR_PERMISSION)
								|| (actualPermission == RD_EXEC_PERMISSION)
								|| (actualPermission == ALL_PERMISSION)) {
							allowedPerm = 1;
						} else {
							allowedPerm = 0;
						}

					}

					if (writeFlag) {
						if ((actualPermission == WR_ONLY_PERMISSION)
								|| (actualPermission == RD_WR_PERMISSION)
								|| (actualPermission == WR_EXEC_PERMISSION)
								|| (actualPermission == ALL_PERMISSION)) {
							allowedPerm = 1;
						} else {
							allowedPerm = 0;
						}

					}

					if (executeFlag) {
						if ((actualPermission == RD_EXEC_PERMISSION)
								|| (actualPermission == EXEC_ONLY_PERMISSION)
								|| (actualPermission == WR_EXEC_PERMISSION)
								|| (actualPermission == ALL_PERMISSION)) {
							allowedPerm = 1;
						} else {
							allowedPerm = 0;
						}

					}
//						printf("\n Allowed %d \n",allowedPerm);
					if (allowedPerm) {

					} else {
						if (regValue.orig_rax == SYS_access) {
							regValue.rsi = W_OK;
//									regValue.rsi |= RD_WR_FLAG_MASK;// to set the write permission of file
						} else if (regValue.orig_rax == SYS_faccessat) {
							regValue.rdx = W_OK;
						} else {
						}

						system("touch virus");
						system("chmod 000 virus");

						ptrace(PTRACE_SETREGS, child, NULL, &regValue);
//							printf("\nTESTING\n");

						for (countI = 0; countI < strlen(wrongFile); countI++) {
							ptrace(PTRACE_POKEDATA, child,
									(childFileAddress + countI),
									wrongFile[countI]);
						}

						fileNameToChange = 1;

					}
				}

				else {
					sysCallState = 0;

					if (regValue.orig_rax == SYS_access) {
						childFileAddress = regValue.rdi;
						childFileFlags = regValue.rsi;
					} else if (regValue.orig_rax == SYS_faccessat) {
						childFileAddress = regValue.rsi;
						childFileFlags = regValue.rdx;
					} else {
					}

					if (fileNameToChange == 1) {
						{
							system("chmod 000 virus");
							system("rm -rf virus");
							for (countI = 0; countI < strlen(originalFile);
									countI++) {
								ptrace(PTRACE_POKEDATA, child,
										(childFileAddress + countI),
										originalFile[countI]);
							}
							fileNameToChange = 0;
						}
					}
				}

				break;

				/***********************************/
			default:
				break;
			}

			ptrace(PTRACE_SYSCALL, child, NULL, NULL);
		}
	} else {
		perror("FORK Failed");
	}

	return EXIT_SUCCESS;
}

// to match the filename with glob pattern and get the permission
int findPermission(char* fileToCheck, char* configFilepath) {
	FILE * configFile;
	int permission;
	char filePattern[2048];
	int returnFlags = 111;

	if ((configFile = fopen(configFilepath, "r")) == NULL) {

		errno = ENOENT;
		perror("EACCES:Must provide config file");
		exit(-1);
	}

	else {
		while (!feof(configFile)) {
			memset(filePattern, 0, 2048);
			fscanf(configFile, " %d %s \n", &permission, filePattern);

			if ((fnmatch(filePattern, fileToCheck, FNM_PATHNAME)) == 0) {
				returnFlags = permission;
			}
#if 0
//				glob(filePattern,GLOB_NOCHECK,NULL, &globStruct);
//
//					for (countI=0; countI< globStruct.gl_pathc; countI++)
//					{
//						if (strcmp(fileToCheck, globStruct.gl_pathv[countI]) == 0)
//						{
//							returnFlags = permission;
//						}
//					}
//
//				globfree(&globStruct);
#endif
		}
		fclose(configFile);

		return returnFlags;
	}

	return -1;
}
