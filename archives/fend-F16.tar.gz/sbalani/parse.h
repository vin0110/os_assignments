#define NO_ACCESS 0
#define READ_ACCESS 100
#define WRITE_ACCESS 10
#define EXEC_ACCESS  1
#define RDWR_ACCESS 110
#define WREX_ACCESS 11
#define RDEX_ACCESS 101
#define ALL_ACCESS 111

int parser(char *filename,char *config_file);
int get_absolute_path(char *filename,char *absolute_path);
