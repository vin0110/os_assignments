#include<sys/user.h>
#include<sys/types.h>

int open_handler(pid_t pid,struct user_regs_struct *arguments,char *config_file);
int openat_handler(pid_t pid,struct user_regs_struct *arguments,char *config_file);
int stat_handler(pid_t pid,struct user_regs_struct *arguments,char *config_file);
int mkdir_handler(pid_t pid,struct user_regs_struct *arguments,char *config_file);
int chdir_handler(pid_t pid,struct user_regs_struct *arguments,char *config_file);
int creat_handler(pid_t pid,struct user_regs_struct *arguments,char *config_file);
int faccessat_handler(pid_t pid,struct user_regs_struct *arguments,char *config_file);
int access_handler(pid_t pid,struct user_regs_struct *arguments,char *config_file);
int clone_handler(pid_t pid,struct user_regs_struct *arguments,char *config_file);

void read_string_arg(pid_t pid, long long unsigned addr);
void write_string_arg(pid_t pid,long long unsigned addr);

/* Use this function only for debugging */
void read_string_arg_temp(pid_t pid, long long unsigned addr);
