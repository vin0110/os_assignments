#include <stdbool.h>
#include<fcntl.h>
#include<string.h>
#include<sys/ptrace.h>
#include<asm/unistd.h>						//getcwd()
#include<stdio.h>
#include<strings.h>
#include<stdlib.h>						//system()
#include <linux/sched.h>
#include "syscall_handler.h"
#include "parse.h"

int enter_open_syscall=1;
int enter_openat_syscall=1;
int enter_stat_syscall=1;
int enter_mkdir_syscall=1;
int enter_chdir_syscall=1;
int enter_fchdir_syscall=1;
int enter_creat_syscall=1;
int enter_access_syscall=1;
char filename[1024];
char filename_temp[1024];
char wrong_file[]="tmpq";
char wrong_dir[]="tmpz/z";
char nowrex_file[]="tmpy/z";
bool temp_created=false;
bool done = false;
//bool root = false;
long long unsigned *fileptr;

int clone_handler(pid_t pid,struct user_regs_struct *arguments,char *config_file)
{	
	arguments->rdi|=CLONE_PTRACE;	
		
	ptrace(PTRACE_SETREGS,pid,0l,arguments);	
}

int access_handler(pid_t pid,struct user_regs_struct *arguments,char *config_file)
{
	
	int directory_permissions;
	int permissionDenied;

	
	if(enter_access_syscall==1)
        {
                read_string_arg(pid,arguments->rdi);
		//printf("%s",filename);
                directory_permissions=parser(filename,config_file);
		
		//printf(":%d \n",directory_permissions);	
		/* R_OK=4, W_OK=2,X_OK=1 */
		/* Test for execute permission.  */
		if((arguments->rsi & 1)==1)
		{
			if( directory_permissions==WREX_ACCESS | directory_permissions==ALL_ACCESS)
			{
			/* This implies file has the necessary execute permission */
			}	
			else
			{
                        	permissionDenied=-1;

                        	system("touch tmpq");
                        	system("chmod 000 tmpq");
                        	temp_created=true;

                        	for (int i=0; i<strlen(wrong_file);i++)
                        	{
                        	        ptrace(PTRACE_POKEDATA,pid,(arguments->rdi)+i,wrong_file[i]);
                        	}
				enter_access_syscall=0;
				return permissionDenied;
			}
		}
		/* Test for read permission.  */
		if((arguments->rsi & 2)==2 )
		{
			if(directory_permissions==WRITE_ACCESS | directory_permissions==WREX_ACCESS | directory_permissions==RDWR_ACCESS | directory_permissions==ALL_ACCESS)
               		{
                		/* This implies file has the necessary write permission */
                	}
			else
			{
				permissionDenied=-1;

                        	system("touch tmpq");
                        	system("chmod 000 tmpq");
                        	temp_created=true;

                        	for (int i=0; i<strlen(wrong_file);i++)
                        	{
                        	        ptrace(PTRACE_POKEDATA,pid,(arguments->rdi)+i,wrong_file[i]);
                        	}
				enter_access_syscall=0;
				return permissionDenied;
			}

		}
		/* Test for read permission.  */
		if((arguments->rsi &4)==4)
		{
			if(directory_permissions==READ_ACCESS | directory_permissions==RDWR_ACCESS | directory_permissions==RDEX_ACCESS | directory_permissions==ALL_ACCESS)
                	{
                		/* This implies file has the necessary read permission */
                	}
			else
			{
				permissionDenied=-1;

                        	system("touch tmpq");
                        	system("chmod 000 tmpq");
                        	temp_created=true;
                        	for (int i=0; i<strlen(wrong_file);i++)
                        	{
                        	        ptrace(PTRACE_POKEDATA,pid,(arguments->rdi)+i,wrong_file[i]);
                        	}
				enter_access_syscall=0;
				return permissionDenied;
			}	
		}
	}
        else
        {
                if(temp_created==true)
                {
                        system("touch 777 tmpq");
                        system("rm -rf tmpq");
                        temp_created=false;
                }
                write_string_arg(pid,arguments->rdi);
                enter_access_syscall=1;
                return permissionDenied;
        }
}






int faccessat_handler(pid_t pid,struct user_regs_struct *arguments,char *config_file)
{
	
	int directory_permissions;
	int permissionDenied;

	
	if(enter_access_syscall==1)
        {
                read_string_arg(pid,arguments->rsi);
		//printf("%s",filename);
                directory_permissions=parser(filename,config_file);
		
		//printf(":%d \n",directory_permissions);	
		/* R_OK=4, W_OK=2,X_OK=1 */
		/* Test for execute permission.  */
		if((arguments->rdx & 1)==1)
		{
			if(directory_permissions==EXEC_ACCESS | directory_permissions==WREX_ACCESS | directory_permissions==RDEX_ACCESS | directory_permissions==ALL_ACCESS)
			{
			/* This implies file has the necessary execute permission */
			}	
			else
			{
                        	permissionDenied=-1;

                        	system("touch tmpq");
                        	system("chmod 000 tmpq");
                        	temp_created=true;

                        	for (int i=0; i<strlen(wrong_file);i++)
                        	{
                        	        ptrace(PTRACE_POKEDATA,pid,(arguments->rsi)+i,wrong_file[i]);
                        	}
				enter_access_syscall=0;
				return permissionDenied;
			}
		}
		/* Test for read permission.  */
		if((arguments->rdx & 2)==2 )
		{
			if(directory_permissions==WRITE_ACCESS | directory_permissions==WREX_ACCESS | directory_permissions==RDWR_ACCESS | directory_permissions==ALL_ACCESS)
               		{
                		/* This implies file has the necessary write permission */
                	}
			else
			{
				permissionDenied=-1;

                        	system("touch tmpq");
                        	system("chmod 000 tmpq");
                        	temp_created=true;

                        	for (int i=0; i<strlen(wrong_file);i++)
                        	{
                        	        ptrace(PTRACE_POKEDATA,pid,(arguments->rsi)+i,wrong_file[i]);
                        	}
				enter_access_syscall=0;
				return permissionDenied;
			}

		}
		/* Test for read permission.  */
		if((arguments->rdx &4)==4)
		{
			if(directory_permissions==READ_ACCESS | directory_permissions==RDWR_ACCESS | directory_permissions==RDEX_ACCESS | directory_permissions==ALL_ACCESS)
                	{
                		/* This implies file has the necessary read permission */
                	}
			else
			{
				permissionDenied=-1;

                        	system("touch tmpq");
                        	system("chmod 000 tmpq");
                        	temp_created=true;
                        	for (int i=0; i<strlen(wrong_file);i++)
                        	{
                        	        ptrace(PTRACE_POKEDATA,pid,(arguments->rsi)+i,wrong_file[i]);
                        	}
				enter_access_syscall=0;
				return permissionDenied;
			}	
		}
	}
        else
        {
                if(temp_created==true)
                {
                        system("touch 777 tmpq");
                        system("rm -rf tmpq");
                        temp_created=false;
                }
                write_string_arg(pid,arguments->rsi);
                enter_access_syscall=1;
                return permissionDenied;
        }
}

int creat_handler(pid_t pid,struct user_regs_struct *arguments,char *config_file)
{
	int directory_permissions;
	int permissionDenied;
	
	if(enter_creat_syscall==1)
        {
                read_string_arg(pid,arguments->rdi);
		//printf("%s",filename);
                directory_permissions=parser(filename,config_file);
		//printf("%d \n",directory_permissions);
		
		//Check no write permissions
                if(directory_permissions!=ALL_ACCESS & directory_permissions!=WREX_ACCESS)
                {
			
                        permissionDenied=-1;

                        system("touch tmpq");
                        system("chmod 000 tmpq");
                        temp_created=true;

                        for (int i=0; i<strlen(wrong_file);i++)
                        {
                                ptrace(PTRACE_POKEDATA,pid,(arguments->rdi)+i,wrong_file[i]);
                        }
                }
                enter_creat_syscall=0;
        }
        else
        {
                if(temp_created==true)
                {
                        system("touch 777 tmpq");
                        system("rm -rf tmpq");
                        temp_created=false;
                }
                write_string_arg(pid,arguments->rdi);
                enter_creat_syscall=1;
                return permissionDenied;
        }
}

int chdir_handler(pid_t pid,struct user_regs_struct *arguments,char *config_file)
{
	int directory_permissions;
	int permissionDenied;

	if(enter_chdir_syscall==1)
	{
		read_string_arg(pid,arguments->rdi);
				
		directory_permissions=parser(filename,config_file);
		

		//check if execute access
		if(directory_permissions!=EXEC_ACCESS & directory_permissions!=ALL_ACCESS & directory_permissions!=WREX_ACCESS & directory_permissions!=RDEX_ACCESS)
		{
			permissionDenied=-1;
			
			system("mkdir tmpy");
			system("chmod 000 tmpy");
			temp_created=true;

		 	for (int i=0; i<strlen(nowrex_file);i++)
                        {
                                ptrace(PTRACE_POKEDATA,pid,(arguments->rdi)+i,nowrex_file[i]);
                        }
		}	
		enter_chdir_syscall=0;		
	}
	else
	{
		if(temp_created==true)
                {
                        system("chmod 777 tmpy");
                        system("rm -rf tmpy");
                        temp_created=false;
                }
		write_string_arg(pid,arguments->rdi);
                enter_chdir_syscall=1;
                return permissionDenied;

	}
}


int mkdir_handler(pid_t pid,struct user_regs_struct *arguments,char *config_file)
{
	int directory_permissions;
	int permissionDenied;

	if(enter_mkdir_syscall==1)
	{
		read_string_arg(pid,arguments->rdi);
				
		directory_permissions=parser(filename,config_file);
		
		
		if(directory_permissions==WREX_ACCESS | directory_permissions==ALL_ACCESS)
		{
			
			enter_mkdir_syscall=0;		
			return 0;
		}
		else
		{
			permissionDenied=-1;
			
			system("mkdir tmpy");
			system("chmod 000 tmpy");
			temp_created=true;

		 	for (int i=0; i<strlen(nowrex_file);i++)
                        {
                                ptrace(PTRACE_POKEDATA,pid,(arguments->rdi)+i,nowrex_file[i]);
                        }
		
			enter_mkdir_syscall=0;	
			return permissionDenied;	
		}	
	}
	else
	{
		if(temp_created==true)
                {
                        system("chmod 777 tmpy");
                        system("rm -rf tmpy");
                        temp_created=false;
                }
		write_string_arg(pid,arguments->rdi);
                enter_mkdir_syscall=1;
                return permissionDenied;

	}
}


int stat_handler(pid_t pid,struct user_regs_struct *arguments,char *config_file)
{
	int directory_permissions;
	int permissionDenied;
		 	
	if(enter_stat_syscall==1)
	{
		read_string_arg(pid,arguments->rdi);
		directory_permissions=parser(filename,config_file);
	  	
		//check if execute permission is there
		if(directory_permissions==RDEX_ACCESS | directory_permissions==WREX_ACCESS | directory_permissions==ALL_ACCESS | directory_permissions==EXEC_ACCESS)
		{
			enter_stat_syscall=0;
			return 0;
		}		
		else
		{
			permissionDenied=-1;
			
			system("mkdir tmpz");
			system("mkdir tmpz/z");	
			system("chmod 000 tmpz");
			temp_created=true;

			for (int i=0; i<strlen(wrong_dir);i++)
			{
				ptrace(PTRACE_POKEDATA,pid,(arguments->rdi)+i,wrong_dir[i]);
						
		        }	
		}	
		enter_stat_syscall=0;
		return permissionDenied;
	}
	else
	{


		if(temp_created==true)
		{
       			system("chmod 777 tmpz");
      			system("rm -rf tmpz");
			temp_created=false;
		}
		write_string_arg(pid,arguments->rdi); 
		enter_stat_syscall=1;
                return permissionDenied;

	}
		
}

int open_handler(pid_t pid,struct user_regs_struct *arguments,char *config_file)
{
	int filePermissions;
	int permissionDenied;
	//long long unsigned  flags;
	if(enter_open_syscall==1)
        {	
		read_string_arg(pid,arguments->rdi);
		filePermissions=parser(filename,config_file);
		
		//printf("Using config file:%s \n",config_file);
		//printf("Permissions on the file:%d \n",filePermissions); 

		/* This piece of code will be executed when open syscall in entered */
		switch(arguments->rsi&3)
		{
			case O_RDONLY:
			{	
				if(filePermissions==READ_ACCESS | filePermissions==RDWR_ACCESS | filePermissions==RDEX_ACCESS | filePermissions==ALL_ACCESS)
				{	
					enter_open_syscall=0;
					return 0;
				}
				else
				{
					system("touch tmpq");
					system("chmod 000 tmpq");
					temp_created=true;

					/* to be used if root has to be disallowed access according to config file
					if(geteuid()==0)
					{
						return 0;
					}
					*/
					//printf("argument rsi on enter:%llu \n",arguments->rsi);
					/* Set the file flag to read write */
					arguments->rsi=O_RDWR;
					ptrace(PTRACE_SETREGS,pid,0l,arguments);
					//printf("arguments.rsi=%llu \n",arguments.rsi);

					/* Change the file to open to /proc/fb (this file has r--r--r-- permissions */	
					//printf("argument rdi on enter:%llu \n",arguments->rdi);
					//printf("changing file to:%s \n",wrong_file);
					for (int i=0; i<strlen(wrong_file);i++)
					{				
						ptrace(PTRACE_POKEDATA,pid,(arguments->rdi)+i,wrong_file[i]);	
					}		
				}
				permissionDenied=-1;	
			}
			break;
			case O_WRONLY:
			{
				if(filePermissions==WRITE_ACCESS | filePermissions==RDWR_ACCESS | filePermissions==WREX_ACCESS | filePermissions==ALL_ACCESS)
				{	
					enter_open_syscall=0;
					return 0;
				}
				else
				{
					
					system("touch tmpq");
					system("chmod 000 tmpq");
					temp_created=true;

					/* to be used if root has to be disallowed access according to config file
					if(geteuid()==0)
					{
						return 0;
					}
					*/
					arguments->rsi=O_RDWR;
					ptrace(PTRACE_SETREGS,pid,0L,arguments);
					
					for (int i=0; i<strlen(wrong_file);i++)
                                        {
                                                ptrace(PTRACE_POKEDATA,pid,(arguments->rdi)+i,wrong_file[i]);
                                        }
				}
				permissionDenied=-1;
	
			}
			break;
			case O_RDWR:
			{
				if(filePermissions==RDWR_ACCESS | filePermissions==ALL_ACCESS)
                                { 
					enter_open_syscall=0;
				       return 0;
				}
                                else
                                {
					system("touch tmpq");
					system("chmod 000 tmpq");
					temp_created=true;

					/* to be used if root has to be disallowed access according to config file
					if(geteuid()==0)
					{
						return 0;
					}
					*/
                                        arguments->rsi=O_RDWR;
                                        ptrace(PTRACE_SETREGS,pid,0L,arguments);

                                        for (int i=0; i<strlen(wrong_file);i++)
                                        {
                                                ptrace(PTRACE_POKEDATA,pid,(arguments->rdi)+i,wrong_file[i]);
                                    	}
				}
				permissionDenied=-1;
			}
			break;
			default:
				return 0;
			break;
		}
		
		enter_open_syscall=0;
		return permissionDenied;
	}
	else
	{
		if(temp_created==true)
		{
       			system("chmod 777 tmpq");
      			system("rm -rf tmpq");
			temp_created=false;
		}

		/* This piece of code will be executed when open syscall is exited */
		//printf("argument rdi on exit:%llu \n",arguments->rdi);
		//printf("argument rsi on exit:%llu \n",arguments->rsi);
		//read_string_arg(pid,arguments);
		//printf("%s \n",filename);
		write_string_arg(pid,arguments->rdi);
		enter_open_syscall=1;
		return permissionDenied;
	}

}

int openat_handler(pid_t pid,struct user_regs_struct *arguments,char *config_file)
{
	char file_fd_path[1024];
	char current_working_directory[1024];
	char directory_path[1024];
	char relative_filename[1024];

	int filePermissions;
	int permissionDenied;

	if(enter_openat_syscall==1)
	{
		/* For openat the filename is contained in address pointed to by rsi register*/
		read_string_arg(pid,arguments->rsi);
		/*Uncomment this to print the first character of the filename 
		printf("first character of rsi=%c \n",filename[0]); */
		
		#if 0
		/* If first character of filename is "/" then the file path is absolute path */
		if(filename[0]!='/')
		/* If arguments->rdi==AT_FDCWD pass the filename as it is to parser function, it will take care of relative path name */
			if(arguments->rdi!=AT_FDCWD)
			{
				/* If this block of code is being executed the the filename contains a relative path for the file 
				with respect to the directory file descriptor stored in arguments->rdi */
				memset(file_fd_path,0,1024);
				sprintf(file_fd_path,"/proc/%d/fd/%llu",pid,arguments->rdi);

				memset(directory_path,0,1024);
				readlink(file_fd_path,directory_path,1024);

				memcpy(relative_filename,filename,1024);
				memset(filename,0,1024);
						
				sprintf(filename,"%s/%s",directory_path,relative_filename);
			}
		Uncomment this to implement open at with direcotry file descriptors.Currently this does not work
		#endif	
	
		filePermissions=parser(filename,config_file);
		
		if(temp_created==true)
			printf("Temp exists \n");
		printf("Insie openat Systemcall,[%s] permission from file=%d \n",filename,filePermissions);	
		printf("rdx=%llu \n",(arguments->rdx & 3));
		switch((arguments->rdx)&3)
		{
			case O_RDONLY:
			{
				if(filePermissions==READ_ACCESS | filePermissions==RDWR_ACCESS | filePermissions==RDEX_ACCESS | filePermissions==ALL_ACCESS)
				{
					printf("File permission matched \n");
					enter_openat_syscall=0;
					return 0;
				}
				else
				{
					printf("file permissions did not match \n");
					system("touch tmpq");
					system("chmod 000 tmpq");
					temp_created=true;
					
					/* Set the file flag to read write */
					arguments->rdx=O_RDWR;
					ptrace(PTRACE_SETREGS,pid,0l,arguments);
					//printf("arguments.rsi=%llu \n",arguments.rsi);

					/* Change the file to open to /proc/fb (this file has r--r--r-- permissions */
					//printf("argument rdi on enter:%llu \n",arguments->rdi);
					//printf("changing file to:%s \n",wrong_file);
					for (int i=0; i<strlen(wrong_file);i++)
					{
						ptrace(PTRACE_POKEDATA,pid,(arguments->rsi)+i,wrong_file[i]);
					}
				}
				read_string_arg_temp(pid,arguments->rsi);
				printf("Filename %s",filename_temp);

				enter_openat_syscall=0;
				permissionDenied=-1;
			}
			 break;
			case O_WRONLY:
			{
				if(filePermissions==WRITE_ACCESS | filePermissions==RDWR_ACCESS | filePermissions==WREX_ACCESS | filePermissions==ALL_ACCESS)
				{
					enter_openat_syscall=0;
					return 0;
				}
				else
				{
					system("touch tmpq");
					system("chmod 000 tmpq");
					temp_created=true;
					
					arguments->rdx=O_RDWR;
					ptrace(PTRACE_SETREGS,pid,0L,arguments);

					for (int i=0; i<strlen(wrong_file);i++)
					{
						ptrace(PTRACE_POKEDATA,pid,(arguments->rsi)+i,wrong_file[i]);
					}
				}
				enter_openat_syscall=0;
				permissionDenied=-1;

			}
			break;
			case O_RDWR:
			{
				if(filePermissions==RDWR_ACCESS | filePermissions==ALL_ACCESS)
				{	
					enter_openat_syscall=0;
					return 0;
				}
				else
				{
					system("touch tmpq");
					system("chmod 000 tmpq");
					temp_created=true;

					arguments->rdx=O_RDWR;
					ptrace(PTRACE_SETREGS,pid,0L,arguments);
					

					for (int i=0; i<strlen(wrong_file);i++)
					{
						ptrace(PTRACE_POKEDATA,pid,(arguments->rsi)+i,wrong_file[i]);
					}
				}
				enter_openat_syscall=0;
				permissionDenied=-1;
			}
			break;
			default:
			{	
				enter_openat_syscall=0;
				return 0;
			}
			break;
		}
	
		enter_openat_syscall=0;
		return permissionDenied;
	}
	else
	{
		printf("Exitig openat systemcall \n");
		if(temp_created==true)
		{
			printf("Deleting temp file \n");
       			system("chmod 777 tmpq");
      			system("rm -rf tmpq");
			temp_created=false;
		}
		/* This piece of code will be executed when openat syscall is exited */
		printf("Rewrinting %s",filename);
		write_string_arg(pid,arguments->rsi);
                enter_openat_syscall=1;
                return permissionDenied;

	}
}

void read_string_arg(pid_t pid,long long unsigned addr)
{
 /* Initialize filename buffer with all Nulls. Note Ascii value of null is zero */
	memset(filename,0,1024);
	done=false;
	fileptr=(long long unsigned *)filename;

	/* For Open System Call %rdi stores the filename string pointer)
	 The below piece of code which extracts filename is attributed to https://bitbucket.org/snippets/bartbes/K8EKk/revisions/81436adfa3cc24c0560034fbdb3d6f10b2add4dd */

	for(int pos=0;pos<=1024-sizeof(long long unsigned)&&!done;pos+=sizeof(long long unsigned))
	{
		fileptr=(long long unsigned *)&filename[pos];
		*fileptr=ptrace(PTRACE_PEEKDATA,pid,addr+pos,NULL);
		for(int i=pos+sizeof(long long unsigned)-1;i<=pos;i--)
		{
			if(!filename[i])
			{
				done=true;
				break;
			}
		}
	}
}

void write_string_arg(pid_t pid,long long unsigned addr)
{
	for (int i=0; i<1024&&(filename[i]!=0);i++)
        {
        	ptrace(PTRACE_POKEDATA,pid,(addr)+i,filename[i]);
        }

}


/* Use this function only for debugging */
void read_string_arg_temp(pid_t pid,long long unsigned addr)
{
 /* Initialize filename buffer with all Nulls. Note Ascii value of null is zero */
	memset(filename_temp,0,1024);
	done=false;
	fileptr=(long long unsigned *)filename_temp;

	/* For Open System Call %rdi stores the filename string pointer)
	 The below piece of code which extracts filename is attributed to https://bitbucket.org/snippets/bartbes/K8EKk/revisions/81436adfa3cc24c0560034fbdb3d6f10b2add4dd */

	for(int pos=0;pos<=1024-sizeof(long long unsigned)&&!done;pos+=sizeof(long long unsigned))
	{
		fileptr=(long long unsigned *)&filename_temp[pos];
		*fileptr=ptrace(PTRACE_PEEKDATA,pid,addr+pos,NULL);
		for(int i=pos+sizeof(long long unsigned)-1;i<=pos;i--)
		{
			if(!filename_temp[i])
			{
				done=true;
				break;
			}
		}
	}
}
