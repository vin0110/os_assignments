#include <fnmatch.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include <pwd.h>
#include<unistd.h>				// getuid()
#include<sys/types.h>				// uid_t
#include "parse.h"


int parser(char *filename,char *config_file)
{
	FILE *config;
	char buffer[1024];
	int permissions;
	/* Initialise default access to all access */
	int fileaccess=111;
	char absolute_path[1024];
	int match_found=1;	

	memset(absolute_path,0,1024);
	get_absolute_path(filename,absolute_path);
	//printf("Absolute file path/name: %s \n",absolute_path);
	//printf("absolute path:%s\n ",absolute_path);
	if((config=fopen(config_file, "r"))==NULL)	
	{
		printf("Must provide config file.\n");
		exit(EXIT_FAILURE);
	}
	else
	{
		/* Uncomment this to print the file being searched and the config file being used
		printf("Searching for file %s",filename);
		printf("Using config file:%s",config_file);
		*/

		while(!feof(config))
		{
			
			fscanf(config,"%d",&permissions);

			memset(buffer,0,1024);
			fscanf(config," %s \n",buffer);	
			/* Uncomment this to print the permissions and pattern parsed from the config file line by line
			printf("Permissions:%d		Pattern:%s  \n",permissions,buffer);
			*/
			
			match_found=fnmatch(buffer,absolute_path,FNM_PATHNAME);
			//printf("Match result %d \n",match_found);
			if(match_found==0)
				fileaccess=permissions;
			
		}


	}
	//printf("%s	 %d \n",absolute_path,fileaccess);	
	fclose(config);		
	return fileaccess;
}

int get_absolute_path(char *filename,char *absolute_path)
{
	char *homedir;
	char *substring;

	/* If the file name contains ~ realpath function does not work. So 
	append ($HOME) to whatever follows ~/ */
	if((substring=strstr(filename,"~/"))!=NULL)
	{
		if((homedir=getenv("HOME")) == NULL)
        	{
                	homedir=getpwuid(getuid())->pw_dir;
        	}
		sprintf(absolute_path,"%s/%s",homedir,substring+2);
		return 0;
	}
	else
	{
		
		realpath(filename,absolute_path);
		return 0;	
	}


}
	
