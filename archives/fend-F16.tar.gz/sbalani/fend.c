#include<stdio.h>
#include <unistd.h>				// getcwd(),
#include<string.h>				// memset(),
#include<stdlib.h>				// exit(),				
#include <sys/types.h>				// open(),pid_t,
#include <sys/stat.h>				// open(),
#include <fcntl.h>				// open(),
#include <pwd.h>				// getpwuid()
#include <sys/wait.h>				// wait()
#include<sys/user.h>				// user_regs_struct,
#include<sys/ptrace.h>				// ptrace()
#include<asm/unistd.h>				// Defines system call numbers
#include "syscall_handler.h"
#include <errno.h>
#define CHILD 0



int main(int argc,char *argv[])
{
	char *homedir;
	char currdir[1024];
	char config_file[1024];
	char **newargv;
	pid_t pid;
	int fd;
	int wait_status;
	struct user_regs_struct arguments;
	int permissionDenied;
	int child_pid;

	memset(currdir,0,1024);
	memset(config_file,0,1024);

	getcwd(currdir,1024);
	/* The code to get the home directory has been taken from http://stackoverflow.com/questions/2910377/get-home-directory-in-linux-c */
	if((homedir=getenv("HOME")) == NULL)
        {
        	homedir=getpwuid(getuid())->pw_dir;
        }


	/* Uncomment this to print Current Working Directory and Home Directory
	printf("Current Working Directory %s \n",currdir);
	printf("Home directory %s \n",homedir);	
	*/

	if(argc<2)
	{
		//printf("Must provide a config file.\n");
		exit(EXIT_SUCCESS);
	}
	else if((strcmp(argv[1],"-c"))==0) 
	/* Then the next argument following -c is a config file*/
	{
		sprintf(config_file,"%s/%s",currdir,argv[2]);
		if((fd=open(config_file,O_RDONLY))==-1)
		{
			printf("Must provide a config file.\n");
			exit(EXIT_FAILURE);
		}
		else
		{		
			close(fd);
			if(argc>3)
				newargv=&argv[3];
			else
				exit(EXIT_SUCCESS);
		}
		/* Uncomment this to print the command being executed and the config file being used
		printf("Executing command %s \n",*newargv);		
		printf("Provided configuration file %s \n",config_file);	
		*/
	}
	else if((fd=open(".fendrc",O_RDONLY))!=-1)
		{
			close(fd);
			sprintf(config_file,"%s/%s",currdir,".fendrc");
			
			newargv=&argv[1];	
			/* Uncomment this to print the command being executed and the config file being used
			printf("Executing command %s \n",*newargv);	
			printf("Provided configuration file is %s \n",config_file);
			*/
		}
	else
	{
		sprintf(config_file,"%s/%s",homedir,".fendrc");
		if((fd=open(config_file,O_RDONLY))==-1)
		{
			printf("Must provide a config file.\n");
                        exit(EXIT_FAILURE);
		}
		else
		{
			close(fd);
			newargv=&argv[1];
		}
		/* Uncomment this to print the command being executed and the config file being used
		printf("Executing command %s \n",*newargv);
		printf("Provided configuration file is %s \n",config_file);
		*/
	}	
	
	/* Now we will fork child process to execute the command , while the parent process will monitor the child process system calls */
	
	if((pid=fork())==-1)
		exit(EXIT_FAILURE);
	else if(pid==CHILD)
	{
		if(ptrace(PTRACE_TRACEME,pid,NULL,NULL)<0)
              		exit(EXIT_FAILURE);
		
		//printf("Executing command:%s\n",*newargv);
		execvp(*newargv,newargv);
		/* Uncomment this for debugging
		perror("Failed to complete ptrace request: PTRACE_TRACEME");
		*/
	}
	else
	{
		do
		{
			/* Parent execution begins here */
			if((pid=wait(&wait_status))==-1)
			{
			//perror("Wait call inside parent failed");
				exit(EXIT_SUCCESS);
			}

			ptrace(PTRACE_GETREGS,pid,0L,&arguments);	
			//printf("Argument of systemcall=%d \n",arguments.orig_rax);	
			switch (arguments.orig_rax)
			{
				case __NR_open:
				{
					permissionDenied=open_handler(pid,&arguments,config_file);
				}
				break;
				case __NR_openat:
				{
					permissionDenied=openat_handler(pid,&arguments,config_file);
				}
				break;
				case __NR_stat:
				case __NR_lstat:
				{
					permissionDenied=stat_handler(pid,&arguments,config_file);
				}
				break;
				case __NR_mkdir:
				case __NR_rmdir:
				{
					/* Handlers for both system calls are the same -> mkdir_handler*/
					permissionDenied=mkdir_handler(pid,&arguments,config_file);
				}
				break;
				case __NR_chdir:
				{
					permissionDenied=chdir_handler(pid,&arguments,config_file);
				}
				break;
				case __NR_creat:
				{
					permissionDenied=creat_handler(pid,&arguments,config_file);
				}
				break;
				case __NR_faccessat:
				{	
					permissionDenied=faccessat_handler(pid,&arguments,config_file);
				}
				break;
				case __NR_access:
				{
					permissionDenied=access_handler(pid,&arguments,config_file);
				}
				break;
				case __NR_clone:
				{
					permissionDenied=clone_handler(pid,&arguments,config_file);
				}
				break;
				default:
				break;
			}
			ptrace(PTRACE_SYSCALL,pid,0L,0L);
			
		}while(/* !WIFEXITED(wait_status) && !WIFSIGNALED(wait_status)*/ pid!=-1);

		exit(EXIT_SUCCESS);
	}
			
	exit(EXIT_SUCCESS);
}

