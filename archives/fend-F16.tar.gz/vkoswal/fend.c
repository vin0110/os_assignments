#include <stdio.h>
#include <stdlib.h>
#include <glob.h>
#include <string.h>
#include <sys/ptrace.h>
#include <err.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>
#include <sys/user.h>
#include <sys/reg.h>
#include <sys/syscall.h>
#include <fcntl.h>
#include <linux/limits.h>
#include <libgen.h>
#include <fnmatch.h>
#include <sys/stat.h>
struct config
{
	char patt[500][500];
	int *perm_r;
	int *perm_w;
	int *perm_x;
	int cnt;
};
int flag=0,flagm=0,flads=0,flagr=0,flaga=0,flagu=0,flagx=0;
char* old1,*new1;
//Read and identify access rules in config file
struct config fend_configFileRead(int argc,char **argv)
{
	FILE *config_file;
	struct config c;
	if(strcmp(argv[1],"-c")!=0) 	//config file not found check cur dir then home dir
	{
		config_file=fopen(".fendrc","r");
		if(config_file==NULL)
			config_file=fopen("~/.fendrc","r");
	}
	else		//config file provided by user
	{
		config_file=fopen(argv[2],"r");
	}	
	if(config_file==NULL)	//file not valid
	{
		printf("Must provide a config file.\n");
		exit(1);
	}
	else			//file is valid
	{
		int ptr=0;	//Read file found
		char ch;
		c.cnt=0;
		int per;
		while(!feof(config_file))
		{
		  ch = fgetc(config_file);
		  if(ch == '\n')
		  {
		    c.cnt++;
		  }
		}
		//printf("-------------%d\n",c.cnt);
		c.perm_r=malloc(c.cnt*(sizeof(int)));
		c.perm_w=malloc(c.cnt*(sizeof(int)));
		c.perm_x=malloc(c.cnt*(sizeof(int)));
		fseek(config_file,0,SEEK_SET);
		while(fscanf(config_file, "%d %s",&per , c.patt[ptr])!=EOF)	
		{
			c.perm_x[ptr]=per%10;
			per=per/10;
			c.perm_w[ptr]=per%10;
			per=per/10;
			c.perm_r[ptr]=per%10;
			//printf("%s %d%d%d\n",c.patt[ptr], c.perm_r[ptr], c.perm_w[ptr], c.perm_x[ptr]);				
			ptr++;
		}
	}
	fclose(config_file);
	return c;
}

//Error function for glob
int globerr(const char *path, int eerrno)
{
	return 0; 
}

//File name identification using Glob
glob_t* fend_glob(struct config cf)
{
	int i=0,ret;
	glob_t *res;
	int len=cf.cnt;
	res=malloc(sizeof(glob_t)*len);
	//printf("%d",len);
	for(i=0;i<len;i++)	
		ret=glob(cf.patt[i], 0, globerr,&res[i]);
	return res;	
}

//Kill the child to avoid orphans/zombies
void fend_kill(pid_t pid) {
  kill(pid, SIGKILL);
  wait(NULL);
  exit(EXIT_FAILURE);
}
//Logic to read argument in read taken from stackoverflow start
char *read_string (pid_t child, unsigned long addr) {
	char *value;
	value=malloc(4096);
	int allocated = 4096, read = 0;
	unsigned long tmp =0;
	while(1) 
	{
		if (read + sizeof (tmp) > allocated) 
		{
			allocated *= 2;
			value = realloc (value, allocated);
		}
		tmp = ptrace(PTRACE_PEEKDATA, child, addr + read);
		if(errno != 0) 
		{
			value[read] = 0;
			break;
		}
		memcpy(value + read, &tmp, sizeof tmp);
		if (memchr(&tmp, 0, sizeof tmp) != NULL)
			break;
		read += sizeof tmp;
	}
	//free (value);
	return value;
}
//end
void fend_cdeny1(pid_t pid, int val,struct user_regs_struct regs)
{
	if(val==0)
	{
		regs.rsi=regs.rsi-64;
		ptrace(PTRACE_SETREGS, pid, NULL, &regs);
	}
	if(val==1)			
	{
		//printf("Make a chang here---------------Val%d-----------",val);
		//regs.rsi=regs.rsi-64;
		//close(regs.rax);
		regs.rax=-EACCES;
		ptrace(PTRACE_SETREGS, pid, NULL, &regs);
	}
}
char* realpath1(char *path, char *buff)
{
	//char rp[PATH_MAX];
	char *hm,*rp1;
	if(path[0]=='~')
	{
		hm=getenv("HOME");
		char buffer[1000];
		//rp1=malloc(sizeof(*filepath1));		
		char *tot;
		tot=strcat(hm,path+1);
		rp1=realpath(tot,buff);
		//printf("------------------%s",rp1);
	}
	else
	rp1=realpath(path,buff);
	if(rp1==NULL)
		return path;
	else
		return rp1;
}
int check_parent(char *path,struct config con,int a2,pid_t pid,int val,struct user_regs_struct regs,glob_t* res)
{
	int i,j;
	int perm_r=1,perm_w=1,perm_x=1;
	while(strcmp(path,"/")!=0)
	{
	//printf("Here for :%s\n",path);
	//printf("Val hbjvhg%d==============",val);
	for(i=0;i<con.cnt;i++)
			{
			char buff1[1000],buff2[1000];
			if(fnmatch(con.patt[i],path,FNM_NOESCAPE)==0)
			{
				perm_r=con.perm_r[i];
				perm_w=con.perm_w[i];
				perm_x=con.perm_x[i];
				if((a2 & 1)==0)			
				{
					if((a2 & 1)==0)
					{
						//printf("Access mode - O_RDONLY\n");
						if(perm_x==0)
						{
							//printf("Permission - No Exec for parent: %s Val:%d\n",path,val);
							
							fend_cdeny1(pid,val,regs);
							return 0;		
						}
					}
					else
					{
						//printf("Access mode - O_RDWR\n");
						if(perm_w==0 || perm_x==0)
						{
						//printf("Permission - No Write Exec for parent: %s Val: %d\n",path,val);
						//printf("O_RDWR");
						fend_cdeny1(pid,val,regs);
						return 0;
						}			
					}
				}
				else
				{			
					//printf("O_WRONLY");
					//printf("Access mode - O_WRONLY\n");
					if(perm_w==0 || perm_x==0)
					{
					//printf("Permission - No Write Exec for parent: %s  Val:%d\n",path,val);
					fend_cdeny1(pid,val,regs);
					return 0;						
					}
				}
			}
		}	
		path=dirname(path);
	}
return 1;					
}
void fend_cdeny(pid_t pid, int val,struct user_regs_struct regs,struct config con,glob_t *res,int a,int b)
{
	int a2,i,j;
	long a1;
	char *filepath1,*rp;
	int perm_r=1,perm_w=1,perm_x=1;
	a1=ptrace(PTRACE_PEEKUSER, pid, 8*a, NULL);
	filepath1 = read_string(pid, a1);
	a2=ptrace(PTRACE_PEEKUSER, pid, 8*b, NULL);
	char buff[1000];
	//printf("%s\n",filepath1);
	//int ret=check_parent(realpath1(filepath1,buff));
	//printf("Val ----------%d==============",val);
	for(i=0;i<con.cnt;i++)
	{
				char buff1[1000],buff2[1000];		
				if(fnmatch(con.patt[i],filepath1,FNM_NOESCAPE)==0)
				{
					perm_r=con.perm_r[i];
					perm_w=con.perm_w[i];
					perm_x=con.perm_x[i];
				}
	}	
	if(realpath(filepath1,buff)==NULL)
	{	//printf("%s doesnt exist",filepath1);
		char cwd[1024];
  		if (getcwd(cwd, sizeof(cwd)) != NULL)
		{	int ret=check_parent(cwd,con,a2,pid,val,regs,res);	}	
       			//fprintf(stdout, "Current working dir: %s\n", cwd);
  		 else
      			 perror("getcwd() error");
		perm_r=perm_w=perm_x=1;
	}
	for(i=0;i<con.cnt;i++)
	{
				char buff1[1000],buff2[1000];		
				if(fnmatch(con.patt[i],filepath1,FNM_NOESCAPE)==0)
				{
					perm_r=con.perm_r[i];
					perm_w=con.perm_w[i];
					perm_x=con.perm_x[i];
				}
			}
			//printf("%s-----------Flag:%d last bit %d\n",realpath1(filepath1,buff),a2,(a2&1));
			if((a2 & 1)==0)			
			{
				if(((a2>>1) & 1)==0)
				{
					if(perm_r==0)
					{
						//printf("O_RDONLY");
						//printf(":))))))))Val %d==============",val);
						fend_cdeny1(pid,val,regs);		
					}
					else
					{
						if(perm_w==0 || perm_r==0)
						{
							//printf("O_RDWR");
							//printf(":)))))))Val %d==============",val);
							fend_cdeny1(pid,val,regs);
						}			
					}
				}
			}
			if((a2 & 1)==1)
			{			
				//printf("O_WRONLY flag%d----",perm_w);
				if(perm_w==0)
				{
					fend_cdeny1(pid,val,regs);					
					//printf(":0000Val %d==============",val);
				}
			}
if(realpath(filepath1,buff)!=NULL)
{int ret=check_parent(realpath(filepath1,buff),con,a2,pid,val,regs,res);}		
//printf("Filename: %s Permissions: %d %d %d Arg Val: %d Val: %d\n", filepath1, perm_r,perm_w,perm_x,a2,val);

}
void fend_scheck(pid_t pid, int val,struct user_regs_struct regs,struct config con,glob_t *res,int a)
{
	int perm_r=1,perm_w=1,perm_x=1;
	int i,j,k,len=0;
	unsigned long a1;
	char* path,*filepath1;
	char buff[4096];
	a1=ptrace(PTRACE_PEEKUSER, pid, 8*a, NULL);
	path = read_string(pid, a1);
	path=dirname(path);
	path=realpath1(path,buff);
	//printf("File %s\n",path);
	//printf("%s",path);
	char *lastSlash = NULL;
	char *parent = path;
	lastSlash = strrchr(parent, '/'); // you need escape character		
	//printf("%s %s %d %d\n",lastSlash,parent,strlen(parent)-1,(strlen(lastSlash)-1));		
	if(lastSlash!=NULL)
	len=strlen(lastSlash);
	parent = strndup(parent, strlen(parent)-1 - (len - 1));
	while(strcmp(parent,lastSlash)!=0 || strlen(parent)!=strlen(lastSlash))
	{
	for(k=0;k<strlen(parent);k++)
		if(parent[k]=='/')
			break;
	if(k==strlen(parent))
		break;
	//printf("Here for :%s\n",parent);
	//printf("Val hbjvhg%d==============",val);
	for(i=0;i<con.cnt;i++)
		{
			char buff1[1000],buff2[1000];
			if(fnmatch(con.patt[i],realpath1(path,buff2),FNM_NOESCAPE)==0)
			{
				perm_r=con.perm_r[i];
				perm_w=con.perm_w[i];
				perm_x=con.perm_x[i];
				//printf("Access mode - O_RDONLY\n");
				if(perm_x==0)
				{
				//printf("Permission - No Exec for parent: %s Val:%d\n",path,val);
				if(val==1)			
				{
					regs.rax=-EACCES;
					ptrace(PTRACE_SETREGS, pid, NULL, &regs);			
				}
				}
			}
		}	
		lastSlash = strrchr(parent, '/'); // you need escape character		
		//printf("%s %s %d %d\n",lastSlash,parent,strlen(parent)-1,(strlen(lastSlash)-1));
		parent = strndup(parent, strlen(parent)-1 - (strlen(lastSlash) - 1));
		path=dirname(path);	
	}
}
void fend_mcheck(pid_t pid, int val,struct user_regs_struct regs,struct config con,glob_t *res,int a,int b)
{
	int perm_r=1,perm_w=1,perm_x=1;
	int i,j,k,a2;
	unsigned long a1;
	char* path,*filepath1;
	char buff[4096];
	a1=ptrace(PTRACE_PEEKUSER, pid, 8*a, NULL);	
	path = read_string(pid, a1);
	char *lastSlash = NULL;
	//char *lastSlash1 = NULL;
	char *parent = path;
	lastSlash = strrchr(parent, '/');
	//printf("%s",realpath1(path,buff));
	if(realpath(path,buff)==NULL)
	{	//printf("%s doesnt exist",filepath1);
		char cwd[1024];
  		if (getcwd(cwd, sizeof(cwd)) != NULL)
		{	filepath1=strcat(cwd,path);	}	
       			//fprintf(stdout, "Current working dir: %s\n", cwd);
  		 else
      			 perror("getcwd() error");
		perm_r=perm_w=perm_x=1;
	}
	if(lastSlash==NULL)
		lastSlash=path;
	parent = strndup(parent, strlen(parent)-1 - (strlen(lastSlash) - 1));
	int len=strlen(lastSlash);	
	if(val==0)
	{
		//printf("Checking %s !!",lastSlash);
		for(i=0;i<con.cnt;i++)
			{	
			char buff1[1000],buff2[1000];
			if(fnmatch(con.patt[i],path,FNM_NOESCAPE)==0 || fnmatch(con.patt[i],filepath1,FNM_NOESCAPE)==0)
			{
				//printf("Here for %s\n",lastSlash);
				perm_r=con.perm_r[i];
				perm_w=con.perm_w[i];
				perm_x=con.perm_x[i];
				//printf("%d  \n",perm_w);
				if(perm_w==0)
				{
					if(val==0)
					{
						flagm=1;
					}
					//printf("Permission - No Exec for parent: %s Val:%d\n",path,val);
				}
			}	
		}	
		//printf("Checked %s !!!",lastSlash1);
	}
	if(val==1 && flagm==1)
	{
		filepath1=read_string(pid, a1);
		//printf("--------%s--------\n",filepath1);
		rmdir(filepath1);
		regs.rax=-EACCES;
		ptrace(PTRACE_SETREGS, pid, NULL, &regs);
		flagm=0;
	}
	path= realpath1(path,buff);
	path=dirname(path);
	while(strcmp(parent,lastSlash)!=0 || strlen(parent)!=len)
	{
	//printf("lastSlash: %s\n",lastSlash);
	for(k=0;k<strlen(parent);k++)
		if(parent[k]=='/')
			break;
	if(k==strlen(parent))
		break;
	for(i=0;i<con.cnt;i++)
		{
			char buff1[1000],buff2[1000];
			if(fnmatch(con.patt[i],path,FNM_NOESCAPE)==0 || fnmatch(con.patt[i],filepath1,FNM_NOESCAPE)==0)
			{
				perm_r=con.perm_r[i];
				perm_w=con.perm_w[i];
				perm_x=con.perm_x[i];
				//printf("Access mode - O_RDONLY\n");
				if(perm_x==0 || perm_w==0)
				{
				//printf("Permission - No Exec for parent: %s Val:%d\n",path,val);
				if(val==1)			
				{
					filepath1=read_string(pid, a1);
					//printf("--------%s--------\n",filepath1);
					rmdir(filepath1);
					regs.rax=-EACCES;
					ptrace(PTRACE_SETREGS, pid, NULL, &regs);			
				}
				}
			}
		}	
		lastSlash = strrchr(parent, '/'); // you need escape character		
		//printf("%s %s %d %d\n",lastSlash,parent,strlen(parent)-1,(strlen(lastSlash)-1));
		parent = strndup(parent, strlen(parent)-1 - (strlen(lastSlash) - 1));
		path=dirname(path);	
	}
}
void fend_rmcheck(pid_t pid, int val,struct user_regs_struct regs,struct config con,glob_t *res,int a,int b)
{
	int perm_r=1,perm_w=1,perm_x=1;
	int i,j,k,a2;
	unsigned long a1;
	char* path,*filepath1;
	char buff[4096];
	a1=ptrace(PTRACE_PEEKUSER, pid, 8*a, NULL);	
	path = read_string(pid, a1);

	char *lastSlash = NULL;
	//char *lastSlash1 = NULL;
	char *parent = path;
	lastSlash = strrchr(parent, '/');
	//printf("%s",realpath1(path,buff));
	if(lastSlash==NULL)
		lastSlash=path;
	parent = strndup(parent, strlen(parent)-1 - (strlen(lastSlash) - 1));
	int len=strlen(lastSlash);	
	if(val==0)
	{
		//printf("Checking %s !!",lastSlash);
		for(i=0;i<con.cnt;i++)
			{	
			char buff1[1000],buff2[1000];
			if(fnmatch(con.patt[i],path,FNM_NOESCAPE)==0)
			{
				//printf("Here for %s\n",lastSlash);
				perm_r=con.perm_r[i];
				perm_w=con.perm_w[i];
				perm_x=con.perm_x[i];
				//printf("%d  \n",perm_w);
				if(perm_w==0)
				{
					if(val==0)
					{
						flagr=1;
					}
					//printf("Permission - No Exec for parent: %s Val:%d\n",path,val);
				}
			}	
		}	
		//printf("Checked %s !!!",lastSlash1);
	}
	if(val==1 && flagr==1)
	{
		filepath1=read_string(pid, a1);
		//printf("--------%s--------\n",filepath1);
		//rmdir(filepath1);
		regs.rax=-EACCES;
		ptrace(PTRACE_SETREGS, pid, NULL, &regs);
		flagr=0;
	}
	lastSlash = strrchr(parent, '/');
	//printf("%s",realpath1(path,buff));
	if(lastSlash==NULL)
		lastSlash=path;
	parent = strndup(parent, strlen(parent)-1 - (strlen(lastSlash) - 1));
	len=strlen(lastSlash);	
	path= realpath1(path,buff);
	path=dirname(path);
	while(strcmp(parent,lastSlash)!=0 || strlen(parent)!=len)
	{
	//printf("%s --------\n",path);
	//printf("lastSlash: %s\n",lastSlash);
	for(k=0;k<strlen(parent);k++)
		if(parent[k]=='/')
			break;
	if(k==strlen(parent))
		break;
	for(i=0;i<con.cnt;i++)
		{
			char buff1[1000],buff2[1000];
			if(fnmatch(con.patt[i],path,FNM_NOESCAPE)==0)
			{
				perm_r=con.perm_r[i];
				perm_w=con.perm_w[i];
				perm_x=con.perm_x[i];
				//printf("Access mode - O_RDONLY\n");
				if(perm_x==0 || perm_w==0)
				{
				//printf("Permission - No Exec for parent: %s Val:%d\n",path,val);
				if(val==1)			
				{
					filepath1=read_string(pid, a1);
					//printf("--------%s--------\n",filepath1);
					mkdir(filepath1,0777);
					regs.rax=-EACCES;
					ptrace(PTRACE_SETREGS, pid, NULL, &regs);			
				}
				}
			}
		}	
		lastSlash = strrchr(parent, '/'); // you need escape character		
		//printf("%s %s %d %d\n",lastSlash,parent,strlen(parent)-1,(strlen(lastSlash)-1));
		parent = strndup(parent, strlen(parent)-1 - (strlen(lastSlash) - 1));
		path=dirname(path);	
	}
}

void fend_accheck(pid_t pid, int val,struct user_regs_struct regs,struct config con,glob_t *res,int a,int b)
{
	int perm_r=1,perm_w=1,perm_x=1;
	int i,j,k,len=0,len1=0;
	unsigned long a1,a2;
	char* path;
	char buff[4096];
	a1=ptrace(PTRACE_PEEKUSER, pid, 8*a, NULL);
	a2=ptrace(PTRACE_PEEKUSER, pid, 8*b, NULL);
	path = read_string(pid, a1);
	path=realpath1(path,buff);
	//printf("````````Reached for %s\n",path);
	char *lastSlash = NULL;
	char *parent = path;
	lastSlash = strrchr(parent, '/');
	//printf("%s",realpath1(path,buff));
	if(lastSlash==NULL)
		lastSlash=path;
	parent = strndup(parent, strlen(parent)-1 - (strlen(lastSlash) - 1));
	len=strlen(lastSlash);	
	if(val==0)
	{
		//printf("Checking %s !!",lastSlash);
		for(i=0;i<con.cnt;i++)
			{	
			char buff1[1000],buff2[1000];
			if(fnmatch(con.patt[i],path,FNM_NOESCAPE)==0)
			{
				//printf("Here for %s\n",lastSlash);
				perm_r=con.perm_r[i];
				perm_w=con.perm_w[i];
				perm_x=con.perm_x[i];
				//printf("%d  \n",perm_w);
				if((a2>>1)&1==1)
				{//Read
					if(perm_r==0)
				{
					//printf("Permission - No Exec for parent: %s Val:%d\n",path,val);
					if(val==1)			
					{
						//filepath1=read_string(pid, a1);
						//printf("--------%s--------\n",path);
						flaga=1;			
					}
				}
				}	
			
				if(a2&1==1)
				{//EXEC
				if(perm_x==0)
				{
					//printf("Permission - No Exec for parent: %s Val:%d\n",path,val);
					if(val==1)			
					{
						//filepath1=read_string(pid, a1);
						//printf("--------%s--------\n",path);
						flaga=1;			
					}
				}
				}	
				if((a2>>2)&1==1)
				{//WR
				if(perm_w==0)
				{
					//printf("Permission - No Exec for parent: %s Val:%d\n",path,val);
					if(val==1)			
					{
						//filepath1=read_string(pid, a1);
						flaga=1;			
					}
				}
				}
			}	
		}	
		//printf("Checked %s !!!",lastSlash1);
	}
	if(val==1 && flaga==1)
	{
		char* filepath1=read_string(pid, a1);
		//printf("--------%s--------\n",filepath1);
		//rmdir(filepath1);
		regs.rax=-EACCES;
		ptrace(PTRACE_SETREGS, pid, NULL, &regs);
		flaga=0;
	}
	lastSlash = strrchr(parent, '/');
if(lastSlash==NULL)	
	lastSlash="";
	len=strlen(lastSlash);
	parent = strndup(parent, strlen(parent)-1 - (len-1));
	while(strcmp(parent,lastSlash)!=0 || strlen(parent)!=len)
	{
	//printf("Here for %s\n",lastSlash);
	for(k=0;k<strlen(parent);k++)
		if(parent[k]=='/')
			break;
	if(k==strlen(parent))
		break;
	for(i=0;i<con.cnt;i++)
		{
			char buff1[1000],buff2[1000];
			if(fnmatch(con.patt[i],realpath1(parent,buff2),FNM_NOESCAPE)==0)
			{
				perm_r=con.perm_r[i];
				perm_w=con.perm_w[i];
				perm_x=con.perm_x[i];
				//printf("%d  %d\n",(a2>>1)&1,perm_w);
				if((a2>>1)&1==1)
				{//Read
					if(perm_x==0)
				{
					//printf("Permission - No Exec for parent: %s Val:%d\n",path,val);
					if(val==1)			
					{
						//filepath1=read_string(pid, a1);
						//printf("--------%s--------\n",path);
						regs.rax=-EACCES;
						ptrace(PTRACE_SETREGS, pid, NULL, &regs);			
					}
				}
				}	
			
				if(a2&1==1)
				{//EXEC
				if(perm_x==0)
				{
					//printf("Permission - No Exec for parent: %s Val:%d\n",path,val);
					if(val==1)			
					{
						//filepath1=read_string(pid, a1);
						//printf("--------%s--------\n",path);
						regs.rax=-EACCES;
						ptrace(PTRACE_SETREGS, pid, NULL, &regs);			
					}
				}
				}	
				if((a2>>2)&1==1)
				{//WR
				if(perm_w==0 || perm_x==0)
				{
					//printf("Permission - No Exec for parent: %s Val:%d\n",path,val);
					if(val==1)			
					{
						//filepath1=read_string(pid, a1);
						//printf("--------%s--------\n",path);
						regs.rax=-EACCES;
						ptrace(PTRACE_SETREGS, pid, NULL, &regs);			
					}
				}
				}
			}
		}
		lastSlash = strrchr(parent, '/'); 	
		//printf("%s %s %d %d\n",lastSlash,parent,strlen(parent)-1,(strlen(lastSlash)-1));
		parent = strndup(parent, strlen(parent)-1 - (strlen(lastSlash) - 1));	
}	
}
void fend_excheck(pid_t pid, int val,struct user_regs_struct regs,struct config con,glob_t *res,int a)
{
	int perm_r=1,perm_w=1,perm_x=1;
	int i,j,k,a2;
	long a1;
	char* path,*filepath1;
	char buff[4096];
	a1=ptrace(PTRACE_PEEKUSER, pid, 8*a, NULL);	
	path = read_string(pid, a1);
	char *lastSlash = NULL;
	//char *lastSlash1 = NULL;
	char *parent = path;
	lastSlash = strrchr(parent, '/');
	//printf("-------%s---------",realpath1(parent,buff));
	if(lastSlash==NULL)
		lastSlash=path;
	parent = strndup(parent, strlen(parent)-1 - (strlen(lastSlash) - 1));
	int len=strlen(lastSlash);	
	if(val==0)
	{
		//printf("Checking %s !!",lastSlash);
		for(i=0;i<con.cnt;i++)
			{	
			char buff1[1000],buff2[1000];
			if(fnmatch(con.patt[i],path,FNM_NOESCAPE)==0)
			{
				//printf("Here for %s\n",lastSlash);
				perm_r=con.perm_r[i];
				perm_w=con.perm_w[i];
				perm_x=con.perm_x[i];
				//printf("%d  \n",perm_w);
				if(perm_x==0)
				{
					if(val==0)
					{
						flagx=1;
					}
					//printf("Permission - No Exec for parent: %s Val:%d\n",path,val);
				}
			}	
		}	
		//printf("Checked %s !!!",lastSlash1);
	}
	if(val==1 && flagx==1)
	{
		filepath1=read_string(pid, a1);
		//printf("--------%s--------\n",filepath1);
		//rmdir(filepath1);
		regs.rax=-EACCES;
		ptrace(PTRACE_SETREGS, pid, NULL, &regs);
		flagx=0;
	}
	path= realpath1(path,buff);
	path=dirname(path);
	while(strcmp(parent,lastSlash)!=0 || strlen(parent)!=len)
	{
	//printf("lastSlash: %s\n",lastSlash);
	for(k=0;k<strlen(parent);k++)
		if(parent[k]=='/')
			break;
	if(k==strlen(parent))
		break;
	for(i=0;i<con.cnt;i++)
		{
			char buff1[1000],buff2[1000];
			if(fnmatch(con.patt[i],path,FNM_NOESCAPE)==0)
			{
				perm_r=con.perm_r[i];
				perm_w=con.perm_w[i];
				perm_x=con.perm_x[i];
				//printf("Access mode - O_RDONLY\n");
				if(perm_x==0)
				{
				//printf("Permission - No Exec for parent: %s Val:%d\n",path,val);
				if(val==1)			
				{
					filepath1=read_string(pid, a1);
					//printf("--------%s--------\n",filepath1);
					//rmdir(filepath1);
					flagx=1;
					regs.rax=-EACCES;
					ptrace(PTRACE_SETREGS, pid, NULL, &regs);			
				}
				}
			}
		}	
		lastSlash = strrchr(parent, '/'); // you need escape character		
		//printf("%s %s %d %d\n",lastSlash,parent,strlen(parent)-1,(strlen(lastSlash)-1));
		parent = strndup(parent, strlen(parent)-1 - (strlen(lastSlash) - 1));
		path=dirname(path);	
	}
}
void fend_recheck(pid_t pid, int val,struct user_regs_struct regs,struct config con,glob_t *res,int a,int b)
{
	int perm_r=1,perm_w=1,perm_x=1;
	int i,j,k,a2,a4;
	long a1,a3;
	char* path,*newpath,*oldpath,*filepath;
	char buff[4096];
	a1=ptrace(PTRACE_PEEKUSER, pid, 8*a, NULL);
	a2=ptrace(PTRACE_PEEKUSER, pid, 8*RSI, NULL);	
	path = read_string(pid, a1);
	filepath = read_string(pid, a1);
	path=realpath1(path,buff);
	char *lastSlash = NULL;
	char *lastSlash1 = NULL;
	char *parent = path;
	lastSlash = strrchr(parent, '/');
	//printf("------------------%s=-=====",realpath1(filepath,buff));
	for(i=0;i<con.cnt;i++)
			{	
			char buff1[1000],buff2[1000];
			if(fnmatch(con.patt[i],filepath,FNM_NOESCAPE)==0 || fnmatch(con.patt[i],realpath1(filepath,buff),FNM_NOESCAPE)==0)
			{
				//printf("Here for %s\n",filepath);
				perm_r=con.perm_r[i];
				perm_w=con.perm_w[i];
				perm_x=con.perm_x[i];
				//printf("---------%d  \n",perm_w);
				if(perm_w==0)
				{
					if(val==0)
					{
						flag=1;
					}
					//printf("Permission - No Exec for parent: %s Val:%d\n",path,val);
				}
			}	
		}
	if(lastSlash==NULL)
		lastSlash="";
	parent = strndup(parent, strlen(parent)-1 - (strlen(lastSlash) - 1));
	if(val==0)
	{
		lastSlash1=lastSlash+1;
		//printf("Checking %s !!",lastSlash1);
		for(i=0;i<con.cnt;i++)
			{	
			char buff1[1000],buff2[1000];
			if(fnmatch(con.patt[i],lastSlash1,FNM_NOESCAPE)==0)
			{
				//printf("Here for %s\n",realpath1(lastSlash1,buff));
				perm_r=con.perm_r[i];
				perm_w=con.perm_w[i];
				perm_x=con.perm_x[i];
				//printf("%d  \n",perm_w);
				if(perm_w==0)
				{
					if(val==0)
					{
						//printf("Reached Here. %s ",path);
						//printf("!!!!!!!!!!!%s    %s    %d\n\n",old1,new1,val);
						flag=1;
					}
					//printf("Permission - No Exec for parent: %s Val:%d\n",path,val);
				}
			}	
		}	
		//printf("Checked %s !!!",lastSlash1);
	}
	else
	{
	while(strcmp(parent,lastSlash)!=0 || strlen(parent)!=strlen(lastSlash))
	{
	for(k=0;k<strlen(parent);k++)
		if(parent[k]=='/')
			break;
	if(k==strlen(parent))
		break;
	for(i=0;i<con.cnt;i++)
	{
			char buff1[1000],buff2[1000];
			if(fnmatch(con.patt[i],realpath1(parent,buff2),FNM_NOESCAPE)==0)
			{
				//printf("Here for %s\n",parent);
				perm_r=con.perm_r[i];
				perm_w=con.perm_w[i];
				perm_x=con.perm_x[i];
				//printf("%d  \n",perm_w);
				if(perm_w==0 || perm_x==0)
				{
					if(val==0)
					{
						//printf("Reached Here.");
						flag=1;
					}
					//printf("Permission - No Exec for parent: %s Val:%d\n",path,val);
				}
			}	
		}	
		lastSlash = strrchr(parent, '/'); 	
		//printf("%s %s %d %d\n",lastSlash,parent,strlen(parent)-1,(strlen(lastSlash)-1));
		parent = strndup(parent, strlen(parent)-1 - (strlen(lastSlash) - 1));	
}
}	
}
void fend_uncheck(pid_t pid, int val,struct user_regs_struct regs,struct config con,glob_t *res,int a)
{
	int perm_r=1,perm_w=1,perm_x=1;
	int i,j,k,a2,a4;
	long a1,a3;
	char* path,*parent,*oldpath,*filepath;
	char buff[4096];
	a1=ptrace(PTRACE_PEEKUSER, pid, 8*a, NULL);
	a2=ptrace(PTRACE_PEEKUSER, pid, 8*RSI, NULL);	
	path = read_string(pid, a1);
	path=realpath1(path,buff);
	parent=dirname(path);
	//printf("------Parent-----%s\n",parent);
	if(parent!=NULL)
	for(i=0;i<con.cnt;i++)
		{	
			char buff1[1000],buff2[1000];
			if(fnmatch(con.patt[i],parent,FNM_NOESCAPE)==0)
			{
				//printf("Here for %s\n",realpath1(lastSlash1,buff));
				perm_r=con.perm_r[i];
				perm_w=con.perm_w[i];
				perm_x=con.perm_x[i];
				//printf("%d  \n",perm_w);
				if(perm_w==0)
				{
					if(val==0)
					{//printf("Reached Here. %s ",parent); 
					flagu=1;}
						//printf("!!!!!!!!!!!%s    %s    %d\n\n",old1,new1,val);
					if(val==1 && flagu==1)
					{	regs.rax=-EACCES;
						flagu=0;
						ptrace(PTRACE_SETREGS, pid, NULL, &regs);
					}
					//printf("Permission - No Exec for parent: %s Val:%d\n",path,val);
				}
			}	
		}	
		
}
void fend_sys_handle(pid_t pid, glob_t *res, struct config con,int val,int argc,char** argv)
{

	struct user_regs_struct regs;
	if(ptrace(PTRACE_GETREGS, pid, NULL, &regs) < 0)
		err(EXIT_FAILURE, "Failed to PTRACE_GETREGS:");
	//printf("System Call: %lld Return val: %lld  Val: %d\n\n",regs.orig_rax,regs.rax,val);
	if(regs.orig_rax==__NR_open)
	{
		//printf("System Call: %lld Return val: %lld  Val: %d\n\n",regs.orig_rax,regs.rax,val);
		fend_cdeny(pid,val,regs,con,res,RDI,RSI);
	}
	if(regs.orig_rax==__NR_openat)
	{
		//printf("System Call: %lld Return val: %lld  Val: %d\n\n",regs.orig_rax,regs.rax,val);
		fend_cdeny(pid,val,regs,con,res,RSI,RDX);
	}
	if(regs.orig_rax==__NR_stat || regs.orig_rax==__NR_lstat)
	{
		//printf("System Call: %lld Return val: %lld  Val: %d\n\n",regs.orig_rax,regs.rax,val);
		fend_scheck(pid,val,regs,con,res,RDI);
	}
	if(regs.orig_rax==__NR_newfstatat)
	{
		//printf("System Call: %lld Return val: %lld  Val: %d\n\n",regs.orig_rax,regs.rax,val);
		fend_scheck(pid,val,regs,con,res,RSI);
	}
	if(regs.orig_rax==__NR_mkdir)
	{
		
		//printf("System Call: %lld Return val: %lld  Val: %d\n\n",regs.orig_rax,regs.rax,val);
		fend_mcheck(pid,val,regs,con,res,RDI,RSI);
	}
	if(regs.orig_rax==__NR_mkdirat)
	{
		
		//printf("System Call: %lld Return val: %lld  Val: %d\n\n",regs.orig_rax,regs.rax,val);
		fend_mcheck(pid,val,regs,con,res,RSI,RSI);
	}
	if(regs.orig_rax==__NR_rmdir)
	{
		
		//printf("System Call: %lld Return val: %lld  Val: %d\n\n",regs.orig_rax,regs.rax,val);
		fend_rmcheck(pid,val,regs,con,res,RDI,RSI);
	}
	if(regs.orig_rax==__NR_access)
	{
		
		//printf("System Call: %lld Return val: %lld  Val: %d\n\n",regs.orig_rax,regs.rax,val);
		fend_accheck(pid,val,regs,con,res,RDI,RSI);
	}
	if(regs.orig_rax==__NR_faccessat)
	{
		
		//printf("System Call: %lld Return val: %lld  Val: %d\n\n",regs.orig_rax,regs.rax,val);
		fend_accheck(pid,val,regs,con,res,RSI,RDX);
	}
	if(regs.orig_rax==__NR_rename)
	{	
		int i=0;
		char *src,*dest;
		char buff[4096];
		if(val==1)			
		{
		//printf("Here tooo \nFlag%d\n",flag);
		if(flag==1)
		{
			regs.rax=-EACCES;
			ptrace(PTRACE_SETREGS, pid, NULL, &regs);
			for(i=0;i<argc;i++)
		{
			if(strcmp(argv[i],"mv")==0)
			{	src=argv[i+1];
				dest=argv[i+2];
			}
		}
			int len=strlen(dest)-4;
			if(dest[len]!='.')
			{
			char* dir="/"; 
			dest=strcat(dest,dir);
			dest=strcat(dest,src);
			}
			rename(dest,src);
			flag=0;
		}
		}
		//printf("System Call: %lld Return val: %lld  Val: %d\n\n",regs.orig_rax,regs.rax,val);
		fend_recheck(pid,val,regs,con,res,RDI,RSI);
	}
	if(regs.orig_rax==__NR_renameat)
	{	
		int i=0;
		char *src,*dest;
		char buff[4096];
		if(val==1)			
		{
		//printf("Here tooo \nFlag%d\n",flag);
		if(flag==1)
		{
			regs.rax=-EACCES;
			ptrace(PTRACE_SETREGS, pid, NULL, &regs);
			for(i=0;i<argc;i++)
		{
			if(strcmp(argv[i],"mv")==0)
			{	src=argv[i+1];
				dest=argv[i+2];
			}
		}
			int len=strlen(dest)-4;
			if(dest[len]!='.')
			{
			char* dir="/"; 
			dest=strcat(dest,dir);
			dest=strcat(dest,src);
			}
			rename(dest,src);
			flag=0;
		}
		}
		//printf("System Call: %lld Return val: %lld  Val: %d\n\n",regs.orig_rax,regs.rax,val);
		fend_recheck(pid,val,regs,con,res,RSI,R10);
	}
	if(regs.orig_rax==__NR_unlink)
	{
		
		//printf("System Call: %lld Return val: %lld  Val: %d\n\n",regs.orig_rax,regs.rax,val);
		fend_uncheck(pid,val,regs,con,res,RDI);
	}
	if(regs.orig_rax==__NR_unlinkat)
	{
		
		//printf("System Call: %lld Return val: %lld  Val: %d\n\n",regs.orig_rax,regs.rax,val);
		fend_uncheck(pid,val,regs,con,res,RSI);
	}
	if(regs.orig_rax==__NR_execve)
	{
		
		//printf("System Call: %lld Return val: %lld  Val: %d\n\n",regs.orig_rax,regs.rax,val);
		fend_excheck(pid,val,regs,con,res,RDI);
	}
	//return NULL;
}

pid_t fend_trace(int argc, char** argv,glob_t *res,struct config con)
{
	/*Check for syscalls and check if the child is trying to access something it has no permission for
	First fork child then allow ptracing
	As parent check if syscall is read write or exec
	If its true then check permissions
	You will need the file name which u can check in the list returned by glob
	After checking if there is no perm return EACCESS error using perror
	*/
	int p,i,j=1,ret;
	pid_t pid,r;
	if(strcmp(argv[1],"-c")!=0)
		p=1;
	else
		p=3;
//Command retrieval
	char *cmd[argc-p+1];
	cmd[0]=argv[p];
	for(i=p+1;i<argc;i++)
	{
		//cmd[j]=malloc(sizeof(char)*sizeof(strlen(argv[i])));
		cmd[j]=argv[i];
		j++;
	}
	cmd[j]=NULL;
//Child Creation
	pid = fork();
	if(pid == -1)
    		err(EXIT_FAILURE, "Error on fork: ");
	
	if(pid == 0)	//Child
	{	
		ptrace(PTRACE_TRACEME, 0, NULL, NULL);
		if(execvp(cmd[0],cmd)<0)
      			err(EXIT_FAILURE, "Execvp error:");
	
	}
	else	//Parent
	{
		wait(NULL);
		r=pid;
	}
	return r;
}

void fend_trace2(pid_t pid,glob_t *res,struct config con,int val,int argc,char** argv)
{
	int status;			 
	int i;
	if(ptrace(PTRACE_SYSCALL, pid, NULL, NULL) < 0) 
	{
	 	if(errno == ESRCH) 
		{
	      		waitpid(pid, &status, __WALL | WNOHANG);
	     		fend_kill(pid);
	    	}
		else 
		{
	      		err(EXIT_FAILURE, "Failed to PTRACE_SYSCALL:");
	    	}
	}
	wait(&status);	
	if(WIFEXITED(status))
    		exit(EXIT_SUCCESS);
	if(WIFSTOPPED(status)) 
	{
		/*Sys call allowance check and Continue logic*/
		//val=!val;		
		fend_sys_handle(pid,res,con,val,argc,argv);

	}
}

int main(int argc,char **argv)
{
	struct config con=fend_configFileRead(argc,argv);
	int len=con.cnt;
	glob_t* res=fend_glob(con);
	pid_t pid=fend_trace(argc,argv,res,con);
	int val=0;
	/*for(int i=0;i<con.cnt;i++)
		for (int j = 0; j < res[i].gl_pathc; j++)
			printf("%s   %d %d %d\n",res[i].gl_pathv[j],con.perm_r[i],con.perm_w[i],con.perm_x[i]);
*/
	while(1)
	{
		fend_trace2(pid,res,con,val,argc,argv);
		val=!val;
	}
}
