#include<stdio.h>
#include<stdlib.h>
#include<err.h>
#include<unistd.h>
#include<sys/types.h>
#include<pwd.h>
#include<errno.h>
#include<memory.h>
#include<glob.h>
#include<sys/ptrace.h>
#include<sys/user.h>
#include<asm/ptrace.h>
#include<sys/wait.h>
#include<asm/unistd.h>
#include<signal.h>
#include<sys/time.h>
#include<sys/reg.h>
#include<limits.h>
#include<sys/stat.h>
#include <fnmatch.h>

extern int errno;
int filetobecreated = 0;
int renamenotallowed = 0;
int renameatnotallowed = 0;
int mkdirnotallowed = 0;
int mkdiratnotallowed = 0;
int rmdirnotallowed = 0;
int execvenotallowed = 0;
char* pattern[500];

struct configfilename {
  char *conffilename;
  char **nextarg;
  int args;
};

struct globline{
  glob_t globl;
  int readperm;
  int writeperm;
  int execperm;
  char *pattern;
};

struct sandbox {
  pid_t child;
  const char *progname;
};

struct sandb_syscall {
  int syscall;
  void (*callback)(struct sandbox*, struct user_regs_struct *regs);
};

struct globline *line_array;

//function to find conf file name and check its existence
void confname_init(struct configfilename *cfile, int argc, char **argv) {
  char currentworkingdir[2048];  //variable to hold current working directory
  struct passwd *pw;
  char* alternateconf=".fendrc";
  
  if(!strcmp(argv[1],"-c") && argv[2] == NULL){
    errx(EXIT_FAILURE, "[FAILURE] fend [-c config] <command [args ...]> ");
  }
  
  if(!strcmp(argv[1],"-c") && argv[2] != NULL){
    if(access(argv[2], F_OK)!=-1){
      cfile->conffilename=argv[2];
      cfile->nextarg=argv+3;
      cfile->args=argc-3; 
      return;
    }
    else
       errx(EXIT_FAILURE,"[FAILURE] No such file or directory : %s \n",argv[2]);
  }
  else {
    if (getcwd(currentworkingdir, sizeof(currentworkingdir)) != NULL){
      char * conffilename = (char *) malloc(1 + strlen(currentworkingdir) + 1 + strlen(alternateconf) );
      strcpy(conffilename, currentworkingdir);
      strcat(conffilename, "/");
      strcat(conffilename, alternateconf);
     
      if(access(conffilename, F_OK)!=-1){
        cfile->conffilename=conffilename;
        cfile->nextarg=argv+1;
        cfile->args=argc-1;
        return;        
      }     
    }
    else
      errx(EXIT_FAILURE,"getcwd() error");   
 
   pw=getpwuid(getuid());
   const char *homedir = pw->pw_dir;

   char * conffilename = (char *) malloc(1 + strlen(homedir) + 1 + strlen(alternateconf) );
   strcpy(conffilename, homedir);
   strcat(conffilename, "/");
   strcat(conffilename, alternateconf);
     
   if(access(conffilename, F_OK)!=-1){
     cfile->conffilename=conffilename;
     cfile->nextarg=argv+1;
     cfile->args=argc-1;
     return;        
    }
    else
      errx(EXIT_FAILURE,"Must provide a config file.");   
  }
}

// function to count the number of lines in the file called filename                                    
int countlines(char *filename) {
  int charretrieved=0; int lines=0;
  FILE *filepointer = fopen(filename,"r");

  if (filepointer == NULL)
   return 0;

  while(!feof(filepointer)) {
    charretrieved = fgetc(filepointer);
    if(charretrieved == '\n')
    {
      lines++;
    }
  }
  fclose(filepointer);
  return lines;
}

//Wrapper function around realpath to obtain realpath even if path looks like ~/foo
//Function start - Referred from http://www.dreamincode.net/forums/topic/218601-realpath-and-tilde/
char *realpathEx(const char *filepath, char *buffer) {
  char *home;
  char *realpathh;
  if (*filepath=='~' && (home = getenv("HOME"))) {
     char stemp[PATH_MAX];
     realpathh=realpath(strcat(strcpy(stemp, home), filepath+1), buffer);
  } else {
     realpathh=realpath(filepath, buffer);
  }
  if (realpathh == NULL)
    return (char *)filepath;
  else 
    return realpathh;
}
//Function end - Referred from http://www.dreamincode.net/forums/topic/218601-realpath-and-tilde/


//function to check perms for stat/lstat system call -  check execute perms on parent and all other ancestors
int check_perms_for_stat(char * filepath, struct globline **line_array, int conffilelinecount){
 
  char buff1[PATH_MAX];
  char buff2[PATH_MAX];
  char *lastslash=NULL;
  char * parent=NULL;
  char * absfpath; 

  if(realpath(realpathEx(filepath,buff2),buff1) == NULL && errno==ENOENT) {
    return 1;
  }
  
  absfpath = realpathEx(filepath,buff2);
  lastslash = strrchr(absfpath,'/');
  parent=strndup(absfpath,strlen(absfpath) - (strlen(lastslash)));
  
  return ((strlen(parent)==0) ? 1 : check_parent_perms(parent,3,line_array, conffilelinecount));
}

//function to check perms for mkdir system call
int check_perms_for_mkdir(char * filepath, struct globline **line_array, int conffilelinecount){
  char buff1[PATH_MAX];
  char buff2[PATH_MAX];
  char * globpath;
  int i,j, matched = 0;
  struct globline match;
  char *lastslash=NULL;
  char * parent=NULL;
  char * absfpath; 
  char currentworkingdir[2048];  //variable to hold current working directory


  for(j=0; j<conffilelinecount; j++){
    if (fnmatch(pattern[j],realpathEx(filepath,buff2),FNM_NOESCAPE)==0){
      match = (*line_array)[j]; matched=1;
      //printf("matched %d for filepath %s \n",matched,filepath); 
    }
  }

  if(realpath(realpathEx(filepath,buff2),buff1) == NULL && errno==ENOENT)
    if(matched==0) 
      return 1; 
    else 
      return match.writeperm;
            //end of non existent file crap
  
  absfpath = realpathEx(filepath,buff2);
  lastslash = strrchr(absfpath,'/');
  parent=strndup(absfpath,strlen(absfpath) - (strlen(lastslash)));
  
  return ((strlen(parent)==0) ? 1 : check_parent_perms(parent,3,line_array, conffilelinecount) && check_parent_perms(parent,1,line_array, conffilelinecount)); //since mkdir needs write and execute on all its ancestors
}

//function to check perms for access/faccessat system call
//mode 0,1,2 stand for exec. write and read respectively
int check_perms_for_access(char * filepath, struct globline **line_array, int conffilelinecount, int mode){
  char buff1[PATH_MAX];
  char buff2[PATH_MAX];
  char * globpath;
  int i,j, matched = 0;
  struct globline match;
  char *lastslash=NULL;
  char * parent=NULL;
  char * absfpath; 
  char currentworkingdir[2048];  //variable to hold current working directory

  for(j=0; j<conffilelinecount; j++){
    if (fnmatch(pattern[j],realpathEx(filepath,buff2),FNM_NOESCAPE)==0){
      match = (*line_array)[j]; matched=1; 
    }
  }

  if(realpath(realpathEx(filepath,buff2),buff1) == NULL && errno==ENOENT)
    if(matched==0) 
      return 1; 
    else 
      switch(mode){
      case 0 :  //exec mode
        return match.execperm;
        break;
      case 1 : //Write mode
        return match.writeperm;
        break;
      case 2 : //Read mode
        return match.readperm && match.writeperm;
        break;
      default : return 0;
      }      //end of non existent file crap
   
  absfpath = realpathEx(filepath,buff2);
  lastslash = strrchr(absfpath,'/');
  parent=strndup(absfpath,strlen(absfpath) - (strlen(lastslash))); 
 
   if(matched==0) {
    switch(mode) {
      case 0 :  //exec mode
        return 1 && ((strlen(parent)==0) ? 1 : check_parent_perms(parent,3,line_array, conffilelinecount));
        break;
      case 1 : //Write only mode
        return 1 && ((strlen(parent)==0) ? 1 : check_parent_perms(parent,3,line_array, conffilelinecount) && check_parent_perms(parent,1,line_array, conffilelinecount));
        break;
      case 2 : //Read mode
        return 1 && ((strlen(parent)==0) ? 1 : check_parent_perms(parent,3,line_array, conffilelinecount));
        break;       
      default : return 0;
    }
  }
     
  //else if matched=1
  switch(mode) {
    case 0 :  //exec mode
      if(match.execperm)
        return 1 && ((strlen(parent)==0) ? 1 : check_parent_perms(parent,3,line_array, conffilelinecount));
        break;
    case 1 : //write mode
      if(match.writeperm)
        return 1 && ((strlen(parent)==0) ? 1 : check_parent_perms(parent,3,line_array, conffilelinecount) && check_parent_perms(parent,1,line_array, conffilelinecount));
        break;
    case 2 : //Read mode
      if(match.readperm)
        return 1 && ((strlen(parent)==0) ? 1 : check_parent_perms(parent,3,line_array, conffilelinecount));
        break;        
    default : return 0;
    
  }

  return 0;
}


//check perms for rename system call
//checks write perms for source filepath and its ancestors (destination write perms are taken care by stat and access)
int check_perms_for_rename(char * filepath, struct globline **line_array, int conffilelinecount){
  char buff1[PATH_MAX];
  char buff2[PATH_MAX];
  char * globpath;
  int i,j, matched = 0;
  struct globline match;
  char *lastslash=NULL;
  char * parent=NULL;
  char * absfpath; 
  char currentworkingdir[2048];  //variable to hold current working directory

  for(j=0; j<conffilelinecount; j++){
    if (fnmatch(pattern[j],realpathEx(filepath,buff2),FNM_NOESCAPE)==0){
      match = (*line_array)[j]; matched=1; 
    }
  }

  if(realpath(realpathEx(filepath,buff2),buff1) == NULL && errno==ENOENT)
    if(matched==0) 
      return 1; 
    else 
        return match.writeperm;
   
  absfpath = realpathEx(filepath,buff2);
  lastslash = strrchr(absfpath,'/');
  parent=strndup(absfpath,strlen(absfpath) - (strlen(lastslash)));
  
  if(matched==0) {
    return 1 && ((strlen(parent)==0) ? 1 : check_parent_perms(parent,1,line_array, conffilelinecount));
  }
  else {   
      if(match.writeperm)
        return 1 && ((strlen(parent)==0) ? 1 : check_parent_perms(parent,3,line_array, conffilelinecount) && check_parent_perms(parent,1,line_array, conffilelinecount));
      else 
        return 0;
  }
}


//function to check perms for unlink/unlinkat system call -  check write perms on parent directory
int check_perms_for_unlink(char * filepath, struct globline **line_array, int conffilelinecount){
  char buff1[PATH_MAX];
  char buff2[PATH_MAX];
  char * globpath;
  int i,j, matched = 0;
  struct globline match;
  char *lastslash=NULL;
  char * parent=NULL;
  char * absfpath; 
  char currentworkingdir[2048];  //variable to hold current working directory

  absfpath = realpathEx(filepath,buff2);
  lastslash = strrchr(absfpath,'/');
  parent=strndup(absfpath,strlen(absfpath) - (strlen(lastslash)));

  for(j=0; j<conffilelinecount; j++){
    if (fnmatch(pattern[j],realpathEx(parent,buff2),FNM_NOESCAPE)==0){
      match = (*line_array)[j]; matched=1; 
    }
  }

  if(matched==0) 
    return 1; 
  else
    return match.writeperm;
}


//function to check perms for execve system call -  check exec perms on current path
int check_perms_for_execve(char * filepath, struct globline **line_array, int conffilelinecount){
  char buff1[PATH_MAX];
  char buff2[PATH_MAX];
  char * globpath;
  int i,j, matched = 0;
  struct globline match;
  char *lastslash=NULL;
  char * parent=NULL;
  char * absfpath; 
  char currentworkingdir[2048];  //variable to hold current working directory


  for(j=0; j<conffilelinecount; j++){
    if (fnmatch(pattern[j],realpathEx(filepath,buff2),FNM_NOESCAPE)==0){
      match = (*line_array)[j]; matched=1; //printf("matched %d \n", matched); 
    }
  }

  if(realpath(realpathEx(filepath,buff2),buff1) == NULL && errno==ENOENT)
    if(matched==0) 
      return 1; 

  return match.execperm;
}


//checks perms for open/openat system call
//match command line args glob patterns, function returns 0 if access needs to be denied and 1 if allowed/no match
int match_glob_for_file(char * filepath, int mode, struct globline **line_array, int conffilelinecount, int filetobecreated){
  char buff1[PATH_MAX];
  char buff2[PATH_MAX];
  char * globpath;
  int i,j, matched = 0;
  struct globline match;
  char *lastslash=NULL;
  char * parent=NULL;
  char * absfpath; 
  char currentworkingdir[2048];  //variable to hold current working directory


  for(j=0; j<conffilelinecount; j++){
    if (fnmatch(pattern[j],realpathEx(filepath,buff2),FNM_NOESCAPE)==0){
      match = (*line_array)[j]; matched=1; 
    }
  }

  if(realpath(realpathEx(filepath,buff2),buff1) == NULL && errno==ENOENT)
    if(matched==0) 
      return 1; 
    else 
      switch(mode){
      case 0 :  //Read  only mode
        return match.readperm;
        break;
      case 1 : //Write only mode
        return match.writeperm;
        break;
      case 2 : //ReadWrite mode
        return match.readperm && match.writeperm;
        break;
      case 3 : //exec mode
        return match.execperm;
        break;       
      }      //end of non existent file crap
   
  absfpath = realpathEx(filepath,buff2);
  lastslash = strrchr(absfpath,'/');
  parent=strndup(absfpath,strlen(absfpath) - (strlen(lastslash))); 
    
  if(matched==0) {
    switch(mode) {
      case 0 :  //Read  only mode
        return 1 && ((strlen(parent)==0) ? 1 : check_parent_perms(parent,3,line_array, conffilelinecount));
        break;
      case 1 : //Write only mode
        return 1 && ((strlen(parent)==0) ? 1 : check_parent_perms(parent,3,line_array, conffilelinecount) && check_parent_perms(parent,1,line_array, conffilelinecount));
        break;
      case 2 : //ReadWrite mode
        return 1 && ((strlen(parent)==0) ? 1 : check_parent_perms(parent,3,line_array, conffilelinecount) && check_parent_perms(parent,1,line_array, conffilelinecount));
        break;       
      default : return 0;
    }
  }
     
  //else if matched=1
  switch(mode) {
    case 0 :  //Read only mode
      if(match.readperm)
        return 1 && ((strlen(parent)==0) ? 1 : check_parent_perms(parent,3,line_array, conffilelinecount));
        break;
    case 1 : //Write only mode
      if(match.writeperm)
        return 1 && ((strlen(parent)==0) ? 1 : check_parent_perms(parent,3,line_array, conffilelinecount) && check_parent_perms(parent,1,line_array, conffilelinecount));
        break;
    case 2 : //ReadWrite mode
      if(match.writeperm && match.readperm)
        return 1 && ((strlen(parent)==0) ? 1 : check_parent_perms(parent,3,line_array, conffilelinecount) && check_parent_perms(parent,1,line_array, conffilelinecount));
        break;      
  }

 return 0;
}

//recursive function to check parent permissions depending on mode specified
//modes 0,1,2 and 3 are read only, write only, read write and exec respectively
int check_parent_perms(char * filepath, int mode, struct globline **line_array, int conffilelinecount){
  char buff1[PATH_MAX];
  char buff2[PATH_MAX];
  char * globpath;
  int i,j, matched = 0;
  struct globline match;
  char *lastslash=NULL;
  char * parent=NULL;
  char * absfpath;  

  for(j=0; j<conffilelinecount; j++)
    if (fnmatch(pattern[j],realpathEx(filepath,buff2),FNM_NOESCAPE)==0)
      {
	match = (*line_array)[j]; matched=1;
       }

  absfpath = realpathEx(filepath,buff2);
  lastslash = strrchr(absfpath,'/');
  parent=strndup(absfpath,strlen(absfpath) - (strlen(lastslash)));
  
  if(matched==0)
    return 1 && ((strlen(parent)==0) ? 1 : check_parent_perms(parent,mode,line_array, conffilelinecount));
  //else if matched=1
  switch(mode) {
    case 0 :  //Read only mode
      if(match.readperm)
        return 1 && ((strlen(parent)==0) ? 1 : check_parent_perms(parent,mode,line_array, conffilelinecount)); break;
    case 1 : //Write only mode
      if(match.writeperm)
        return 1 && ((strlen(parent)==0) ? 1 : check_parent_perms(parent,mode,line_array, conffilelinecount)); break;
    case 2 : //ReadWrite mode
      if(match.writeperm && match.readperm)
        return 1 && ((strlen(parent)==0) ? 1 : check_parent_perms(parent,mode,line_array, conffilelinecount)); break;
    case 3 : //Execute mode
      if(match.execperm)
        return 1 && ((strlen(parent)==0) ? 1 : check_parent_perms(parent,mode,line_array, conffilelinecount)); break;
  }
  return 0;
}



//function to load configuration file into array of globline type structs
void conf_load(struct configfilename *cfile, struct globline **line_array){
  FILE *fp = fopen(cfile->conffilename,"r");
  int ch=0; int lines=0; int globret; int i; int j;
  glob_t res;
  char * patt; char * pch;
  int pch1;
  struct globline match;
  patt = malloc(sizeof(char)*500);
  pch = malloc(sizeof(char)*500);
  if (fp == NULL)
   return;
	
  if (fp != NULL) {

    while(fscanf(fp,"%s %s",pch,patt)!=EOF){
      (*line_array)[lines].readperm=pch[0]-48;
      (*line_array)[lines].writeperm=pch[1]-48;
      (*line_array)[lines].execperm=pch[2]-48;
      pattern[lines] = patt;
      lines++; patt = malloc(sizeof(char)*500);
    }
    fclose(fp);

/*
    for(j=0;j<lines;j++)
      printf("%d %d %d %s \n",(*line_array)[j].readperm,(*line_array)[j].writeperm, (*line_array)[j].execperm, pattern[j]); */ 
  }
  else {
    errx(EXIT_FAILURE,"[FAILURE] Failured while trying to handle file : %s \n", cfile->conffilename);
  }
}

void sandb_kill(struct sandbox *sandb) {
  kill(sandb->child, SIGKILL);
  wait(NULL);
  exit(EXIT_FAILURE);
}


/* function start - from stack overflow; Referred from - http://stackoverflow.com/questions/10385784/how-to-get-a-char-with-ptrace */
char *read_string (pid_t child, unsigned long addr) {
  char *val = malloc(4096);
  //read to keep track of how much is read till now
  int allocated = 4096, read = 0;
  unsigned long tmp =0;
  while(1) {
    if (read + sizeof (tmp) > allocated) {
      allocated *= 2;
      val = realloc (val, allocated);
    }
    tmp = ptrace(PTRACE_PEEKDATA, child, addr + read);
    if(errno != 0) {
      val[read] = 0; //store 0 at the last location read so far
      break;
    }
    memcpy(val + read, &tmp, sizeof tmp); //copy from tmp source to val+read
    if (memchr(&tmp, 0, sizeof tmp) != NULL)
      break;
    read += sizeof tmp;
 }
  //free (val);
  return val;
}
/* function end - from stack overflow */



//Function returns 0,1,2 for read, write, read-write modes respctively for open system call depending on flags like O_RDONLY etc
int open_mode(int flags){
  int flagscopy1, flagscopy2, position, result;
  flagscopy1=flags;
  flagscopy2=flags;

  position=1; //to check if bit 1 is set; implies read-write mode
  result = flagscopy1 >> (position);

  if(result & 1)
    return 2;

  position = 0;
  result = flagscopy2 >> (position); 
  //returns 0 if bit 0 is unset; implies read only mode; returns 1 if bit is set; implies write only mode
  if(result & 1)
    return 1;
  else return 0;
}

//Function returns 0,1,2 for execute, write and read mode respctively for access system call depending on flags like W_OK etc
int access_mode(int flags){
  int flagscopy1, flagscopy2, flagscopy3, position, result;
  flagscopy1=flags;
  flagscopy2=flags;
  flagscopy3=flags;

  position=2; //to check if bit 1 is set; implies read-write mode
  result = flagscopy1 >> (position);

  if(result & 1)
    return 2; //implies R_OK mode

  position = 1;
  result = flagscopy2 >> (position);
 
  if(result & 1)
    return 1; //implies W_OK mode

  position = 0;
  result = flagscopy3 >> (position);

  if(result & 1)
    return 0; //implies X_OK mode
}


//Function returns if O_CREAT flag is set or not for open system call
int check_modify_flags_for_create_mode(int flags){
  int flagscopy1, position, result;
  flagscopy1=flags;

  position=6; //to check if bit 1 is set; implies create mode
  result = flagscopy1 >> (position);

  if(result & 1)
    flags=flags-64;

  return flags;
}

void sandb_handle_syscall(struct sandbox *sandb,struct globline **line_array, int conffilelinecount, int entryexit) {
  int i;
  struct user_regs_struct regs;
  unsigned long argaddr; 
  char * filepath;
  int allowaccess;
  int modifiedflags; 
  char * destination;
  char buff1[PATH_MAX];
  char buff2[PATH_MAX];

  if(ptrace(PTRACE_GETREGS, sandb->child, NULL, &regs) < 0)
    err(EXIT_FAILURE, "[SANDBOX] Failed to PTRACE_GETREGS:");

  if(regs.orig_rax == __NR_open) {
    argaddr = ptrace (PTRACE_PEEKUSER, sandb->child, 8*RDI, NULL);
    filepath = read_string(sandb->child, argaddr);

    argaddr = ptrace (PTRACE_PEEKUSER, sandb->child, 8*RSI, NULL);

    modifiedflags = check_modify_flags_for_create_mode(argaddr);

    if(modifiedflags!=argaddr && entryexit==0)  //file needs to be created
      filetobecreated=1;
    //printf("filetobecreated %d \n",filetobecreated);

    allowaccess = match_glob_for_file(filepath, open_mode(argaddr), line_array, conffilelinecount,filetobecreated);

    if(filetobecreated==1 && entryexit==1) 
      filetobecreated=0;

    if(modifiedflags!=argaddr && allowaccess==0 && entryexit==0){ //file needed to be created but not allowed, remove O_CREAT flag
      regs.rsi=modifiedflags;
      ptrace (PTRACE_SETREGS,sandb->child, NULL, &regs);
    }
    //printf("allow access %d and entry exit %d for filepath %s \n",allowaccess,entryexit,filepath);
    if(allowaccess==0 && entryexit==1){ //during exit and access isn't allowed
      //printf("Sending eaccess now \n");
      close(regs.rax);
      regs.rax=-EACCES;
      ptrace (PTRACE_SETREGS,sandb->child, NULL, &regs);
    } 
  }

  if(regs.orig_rax == __NR_openat) {
    argaddr = ptrace (PTRACE_PEEKUSER, sandb->child, 8*RSI, NULL);
    filepath = read_string(sandb->child, argaddr);

    argaddr = ptrace (PTRACE_PEEKUSER, sandb->child, 8*RDX, NULL);
    allowaccess = match_glob_for_file(filepath, open_mode(argaddr), line_array, conffilelinecount,0);

    if(allowaccess==0 && entryexit==1){ //during exit and access isn't allowed
      close(regs.rax);
      regs.rax=-EACCES;
      ptrace (PTRACE_SETREGS,sandb->child, NULL, &regs);
    } 
  }	

  if(regs.orig_rax == __NR_stat || regs.orig_rax == __NR_lstat ) {
    argaddr = ptrace (PTRACE_PEEKUSER, sandb->child, 8*RDI, NULL);
    filepath = read_string(sandb->child, argaddr);

    allowaccess = check_perms_for_stat(filepath, line_array,conffilelinecount); 

    if(allowaccess==0 && entryexit==1){ //during exit and access isn't allowed
      close(regs.rax);
      regs.rax=-EACCES;
      ptrace (PTRACE_SETREGS,sandb->child, NULL, &regs);
    } 
  }	

  if(regs.orig_rax == __NR_newfstatat) {
    argaddr = ptrace (PTRACE_PEEKUSER, sandb->child, 8*RSI, NULL);
    filepath = read_string(sandb->child, argaddr);

    allowaccess = check_perms_for_stat(filepath, line_array,conffilelinecount); 

    if(allowaccess==0 && entryexit==1){ //during exit and access isn't allowed
      close(regs.rax);
      regs.rax=-EACCES;
      ptrace (PTRACE_SETREGS,sandb->child, NULL, &regs);
    } 
  }

  if(regs.orig_rax == __NR_mkdir) {
    argaddr = ptrace (PTRACE_PEEKUSER, sandb->child, 8*RDI, NULL);
    filepath = read_string(sandb->child, argaddr);

    allowaccess = check_perms_for_mkdir(filepath, line_array,conffilelinecount); 
    if(allowaccess==0 && entryexit==0){
      mkdirnotallowed = 1;
    }

    //printf("allowaccess %d for filepath %s for entry exit %d \n",allowaccess,filepath,entryexit);
    if(mkdirnotallowed==1 && entryexit==1){ //during exit and access isn't allowed
      rmdir(filepath);
      mkdirnotallowed=0;
      close(regs.rax);
      regs.rax=-EACCES;
      ptrace (PTRACE_SETREGS,sandb->child, NULL, &regs);
    } 
    else if(allowaccess==0 && entryexit==1){
      rmdir(filepath);
      mkdirnotallowed=0;
      close(regs.rax);
      regs.rax=-EACCES;
      ptrace (PTRACE_SETREGS,sandb->child, NULL, &regs);
     }
  }	

  if(regs.orig_rax == __NR_mkdirat) {
    argaddr = ptrace (PTRACE_PEEKUSER, sandb->child, 8*RSI, NULL);
    filepath = read_string(sandb->child, argaddr);

    allowaccess = check_perms_for_mkdir(filepath, line_array,conffilelinecount); 
    if(allowaccess==0 && entryexit==0){
      mkdiratnotallowed = 1;
    }

    //printf("allowaccess %d for filepath %s for entry exit %d \n",allowaccess,filepath,entryexit);
    if(mkdiratnotallowed==1 && entryexit==1){ //during exit and access isn't allowed
      rmdir(filepath);
      mkdiratnotallowed=0;
      close(regs.rax);
      regs.rax=-EACCES;
      ptrace (PTRACE_SETREGS,sandb->child, NULL, &regs);
    } 
    else if(allowaccess==0 && entryexit==1){
      rmdir(filepath);
      mkdiratnotallowed=0;
      close(regs.rax);
      regs.rax=-EACCES;
      ptrace (PTRACE_SETREGS,sandb->child, NULL, &regs);
     }
  }	

  if(regs.orig_rax == __NR_rmdir) {
    argaddr = ptrace (PTRACE_PEEKUSER, sandb->child, 8*RDI, NULL);
    filepath = read_string(sandb->child, argaddr);

    allowaccess = check_perms_for_mkdir(filepath, line_array,conffilelinecount); //same perms needed as mkdir
    if(allowaccess==0 && entryexit==0){
      rmdirnotallowed = 1;
    }

    //printf("allowaccess %d for filepath %s for entry exit %d \n",allowaccess,filepath,entryexit);
    if(rmdirnotallowed==1 && entryexit==1){ //during exit and access isn't allowed
      if(realpath(filepath,buff1)!= NULL)
        mkdir(filepath,0777);
      rmdirnotallowed=0;
      close(regs.rax);
      regs.rax=-EACCES;
      ptrace (PTRACE_SETREGS,sandb->child, NULL, &regs);
    } 
    else if(allowaccess==0 && entryexit==1){
      mkdir(filepath,0777);  //avoiding mkdir when path is non existent
      rmdirnotallowed=0;
      close(regs.rax);
      regs.rax=-EACCES;
      ptrace (PTRACE_SETREGS,sandb->child, NULL, &regs);
     }
  }	


  if(regs.orig_rax == __NR_access) {
    argaddr = ptrace (PTRACE_PEEKUSER, sandb->child, 8*RDI, NULL);
    filepath = read_string(sandb->child, argaddr);

    argaddr = ptrace (PTRACE_PEEKUSER, sandb->child, 8*RSI, NULL);
    allowaccess = check_perms_for_access(filepath, line_array,conffilelinecount, access_mode(argaddr)); 

    if(allowaccess==0 && entryexit==1){ //during exit and access isn't allowed
      close(regs.rax);
      regs.rax=-EACCES;
      ptrace (PTRACE_SETREGS,sandb->child, NULL, &regs);
    } 
  }	

  if(regs.orig_rax == __NR_faccessat) {
    argaddr = ptrace (PTRACE_PEEKUSER, sandb->child, 8*RSI, NULL);
    filepath = read_string(sandb->child, argaddr);

    argaddr = ptrace (PTRACE_PEEKUSER, sandb->child, 8*RDX, NULL);
    allowaccess = check_perms_for_access(filepath, line_array,conffilelinecount, access_mode(argaddr)); 

    if(allowaccess==0 && entryexit==1){ //during exit and access isn't allowed
      close(regs.rax);
      regs.rax=-EACCES;
      ptrace (PTRACE_SETREGS,sandb->child, NULL, &regs);
    } 
  }

  if(regs.orig_rax == __NR_rename) {
    argaddr = ptrace (PTRACE_PEEKUSER, sandb->child, 8*RDI, NULL);
    filepath = read_string(sandb->child, argaddr); //source filepath here

    argaddr = ptrace (PTRACE_PEEKUSER, sandb->child, 8*RSI, NULL);
    destination = read_string(sandb->child, argaddr); //destination filepath here

    allowaccess = check_perms_for_rename(filepath, line_array,conffilelinecount); 
 
    if(allowaccess==0 && entryexit==0){
      renamenotallowed = 1;
    }

    if(renamenotallowed==1 && entryexit==1){ //during exit and access isn't allowed
      renamenotallowed = 0;
      rename(destination, filepath);
      close(regs.rax);
      regs.rax=-EACCES;
      ptrace (PTRACE_SETREGS,sandb->child, NULL, &regs);
    } 
  }	


  if(regs.orig_rax == __NR_renameat) {
    argaddr = ptrace (PTRACE_PEEKUSER, sandb->child, 8*RSI, NULL);
    filepath = read_string(sandb->child, argaddr); //source filepath here

    argaddr = ptrace (PTRACE_PEEKUSER, sandb->child, 8*R10, NULL);
    destination = read_string(sandb->child, argaddr); //destination filepath here

    allowaccess = check_perms_for_rename(filepath, line_array,conffilelinecount); 
 
    if(allowaccess==0 && entryexit==0){
      renameatnotallowed = 1;
    }

    if(renameatnotallowed==1 && entryexit==1){ //during exit and access isn't allowed
      renameatnotallowed = 0;
      rename(destination, filepath);
      close(regs.rax);
      regs.rax=-EACCES;
      ptrace (PTRACE_SETREGS,sandb->child, NULL, &regs);
    } 
  }	

  if(regs.orig_rax == __NR_unlink) {
    argaddr = ptrace (PTRACE_PEEKUSER, sandb->child, 8*RDI, NULL);
    filepath = read_string(sandb->child, argaddr);
    //printf("Really? 1\n");

    allowaccess = check_perms_for_unlink(filepath, line_array,conffilelinecount); 

    if(allowaccess==0 && entryexit==1){ //during exit and access isn't allowed
      close(regs.rax);
      regs.rax=-EACCES;
      ptrace (PTRACE_SETREGS,sandb->child, NULL, &regs);
    } 
  }	

  if(regs.orig_rax == __NR_unlinkat) {
    argaddr = ptrace (PTRACE_PEEKUSER, sandb->child, 8*RSI, NULL);
    filepath = read_string(sandb->child, argaddr);

    allowaccess = check_perms_for_unlink(filepath, line_array,conffilelinecount); 
    //printf("Really? 2\n");
    if(allowaccess==0 && entryexit==1){ //during exit and access isn't allowed
      close(regs.rax);
      regs.rax=-EACCES;
      ptrace (PTRACE_SETREGS,sandb->child, NULL, &regs);
    } 
  }	

  if(regs.orig_rax == __NR_execve) {
    argaddr = ptrace (PTRACE_PEEKUSER, sandb->child, 8*RDI, NULL);
    filepath = read_string(sandb->child, argaddr);

    //printf("filepath : %s \n", filepath);
    allowaccess = check_perms_for_execve(filepath, line_array,conffilelinecount); 

    if(allowaccess==0 && entryexit==0)
      execvenotallowed=1;

    //printf("Really? allowaccess %d \n",allowaccess);
    if(execvenotallowed==1 && entryexit==1){ //during exit and access isn't allowed
      //printf("sending eaccess");
      execvenotallowed=0;
      close(regs.rax);
      regs.rax=-EACCES;
      ptrace (PTRACE_SETREGS,sandb->child, NULL, &regs);
    } 
  }	

  return;
  
  if(regs.orig_rax == -1) {
   //printf("[SANDBOX] Segfault ?! KILLING !!!\n");
  }
  else
    return; 
  sandb_kill(sandb);
}



void sandb_init(struct sandbox *sandb, int argc, char **argv) {
  pid_t pid; int status;   struct user_regs_struct regs;
  unsigned long argaddr; 
  char * filepath;

  pid = fork();

  if(pid == -1)
    err(EXIT_FAILURE, "[SANDBOX] Error on fork:");

  if(pid == 0) {
    if(ptrace(PTRACE_TRACEME, 0, NULL, NULL) < 0)
      err(EXIT_FAILURE, "[SANDBOX] Failed to PTRACE_TRACEME:");
    
    if(execvp(argv[0], argv) < 0)
      err(EXIT_FAILURE, "[SANDBOX] Failed to execv:");

  } else {
    sandb->child = pid;
    sandb->progname = argv[0];
    wait(&status);

  }
}

void sandb_run(struct sandbox *sandb, struct globline **line_array, int conffilelinecount, int entryexit) {
  int status;
  if(ptrace(PTRACE_SYSCALL, sandb->child, NULL, NULL) < 0) {
    if(errno == ESRCH) {
      waitpid(sandb->child, &status, __WALL | WNOHANG);
      sandb_kill(sandb);
    } else {
      err(EXIT_FAILURE, "[SANDBOX] Failed to PTRACE_SYSCALL:");
    }
  }

  wait(&status);

  if(WIFEXITED(status))
    exit(EXIT_SUCCESS);

  if(WIFSTOPPED(status)) {
    sandb_handle_syscall(sandb, line_array,conffilelinecount,entryexit);
  }
}

int main(int argc, char **argv) {
  struct configfilename cfile;  
  int conffilelinecount=0;
  struct globline *line_array;
  struct globline instance;
  int i;
  struct sandbox sandb; int entryexit = 1;

  if(argc < 2) {
    errx(EXIT_FAILURE, "[FAILURE] fend [-c config] <command [args ...]> ");
  }

  confname_init(&cfile, argc, argv);
  conffilelinecount= countlines(cfile.conffilename);
  line_array = malloc(conffilelinecount * sizeof (struct globline));

  //printf("%s :: %s :: %d :: %d \n",cfile.conffilename,cfile.nextarg[0],cfile.args,conffilelinecount);

  conf_load(&cfile,&line_array);
  //printf("This just got done \n");
  sandb_init(&sandb, cfile.args, cfile.nextarg);


  for(;;) {
    if(entryexit == 0) 
      entryexit = 1;
    else 
      entryexit = 0;
    sandb_run(&sandb,&line_array,conffilelinecount, entryexit);
  }

  return EXIT_SUCCESS;
}
