#include <sys/ptrace.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <err.h>
#include <sys/user.h>
#include <asm/ptrace.h>
#include <sys/wait.h>
#include <asm/unistd.h>
#include <signal.h>
#include <string.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/types.h>
#include <limits.h>
#include <glob.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "read.h"

//Home path buffer
char cur_path[4096];
//permission lists
linkedlist_t *plist;
//hashtable for <fd, filename>
linkedlist_t *ftable;

//path for file witn no permission
const char *denypath = "deny";
const char *denydirs = "denr/";
//size of long
const int long_size = sizeof(long);

struct sandbox {
	pid_t child;
	const char *progname;
};

struct sandb_syscall {
	int syscall;
	void (*callback)(struct sandbox*, struct user_regs_struct *regs);
};

struct sandb_syscall sandb_syscalls[] = {
	{__NR_read,            NULL},
	{__NR_write,           NULL},
	{__NR_exit,            NULL},
	{__NR_brk,             NULL},
	{__NR_mmap,            NULL},
	{__NR_access,          NULL},
	{__NR_open,            NULL},
	{__NR_fstat,           NULL},
	{__NR_close,           NULL},
	{__NR_mprotect,        NULL},
	{__NR_munmap,          NULL},
	{__NR_arch_prctl,      NULL},
	{__NR_exit_group,      NULL},
	{__NR_getdents,        NULL},
};
/*
 * putdata():
 * put len words of string data from str to addr
 * this function is refer from <playing with ptrace>: http://www.linuxjournal.com/article/6100?page=0,2
 *
 * */
void putdata(pid_t child, long addr, char *str, int len)
{   char *laddr;
    int i, j;
    union u {
            long val;
            char chars[long_size];
    }data;
    i = 0;
    j = len / long_size;
    laddr = str;
    while(i < j) {
        memcpy(data.chars, laddr, long_size);
        ptrace(PTRACE_POKEDATA, child,
               addr + i * 4, data.val);
        ++i;
        laddr += long_size;
    }
    j = len % long_size;
    if(j != 0) {
        memcpy(data.chars, laddr, j);
        ptrace(PTRACE_POKEDATA, child,
               addr + i * 4, data.val);
    }
}

/*
   read_string():
   read unbounded string data from regs.

   this fun is refered from nelhage's ministarce repo (https://github.com/nelhage/ministrace/blob/master/ministrace.c)
 */
char *read_string(pid_t child, unsigned long addr) {
	char *val = malloc(4096);
	int allocated = 4096;
	int read = 0;
	unsigned long tmp;
	while (1) {
		//grow the buffer if necessary
		if (read + sizeof tmp > allocated) {
			allocated *= 2;
			val = realloc(val, allocated);
		}
		//error check if it failed
		tmp = ptrace(PTRACE_PEEKDATA, child, addr + read);
		if(errno != 0) {
			val[read] = 0;
			break;
		}
		//appending data
		memcpy(val + read, &tmp, sizeof tmp);
		if (memchr(&tmp, 0, sizeof tmp) != NULL)
			break;
		read += sizeof tmp;
	}
	return val;
}


void sandb_kill(struct sandbox *sandb) {
	kill(sandb->child, SIGKILL);
	wait(NULL);
	exit(EXIT_FAILURE);
}

void sandb_handle_syscall(struct sandbox *sandb) {
	int i;
	static int inscall = 0;
	struct user_regs_struct regs;
	struct user_regs_struct *regspointer;
	char search_path[ 4096 ];

	if(ptrace(PTRACE_GETREGS, sandb->child, 0, &regs) < 0)
		err(EXIT_FAILURE, "[SANDBOX] Failed to PTRACE_GETREGS:");

/////////////////////*handle open(), record fd and corresponding filename*////////////////////||
	if(regs.orig_rax == __NR_open ){
		char *path, *temp;
		//check if this match have return value (the 2nd time will have return value in rax)
		if(inscall == 0){
			//with no return value, set flag to 1, next time will in return value handling
			inscall = 1;
			//get the filepath's absolute path from rdi
			char search_path[4096];
			path = read_string(sandb->child, regs.rdi);
			strcpy( search_path, cur_path );
			strcat( search_path, "/" );
			strcat( search_path, path );
			printf("[SANDBOX] system call open() with path: %s \n", search_path);
			//check if this path is allowed
			if(is_Allow(plist, search_path ,(regs.rsi & 0X03)) == 0) {
				//if not allow, change the filepath to ./deny, which have no permission
				putdata(sandb->child, regs.rdi, denypath, 5);
				errno = EACCES;
				perror("EACCES");
			}
		}
		else {
			//second time in open(), get the fd from the return value
			inscall = 0;
			//get return value
			int ret = regs.rax;
			path = read_string(sandb->child, regs.rdi);
			printf("[SANDBOX] system call open() with path %s return %d \n", path, ret);
			if (ret > 2) {
				//if the file is successfully opened, store <fd, filename> pair to ftable
				node_t *temp = find_Node(ftable, ret);
				if(temp) {
					temp->name = path;
					//this fd number has old data, just update data
				} else {
					add_node(ftable, create_fdnode(path, regs.rax));
					//this is a new fd number, create new node for it
				}
			}
		}
	}

	/////////////////////*handle execve()////////////////////||
		if(regs.orig_rax == __NR_execve ){
			char *path, *temp;
			//check if this match have return value (the 2nd time will have return value in rax)
			if(inscall == 0){
				//with no return value, set flag to 1, next time will in return value handling
				inscall = 1;
				//get the filepath's absolute path from rdi
				char search_path[4096];
				path = read_string(sandb->child, regs.rdi);
				strcpy( search_path, cur_path );
				strcat( search_path, "/" );
				strcat( search_path, path );
				printf("[SANDBOX] system call execve() with path: %s \n", search_path);
				//check if this path is allowed
				if(is_Allow(plist, search_path , -1) == 0) {
					//if not allow, change the filepath to ./deny, which have no permission
					putdata(sandb->child, regs.rdi, denypath, 5);
					errno = EACCES;
					perror("EACCES");
				}
			}
			else {
				//second time in open(), get the fd from the return value
				inscall = 0;
				//get return value
				int ret = regs.rax;
				path = read_string(sandb->child, regs.rdi);
				printf("[SANDBOX] system call execve() with path %s return %d \n", path, ret);
			}
		}
		/////////////////////*handle openat()////////////////////||
			if(regs.orig_rax == __NR_openat ){
				char *path, *temp;
				//check if this match have return value (the 2nd time will have return value in rax)
				if(inscall == 0){
					//with no return value, set flag to 1, next time will in return value handling
					inscall = 1;
					if (regs.rdi == AT_FDCWD) {
					//get the filepath's absolute path from rsi
					char search_path[4096];
					path = read_string(sandb->child, regs.rsi);
					strcpy( search_path, cur_path );
					strcat( search_path, "/" );
					strcat( search_path, path );
					printf("[SANDBOX] system call openat() with path: %s \n", search_path);
					//check if this path is allowed
					if(is_Allow(plist, search_path , (regs.rdx & 0X03)) == 0) {
						//if not allow, change the filepath to ./denr/, which have no permission
						putdata(sandb->child, regs.rsi, denydirs, 5);
						errno = EACCES;
						perror("EACCES");
					}
					}
				}
				else {
					//second time in open(), get the fd from the return value
					inscall = 0;
					//get return value
					int ret = regs.rax;
					path = read_string(sandb->child, regs.rsi);
					printf("[SANDBOX] system call openat() with path %s return %d \n", path, ret);
				}
			}
	/////////////////////*handle read() and write()////////////////////
//	if(regs.orig_rax == __NR_read || regs.orig_rax == __NR_write) {
//		printf("in r/w\n");
//		int fd = regs.rdi;
//		if(fd > 2) {
//			node_t *temp = find_Node(ftable, fd);
//			char search_path[4096];
//			strcpy( search_path, cur_path );
//			strcat( search_path, "/" );
//			strcat( search_path, temp->name );
//			if(is_Allow(plist, search_path ,regs.orig_rax)==0) {
//				printf("[SANDBOX] Permission deny\n");
//				regs.rdi = -1;
//				ptrace(PTRACE_SETREGS, sandb->child, 0, &regs); //set the register(s), which set fd to -1
//			}
//		}
//
//	}


	if(regs.orig_rax == -1) {
		printf("[SANDBOX] Segfault ?! KILLING !!!\n");
		sandb_kill(sandb);
	}
}

/*
   sandb_init():
   create child process and attch tracer to it.

   this fun is refered from t00sh's p-sandbox (https://github.com/t00sh/p-sandbox/blob/master/p-sandbox.c)
 */
void sandb_init(struct sandbox *sandb, int argc, char **argv) {
	pid_t pid;
	int fd2 = open("deny", O_RDWR|O_CREAT, 0000);
	mkdir("denr",0000);
	pid = fork();

	if(pid == -1)
		err(EXIT_FAILURE, "[SANDBOX] Error on fork:");

	if(pid == 0) {

		if(ptrace(PTRACE_TRACEME, 0, NULL, NULL) < 0)
			err(EXIT_FAILURE, "[SANDBOX] Failed to PTRACE_TRACEME:");

		if(execv(argv[0], argv) < 0)
			err(EXIT_FAILURE, "[SANDBOX] Failed to execv:");

	} else {
		sandb->child = pid;
		sandb->progname = argv[0];
		wait(NULL);
	}
}

/*
   sandb_run():
   wait for child process to stopped by ptrace and call handling functions
   this fun is refered from t00sh's p-sandbox (https://github.com/t00sh/p-sandbox/blob/master/p-sandbox.c)
 */
void sandb_run(struct sandbox *sandb) {
	int status;

	if(ptrace(PTRACE_SYSCALL, sandb->child, NULL, NULL) < 0) {
		if(errno == ESRCH) {
			waitpid(sandb->child, &status, __WALL | WNOHANG);
			sandb_kill(sandb);
		} else {
			err(EXIT_FAILURE, "[SANDBOX] Failed to PTRACE_SYSCALL:");
		}
	}

	wait(&status);

	if(WIFEXITED(status))
		exit(EXIT_SUCCESS);

	if(WIFSTOPPED(status)) {
		sandb_handle_syscall(sandb);
	}
}

int main(int argc, char **argv) {
	//variable inits
	plist = create_linkedlist();
	ftable = create_linkedlist();
	//check input
	if(argc < 2) {
		errx(EXIT_FAILURE, "[SANDBOX] Usage : fend [-c config] <command [args ...]>");
	}
	//get Home path
	char *home = getenv( "HOME" );
	char rpath[ 4096 ];
	strcpy( rpath, home );
	strcat( rpath, "/.fendrc" );
	//get current path
	getcwd(cur_path, 4096);

	struct sandbox sandb;
	//flag for ensuring at least config file is read
	int readFlag = 0;

	//read config file in
	//with -c config file
	if(!strcmp(argv[1],"-c")) {
		if (getConfig(argv[2], plist)==1) {
			/* code */
			readFlag = 1;
			argv = argv + 2;
			argc = argc - 2;
		}
	}
	//read ".fendrc" from current path and home path
	if (getConfig(".fendrc", plist)==1 || getConfig(rpath, plist)==1) {
		readFlag = 1;
	}
	//if no file read in, print error and exit
	if (readFlag == 0){
		printf("[SANDBOX] Must provide a config file.");
		return EXIT_SUCCESS;
	}
	// begin tracing
	sandb_init(&sandb, argc-1, argv+1);
	for(;;) {
		sandb_run(&sandb);
	}

	return EXIT_SUCCESS;
}
