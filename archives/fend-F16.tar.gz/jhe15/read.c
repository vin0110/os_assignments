#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <glob.h>
#include <linux/limits.h>
#include "read.h"
#include "glob.h"
#define READ_LENGTH 255

/*
 * LinkedList structure:
 * I implemented this LinkedList based on one course project I done before, which has well error handle and free from memory leakage.
 * I have modified relevant methods about adding and finding.
 * see https://github.com/henryhoo/Lab6-C-programming/tree/master/linkedlist for original version.
 */
linkedlist_t * create_linkedlist(){
	linkedlist_t *newlist = malloc(sizeof(linkedlist_t));
	newlist->head=NULL;
	newlist->tail=NULL;
	return newlist;
}
/*		    free_linkedlist()
 *free each node from the linklist
 */
void free_linkedlist(linkedlist_t *list){
	node_t *walk = list->head;
	node_t *next = NULL;
	while(walk)
	{
		next = walk->next;
		free(walk);
		walk = next;
	}
	free(list);
}

/*				add_node()
 *add a node to linkedlist, return -1 if fail
 */

int add_node(linkedlist_t *list, node_t *node){
	if (list==NULL||node==NULL) {
		/* null error */
		return -1;
	}
	else{
		if (list->head==NULL) {
			/* null error */
			list->head=node;
			list->tail=node;
			return 0;
		}
		if (list->tail!=NULL) {
			/* code */
			node->prev=list->tail;
			list->tail->next=node;
			list->tail=node;
			return 0;
		}
		return -1;
	}
}

/*				create_node()
 *create a node with different data, return NULL if fail, new node if success
 */
node_t *create_node(const char *name, int p[3]){
	node_t *newnode = malloc(sizeof(node_t));
	if(newnode == NULL) return NULL;
	newnode -> name = malloc(READ_LENGTH*sizeof(char));
	newnode -> next = NULL;
	newnode -> prev = NULL;
	strcpy(newnode -> name, name);

	int i = 0;
	for(i = 0; i < 3; i++) {
		newnode -> permits[i] = p[i];
	}

	return newnode;
}

node_t *create_fdnode(const char *name, int fd){
	node_t *newnode = malloc(sizeof(node_t));
	if(newnode == NULL) return NULL;
	newnode -> next = NULL;
	newnode -> prev = NULL;
	newnode -> name = malloc(READ_LENGTH*sizeof(char));
	strcpy(newnode -> name, name);
	newnode->fd = fd;
	return newnode;
}

void delete_node(node_t *node){
	free(node);
}
/*
 * int has_node(linkedlist_t *list, const char *name):
 * check if have specific node with pathname.
 * return -1 for error, 0 for no, 1 for has
 *
 */
int has_Node(linkedlist_t *list, const char *name){

	if (list==NULL||list->head==NULL) {
		/* code */
		return -1;
	}
	else{
		node_t *walk = list->head;
		while(walk){
			if (!strcmp(walk->name, name)) {
				/* code */
				return 1;
			}
			walk=walk->next;
		}
	}
	return 0;
}
/*
 * int has_node(linkedlist_t *list, const char *name):
 * check if specific r/w operation is allow for pathname.
 * return -1 for error, 0 for disallow, 1 for allow
 *
 */
int is_Allow(linkedlist_t *list, const char *name, int mode){

	if (list==NULL||list->tail==NULL) {
		/* code */
		return -1;
	} else if (mode == 2) {
		//mode = 2, means flag is O_RDWR
		node_t *walk = list->tail;
		while(walk){
			if (!strcmp(walk->name, name)) {
				/* code */
				if (walk->permits[0] == 0 || walk->permits[1] == 0) {
					return 0;
				}
			}
			walk=walk->prev;
		}
	} else if (mode == -1) {
		//mode = -1, means flag is execve()
		node_t *walk = list->tail;
		while(walk){
			if (!strcmp(walk->name, name)) {
				/* code */
				if (walk->permits[2] == 0 || walk->permits[0] == 0) {
					return 0;
				}
			}
			walk=walk->prev;
		}
	} else{
		//mode = 0 or mode = 1, means flag is O_RDONLY, O_WRONLY, also means checking for read/write permit for read()/write() syscall
		node_t *walk = list->tail;
		while(walk){
			if (!strcmp(walk->name, name)) {
				/* code */
				if (walk->permits[mode] == 0) {
					return 0;
				}
			}
			walk=walk->prev;
		}
	}
	return 1;
}

/*
 * node_t* find_Node(linkedlist_t *list, int fd):
 * check if have specific node with fd.
 * return NULL for error, node_t if found
 *
 */
node_t* find_Node(linkedlist_t *list, int fd){

	if (list==NULL||list->tail==NULL) {
		/* code */
		return NULL;
	}
	else{
		node_t *walk = list->tail;
		while(walk){
			if (walk->fd == fd) {
				/* code */
				return walk;
			}
			walk=walk->prev;
		}
	}
	return NULL;
}
/*
 * 				getConfig()
 * read from config file and store all pattern into a list
 * return 0 if fail, 1 if success
 * */
int getConfig(const char *path, linkedlist_t *list){
	FILE *fp;
	fp = fopen(path, "r");
	char buff[READ_LENGTH];//file name buffer
	char flag[3];//permission flag to read\write\execute
	int flags[3], i = 0;
	if(fp == NULL)	{
		printf("file %s not exist", path);
		return 0;
	}
	//get current path
	char cur_path[4096];
	char search_path[4096];
	getcwd(cur_path, 4096);

	//read line by line
	while(!feof(fp)){
		fscanf(fp, "%s %s", flag, buff);
		//printf("get  %s, %s\n", flag, buff);
		//read in permission flags
		for(i = 0; i < 3; i++) {
			flags[i] = flag[i] - '0';
		}
		//find and cache all matched results.
		strcpy( search_path, "" );
		strcat( search_path, "/" );
		strcat( search_path, buff );
		//printf("searchpath is %s\n", search_path);
		glob_t results;
		int ret = glob(search_path, GLOB_TILDE , NULL, & results);
		if( ret != 0 && ret != GLOB_NOMATCH) {
			printf("glob error");
			return 0;
		}
		//add each result into a list
		int i = 0;
		for(i = 0; i < results.gl_pathc; i++){
			//printf("glob result is %s %c%c%c\n", results.gl_pathv[i], flag[0], flag[1], flag[2]);

			add_node(list, create_node(results.gl_pathv[i], flags));
		}
		//free memory
		globfree(& results);
	}
	return 1;
}



/*
 *
 * Unit test
 *
 */
 /*
int main(){
	linkedlist_t *read = create_linkedlist();
	linkedlist_t *write = create_linkedlist();
	linkedlist_t *exc = create_linkedlist();
	char *home = getenv( "HOME" );
	char path[ PATH_MAX ];
	strcpy( path, home );
	strcat( path, "/.fendrc" );
	int flag = getConfig("file", read, write, exc);
	int flag2 = getConfig(".fendrc", read, write, exc);
	int flag3 = getConfig(path, read, write, exc);
	node_t *walk = read->head;
	while(walk){
		printf("read block %s\n", walk->name);
		walk = walk->next;
	}
	walk = write->head;
	while(walk){
		printf("write block %s\n", walk->name);
		walk = walk->next;
	}
	walk = exc->head;
	while(walk){
		printf("execute block %s\n", walk->name);
		walk = walk->next;
	}
	printf("read has quit.c ? %d\n",has_Node(read, "quit.c"));
	printf("read has *.txt ? %d\n",has_Node(read, "*.txt"));
}
*/
