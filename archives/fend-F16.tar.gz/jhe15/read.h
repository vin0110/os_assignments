#ifndef READ_H
#define READ_H

typedef struct node {
	struct node *next; // Pointer to next node in the list
	struct node *prev; // Pointer to previous node in the list
	char *name;
	int permits[3];
	int fd;
} node_t;

typedef struct linkedlist {
	node_t *head;
	node_t *tail;
} linkedlist_t;

linkedlist_t *create_linkedlist();
void free_linkedlist(linkedlist_t *list);
int add_node(linkedlist_t *list, node_t *node);
node_t * create_node(const char *, int [3]);
node_t * create_fdnode(const char *, int fd);
int is_Allow(linkedlist_t *list, const char *name, int mode);
void delete_node(node_t *node);
int has_Node(linkedlist_t *list, const char *);
node_t* find_Node(linkedlist_t *, int);

int getConfig(const char*, linkedlist_t *);



#endif
