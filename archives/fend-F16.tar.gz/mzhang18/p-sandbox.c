#include <sys/ptrace.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <err.h>
#include <sys/user.h>
#include <asm/ptrace.h>
#include <sys/wait.h>
#include <asm/unistd.h>
#include <signal.h>
#include <string.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/reg.h>
#include <sys/syscall.h>
#include <stdbool.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <fnmatch.h>

const int long_size = sizeof(long);
const int path_max = 4096;
const int command_length = 32;

int cmdc;
char **cmdv;
char *defaultConfig = ".fendrc";

char *reject_ref = "/root";
char *reject_file = "/root/.bashrc";
char *reject_exe = "/root/exe";
// char *reject_argu[] = {"./imm"};

struct sandb_file {
  int read;
  int write;
  int exe;
  char *pattern;

  struct sandb_file *next;
};

struct file_queue{
  struct sandb_file *head;
  struct sandb_file *tail;

  int size;
};

struct file_queue fqueue = {NULL, NULL, 0};

/**
 * Reference; http://www.geeksforgeeks.org/wildcard-pattern-matching/
 *
 */
bool glob_match(char str[], char pattern[]) {

    // empty pattern can only match with
    // empty string
    int n = strlen(str);
    int m = strlen(pattern);

    if (m == 0)
        return (n == 0);
 
    // lookup table for storing results of
    // subproblems
    bool lookup[n + 1][m + 1];
 
    // initailze lookup table to false
    memset(lookup, false, sizeof(lookup));
 
    // empty pattern can match with empty string
    lookup[0][0] = true;
 
    // Only '*' can match with empty string
    int j = 1;
    for (; j <= m; j++)
        if (pattern[j - 1] == '*')
            lookup[0][j] = lookup[0][j - 1];
 
    // fill the table in bottom-up fashion
    int i = 1;
    for (; i <= n; i++)
    {
        j = 1;
        for (; j <= m; j++)
        {
            // Two cases if we see a '*'
            // a) We ignore ‘*’ character and move
            //    to next  character in the pattern,
            //     i.e., ‘*’ indicates an empty sequence.
            // b) '*' character matches with ith
            //     character in input
            if (pattern[j - 1] == '*')
                lookup[i][j] = lookup[i][j - 1] ||
                               lookup[i - 1][j];
 
            // Current characters are considered as
            // matching in two cases
            // (a) current character of pattern is '?'
            // (b) characters actually match
            else if (pattern[j - 1] == '?' ||
                    str[i - 1] == pattern[j - 1])
                lookup[i][j] = lookup[i - 1][j - 1];
 
            // If characters don't match
            else lookup[i][j] = false;
        }
    }
 
    return lookup[n][m];
}

bool check_permission(char str[], int readReq, int writeReq, int exeReq) {
  struct sandb_file *probe = fqueue.head;
  
  while(probe != NULL) {
    // if (glob_match(str, probe->pattern)) 
    if (!fnmatch(probe->pattern, str, FNM_PATHNAME))
    {
      
      if (readReq && !probe->read)
        return false;

      if (writeReq && !probe->write)
        return false;

      if (exeReq && !probe->exe)
        return false;

      break;  
    }

    probe = probe->next;
  }

  return true;
}

int wait_for_syscall(pid_t child) {
    int status;
    while (1) {
        ptrace(PTRACE_SYSCALL, child, 0, 0);
        waitpid(child, &status, 0);
        if (WIFSTOPPED(status) && WSTOPSIG(status) & 0x80)
            return 0;
        if (WIFEXITED(status))
            return 1;
    }
}

void get_filePath(pid_t child, long addr, char *filePath) {
    int i = long_size, j = 0;
    char *laddr = filePath;
    union u {
            long val;
            char chars[long_size];
    }data;
    
    while (1) {
        if (i == long_size) {
            data.val = ptrace(PTRACE_PEEKDATA, child, addr + j * long_size, NULL);
            j++;
            i = 0;
        }
        if (data.chars[i] == '\0') {
            laddr[0] = '\0';
            break;
        }
        laddr[0] = data.chars[i];
        laddr++;
        i++;
    }
    // fprintf(stderr, "\nFile Path: %s\n", filePath);
}

void set_regs(pid_t child, long addr, char *str) { 
    char *laddr = str;
    int i, j;
    int len = (int)strlen(str);
    union u {
            long val;
            char chars[long_size];
    }data;

    i = 0;
    j = len / long_size;
    laddr = str;
    while(i < j) {
        memcpy(data.chars, laddr, long_size);
        ptrace(PTRACE_POKEDATA, child,
               addr + i * 8, data.val);
        ++i;
        laddr += long_size;
    }

    j = len % long_size;
    memcpy(data.chars, laddr, j + 1);
    ptrace(PTRACE_POKEDATA, child,
        addr + i * 8, data.val); 
}

int get_argument(pid_t child, long addr, char *secArgs[]) {

  char *probe;
  int i = 0;

  while(1) {
    probe = (char *) ptrace(PTRACE_PEEKDATA, child, addr + 8 * i, NULL);

    if (probe == NULL)
      break;

    secArgs[i] = (char*)malloc(command_length * sizeof(char));
    strcpy(secArgs[i], probe);

    i++;
  }

  return i;
}

void set_argument(pid_t child, long addr, char *arguments[], int argc) { 
    
    char *probe;
    int i = 0;

    while (i < argc) {
      probe = (char *) ptrace(PTRACE_PEEKDATA, child, addr + 8 * i, NULL);
      strcpy(probe, arguments[i]);

      // fprintf(stderr, "set_argument: %s\n", probe);

      i++;
    }

    ptrace(PTRACE_POKEDATA, child, addr + i * 8, NULL);
}

void sandb_read_config(int argc, char **argv) {
  FILE *fp;

  if (argc == 0) {

    fp = fopen(defaultConfig, "r");

    if (!fp) {
      char *home = getenv("HOME");

      char *defaultPath = malloc(strlen(home) + strlen(defaultConfig) + 2);
      strcpy(defaultPath, home);
      strcat(defaultPath, "/");
      strcat(defaultPath, defaultConfig);
      // printf("%s\n", defaultPath);

      fp = fopen(defaultPath, "r");

      if (!fp)
        err(EXIT_FAILURE, "Must provide a config file.\n");

    }
  } else {

    fp = fopen(argv[argc], "r");

    if (!fp) 
      err(EXIT_FAILURE, "Failed to open config file: %s\n", argv[argc]); 

  }

  /* read file permission */
  int tmpPer;

  struct sandb_file sfile = {0, 0, 0, (char*)malloc(100 * sizeof(char)), NULL};
  
  while (fscanf(fp, "%d %s\n", &tmpPer, sfile.pattern) != EOF) {
    sfile.read = tmpPer / 100;
    tmpPer = tmpPer % 100;
    sfile.write = tmpPer / 10;
    tmpPer = tmpPer % 10;
    sfile.exe = tmpPer;

    if (sfile.read < 0 || sfile.read > 1 
        || sfile.write < 0 || sfile.write > 1
        || sfile.exe < 0 || sfile.exe > 1
        || strlen(sfile.pattern) < 1) 
    {
      // errx(EXIT_FAILURE, "Invalid config argument about file: %s", sfile.pattern);
      continue;
    }

  /* Initialization */
    struct sandb_file *addfile = (struct sandb_file*)malloc(sizeof(struct sandb_file));
    addfile->pattern = (char*)malloc(100 * sizeof(char));
    struct sandb_file *addfile2 = (struct sandb_file*)malloc(sizeof(struct sandb_file));
    addfile2->pattern = (char*)malloc(100 * sizeof(char));
    
  /* Set value */
    addfile->read = addfile2->read = sfile.read;
    addfile->write = addfile2->write = sfile.write;
    addfile->exe = addfile2->exe = sfile.exe;

    char cwd[path_max];
    cwd[0] = '\0';
    char cwd2[path_max];
    cwd2[0] = '\0';

    /* start */
    /* fnmatch */
    if (sfile.pattern[0] != '/') {
      getcwd(cwd, sizeof(cwd));
      strcat(cwd, "/");
    } 
    /* glob_match() */
    // if (sfile.pattern[0] != '*' && sfile.pattern[0] != '/') {
    //   getcwd(cwd, sizeof(cwd));
    //   strcat(cwd, "/");
    // } 
    /* end */ 
    strcat(cwd, sfile.pattern);
    strcpy(addfile->pattern, cwd);

    strcpy(cwd2, cwd);
    strcat(cwd2, "/*");
    strcpy(addfile2->pattern, cwd2);

    addfile->next = NULL;
    addfile2->next = NULL;

    if (fqueue.head == NULL) {
      fqueue.head = addfile;
      fqueue.tail = addfile;
      fqueue.size++;
    } else {
      addfile->next = fqueue.head;
      fqueue.head = addfile;
      fqueue.size++;
    }

    addfile2->next = fqueue.head;
    fqueue.head = addfile2;
    fqueue.size++;

  }

  /* Print Files` Permission */
  // struct sandb_file *probe = fqueue.head;
  // while(probe != NULL) {
  //   printf("%d %d %d %s\n", probe->read, probe->write, probe->exe, probe->pattern);
  //   probe = probe->next;
  // }

  fclose(fp);
}

void sandb_init(int argc, char **argv) {
  
  size_t i;

  /* [--help] */
  if (strcmp(argv[0], "--help") == 0) {
    printf("p-strace sandbox help instruction\n");
    exit(0);
  }
  
  /* read config file */
  if (strcmp(argv[0], "-c") == 0) {
    
    if (argc < 2) 
      errx(EXIT_FAILURE, "[-c] Must provide a config file");

    sandb_read_config(1, argv);

    cmdc = argc - 2;
    cmdv = argv + 2;
  } else {
    sandb_read_config(0, argv);

    cmdc = argc;
    cmdv = argv;
  }
}

int do_trace(pid_t child) {
    int status, syscall, retval;

    waitpid(child, &status, 0);
    ptrace(PTRACE_SETOPTIONS, child, 0, PTRACE_O_TRACESYSGOOD);

    while(1) {
        if (wait_for_syscall(child) != 0) break;

        syscall = ptrace(PTRACE_PEEKUSER, child, sizeof(long)*ORIG_RAX);
        
        bool flag = false;

        switch (syscall)
        {
            case SYS_openat : {
                long params[3];
                char filePath[path_max];
                filePath[0] = '\0';

                params[0] = ptrace(PTRACE_PEEKUSER,
                                      child, 8 * RDI,
                                      NULL);
                params[1] = ptrace(PTRACE_PEEKUSER,
                                      child, 8 * RSI,
                                      NULL);
                params[2] = ptrace(PTRACE_PEEKUSER,
                                      child, 8 * RDX,
                                      NULL);

                get_filePath(child, params[1], filePath);
                // memcpy(orig_param, filePath, path_max);

                char cwd[path_max];
                cwd[0] = '\0';

                if (strlen(filePath) >= 1 && filePath[0] == '/') {
                  strcat(cwd, filePath);
                } else {
                  getcwd(cwd, sizeof(cwd));

                  strcat(cwd, "/");
                  strcat(cwd, filePath);
                }
                // fprintf(stderr, "|Complete File Path: %s|\n", cwd);

                int rd = 0, wr = 0, ex = 0;
                int flag = (int) params[2];
                rd = !((flag & 1) ^ 0) | !(((flag & (1 << 1)) >> 1) ^ 1);
                wr = !((flag & 1) ^ 1) | !(((flag & (1 << 1)) >> 1) ^ 1);

                // fprintf(stderr, "rd: %d; wr: %d; ex: %d\n", rd, wr, ex);

                if (!check_permission(cwd, rd, wr, ex)) {
                  set_regs(child, params[1], reject_ref);

                  if (wait_for_syscall(child) != 0) {
                        flag = true;
                  }
        
                  set_regs(child, params[1], filePath);

                } else {

                  if (wait_for_syscall(child) != 0) flag = true;

                }

                break;
            }
            case SYS_execve : {
                long params[3];
                char filePath[path_max];
                filePath[0] = '\0';
                // char *secArgs[16];
                // int secArgc;

                params[0] = ptrace(PTRACE_PEEKUSER,
                                      child, 8 * RDI,
                                      NULL);
                params[1] = ptrace(PTRACE_PEEKUSER,
                                      child, 8 * RSI,
                                      NULL);
                params[2] = ptrace(PTRACE_PEEKUSER,
                                      child, 8 * RDX,
                                      NULL);

                get_filePath(child, params[0], filePath);
                // fprintf(stderr, "get_filePath: %s\n", filePath);
                // secArgc = get_argument(child, params[1], secArgs);
                // int i = 0;
                // for (; i < secArgc; i++)
                //   fprintf(stderr, "get_argument: %s\n", secArgs[i]);

                char cwd[path_max];
                cwd[0] = '\0';

                if (strlen(filePath) >= 1 && filePath[0] == '/') {
                  strcpy(cwd, filePath);
                  // fprintf(stderr, "-->case 1 execve_filePath: %s\n", cwd);                
                } else {
                  getcwd(cwd, sizeof(cwd));
                  char *cwdp = filePath;

                  if (strlen(filePath) >= 1 && filePath[0] == '.')
                    cwdp++;
                  else
                    strcat(cwd, "/");

                  strcat(cwd, cwdp);
                  // fprintf(stderr, "-->case 2 execve_filePath: %s\n", cwd);
                }
        
                if (!check_permission(cwd, 0, 0, 1)) {
                  
                  set_regs(child, params[0], reject_exe);
                  // set_argument(child, params[1], reject_argu, 1);
                  
                  // fprintf(stderr, "Trying to set: %s\n", reject_exe);
                  // char tmp[path_max];
                  // tmp[0] = '0';
                  // get_filePath(child, params[0], tmp);
                  // fprintf(stderr, "After Set: %s\n", tmp);
                  
                  if (wait_for_syscall(child) != 0) {
                        flag = true;
                  }

                  set_regs(child, params[0], filePath);
                  // set_argument(child, params[1], secondArgu);     
                  write(2, "./fend: cannot exec: Permission denied\n", 39);

                } else {

                  if (wait_for_syscall(child) != 0) flag = true;

                }

                break;
            }
            case SYS_open : {
                long params[3];
                char filePath[path_max];
                filePath[0] = '\0';

                params[0] = ptrace(PTRACE_PEEKUSER,
                                      child, 8 * RDI,
                                      NULL);
                params[1] = ptrace(PTRACE_PEEKUSER,
                                      child, 8 * RSI,
                                      NULL);
                params[2] = ptrace(PTRACE_PEEKUSER,
                                      child, 8 * RDX,
                                      NULL);

                get_filePath(child, params[0], filePath);
                // fprintf(stderr, "get_filePath: %s\n", filePath);

                char cwd[path_max];
                cwd[0] = '\0';

                if (strlen(filePath) >= 1 && filePath[0] == '/') {
                  strcat(cwd, filePath);
                } else {
                  getcwd(cwd, sizeof(cwd));

                  strcat(cwd, "/");
                  strcat(cwd, filePath);
                }
                // fprintf(stderr, "Complete Fisle Path: %s\n", cwd);

                int rd = 0, wr = 0, ex = 0;
                int flag = (int) params[1];
                rd = !((flag & 1) ^ 0) | !(((flag & (1 << 1)) >> 1) ^ 1);
                wr = !((flag & 1) ^ 1) | !(((flag & (1 << 1)) >> 1) ^ 1);

                if (!check_permission(cwd, rd, wr, ex)) {
                  set_regs(child, params[0], reject_file);

                  if (wait_for_syscall(child) != 0) {
                        flag = true;
                  }
        
                  set_regs(child, params[0], filePath);

                } else {

                  if (wait_for_syscall(child) != 0) flag = true;

                }

                break;
            }
            /* execveat */
            case 322 : {
                long params[3];
                char filePath[path_max];
                filePath[0] = '\0';
                // char *secArgs[16];
                // int secArgc;

                params[0] = ptrace(PTRACE_PEEKUSER,
                                      child, 8 * RDI,
                                      NULL);
                params[1] = ptrace(PTRACE_PEEKUSER,
                                      child, 8 * RSI,
                                      NULL);
                params[2] = ptrace(PTRACE_PEEKUSER,
                                      child, 8 * RDX,
                                      NULL);

                get_filePath(child, params[1], filePath);
                // fprintf(stderr, "get_filePath: %s\n", filePath);
                // secArgc = get_argument(child, params[1], secArgs);
                // int i = 0;
                // for (; i < secArgc; i++)
                //   fprintf(stderr, "get_argument: %s\n", secArgs[i]);

                char cwd[path_max];
                cwd[0] = '\0';

                if (strlen(filePath) >= 1 && filePath[0] == '/') {
                  strcpy(cwd, filePath);
                  // fprintf(stderr, "-->case 1 execve_filePath: %s\n", cwd);                
                } else {
                  getcwd(cwd, sizeof(cwd));
                  char *cwdp = filePath;

                  if (strlen(filePath) >= 1 && filePath[0] == '.')
                    cwdp++;
                  else
                    strcat(cwd, "/");

                  strcat(cwd, cwdp);
                  // fprintf(stderr, "-->case 2 execve_filePath: %s\n", cwd);
                }
        
                if (!check_permission(cwd, 0, 0, 1)) {
                  
                  set_regs(child, params[1], reject_exe);
                  // set_argument(child, params[1], reject_argu, 1);
                  
                  // fprintf(stderr, "Trying to set: %s\n", reject_exe);
                  // char tmp[path_max];
                  // tmp[0] = '0';
                  // get_filePath(child, params[0], tmp);
                  // fprintf(stderr, "After Set: %s\n", tmp);
                  
                  if (wait_for_syscall(child) != 0) {
                        flag = true;
                  }

                  set_regs(child, params[1], filePath);
                  // set_argument(child, params[1], secondArgu);     
                  write(2, "./fend: cannot exec: Permission denied\n", 39);

                } else {

                  if (wait_for_syscall(child) != 0) flag = true;

                }

                break;
            }
            default : if (wait_for_syscall(child) != 0) flag = true;
        }

        retval = ptrace(PTRACE_PEEKUSER, child, sizeof(long)*RAX);
        // fprintf(stderr, "syscall(%d) = %d\n", syscall, retval);
        
        if (flag)
          break;

    }
    return 0;
}

int do_child(int argc, char **argv) {
    char *args [argc+1];
    memcpy(args, argv, argc * sizeof(char*));
    args[argc] = NULL;

    ptrace(PTRACE_TRACEME);
    kill(getpid(), SIGSTOP);
    return execvp(args[0], args);
}

int sandb_run() {
  pid_t child = fork();

  if (child == 0) {
    return do_child(cmdc, cmdv);
  } else {
    return do_trace(child);
  }
}
 
int main(int argc, char **argv) {

  if(argc < 2) {
    errx(EXIT_FAILURE, "[Usage] : ./fend [-c config] <command [args...]>");
  }
  
  sandb_init(argc-1, argv+1);

  if (1)
    sandb_run();
  

  return EXIT_SUCCESS;
}
