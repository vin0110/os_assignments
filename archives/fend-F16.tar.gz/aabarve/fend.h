/* Copyright [2016] <Amit Barve>
 */
#ifndef FEND_H_
#define FEND_H_

#include<stdio.h>
#include<stdlib.h>
#include<stdarg.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include<errno.h>
#include<error.h>
#include<signal.h>
#include<glob.h>
#include<pwd.h>
#include<fnmatch.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<sys/ptrace.h>
#include<sys/user.h>
#include<sys/reg.h>
#include<asm/unistd_64.h>
#include "./fend_syscalls.h"


#define CHAR_BUFFER_SIZE 4096
#define PATTERN_ARRAY_INIT_SIZE 1024

typedef struct file_permissions {
  int access_bits;
  char *pattern; /* a glob pattern */
} file_permissions;

long get_argument_as_long(int argument_number,
                          pid_t child_pid);

int load_configuration_file(char *file_path);

void run_child(char **command_to_run);

int has_end_of_string(char *buffer, int buffer_size);

int is_access_allowed(char *file_path, int open_mode);

int trace_child(pid_t child_pid);

int get_access_bit(char *filename);

void fend_print(char *format, ...);

#endif  // FEND_H_

