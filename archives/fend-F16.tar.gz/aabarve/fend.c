/* Copyright [2016] <Amit Barve>
   Build fend—a simple sandbox using the ptrace system call.
   This sandbox guards all access to all files by a program.
   If an access is disallowed the program the offending system call
   will return the EACCES error code.

   Invocation:
   fend [-c config] <command> 

   where config is an optional configuration file and command is
   the program the is being sandboxed.

   fend is more restrictive then the OS. It will not permit accesses
   that the OS prohibits.
*/
#include "fend.h"

#define DEBUG  0

file_permissions *sandbox_rules = NULL;
int number_of_sandbox_rules = -1;
int is_last_syscall_blocked = 0;

void run_child(char **command_to_run) {
    fend_print("Child running: %s\n", command_to_run[0]);
    /* first declare that this process will be traced */
    ptrace(PTRACE_TRACEME, 0, NULL, NULL);
    /* Give tracing process a first chance to catch the signal */
    kill(getpid(), SIGSTOP);
    /* Start running the given command with execv */
    execvp(command_to_run[0], command_to_run);
}

void fend_print(char *format, ...) {
    if (DEBUG) {
        char buffer[CHAR_BUFFER_SIZE];
        va_list args;
        va_start(args, format);
        vsnprintf(buffer, sizeof(buffer), format, args);
        fprintf(stderr, "[DEBUG] ");
        fprintf(stderr, "%s", buffer);
    }
}

int binary_to_int(char *binary) {
    /* Assuming its only 3 digits */
    int decimal = 0;
    if (binary[0] == '1') decimal += 4;
    if (binary[1] == '1') decimal += 2;
    if (binary[2] == '1') decimal += 1;
    return decimal;
}

void split_line(char *line, char **access, char **pat) {
    char *first = (char*) malloc (MAX_FILENAME_LEN);
    char *pattern = (char*) malloc (MAX_FILENAME_LEN);
    int first_i = 0;
    int pattern_i = 0;
    char *ptr = line;
    while (*ptr == ' ' || *ptr == '\t')
        ptr++;
    while (*ptr != ' ' && *ptr != '\t' && *ptr != '\n') {
        first[first_i++] = *ptr;
        ptr++;
    }
    while (*ptr == ' ' || *ptr == '\t')
        ptr++;
    while (*ptr != ' ' && *ptr != '\t' && *ptr != '\n') {
        pattern[pattern_i++] = *ptr;
        ptr++;
    }
    first[first_i] = 0;
    pattern[pattern_i] = 0;

    *access = first;
    *pat = pattern;

}

int load_configuration_file(char *filepath) {
    int length = PATTERN_ARRAY_INIT_SIZE;
    sandbox_rules = (file_permissions *)
        malloc (length * sizeof(file_permissions));
    int i = 0;
    FILE *config_file = fopen(filepath, "r");
    char *line = NULL;
    size_t len;
    char *temp;
    while (getline(&line, &len, config_file) >= 1) {
        split_line(line, &temp, &sandbox_rules[i].pattern);
        sandbox_rules[i].access_bits = binary_to_int(temp);
        fend_print("(%d)(%s)\n",
                   sandbox_rules[i].access_bits,
                   sandbox_rules[i].pattern);
        i++;
        if (i >= length) {
            sandbox_rules = (file_permissions *)
                realloc(sandbox_rules,
                        (length + PATTERN_ARRAY_INIT_SIZE)
                        * sizeof(file_permissions));
            if (sandbox_rules != NULL) 
                length += PATTERN_ARRAY_INIT_SIZE;
            else
                return -1;
        }
    }
    free(line);  
    fclose(config_file);
    return i - 1; /* ignore last blank rule */
}

/* Return the access for given file
   access is defined as read,write,execute just like chmod
   000 - 0
   111 - 7
*/
int get_access_bit(char *filename) {
    if (filename == NULL)
        return 7;
    int i;
    int access_bits = 7;
    /* check glob pattern match */
    for (i = 0; i < number_of_sandbox_rules; i++) {
        if (!fnmatch(sandbox_rules[i].pattern, filename, FNM_NOESCAPE)) {
            access_bits = sandbox_rules[i].access_bits;
            fend_print("file: %s matches pattern: %s\n", filename,
                       sandbox_rules[i].pattern);
        }
    }
    fend_print("permissions on file %s are %d\n", filename, access_bits);
    return access_bits;
}

int trace_child(pid_t child_pid) {
    int same_call = 0;
    int status;
    struct user_regs_struct *register_data;
    int syscall_id;
    /* Keep tracing all system calls by child process till it
       terminates or exits */
    while (1) {
        register_data = (struct user_regs_struct *) malloc (
            sizeof(struct user_regs_struct));
        /* wait till child makes a system call and signals us */
        wait(&status);
        /* if child has terminated or exited then we need to break */
        if (WIFEXITED(status)) {
            fend_print("child process with pid %ld, exited with "
                       "exit status: %d \n", child_pid, WEXITSTATUS(status));
            break;
        } else if (WIFSIGNALED(status)) {
            fend_print("child process with pid %ld, exited with "
                       "due to signal number %d\n", WTERMSIG(status));
            break;
        } else if (WIFSTOPPED(status)) {
            /* child stopped due the ptrace signal, do processing here */
            /* first we need to find out which system call made the child to
               stop. we are only processing 'open' system call here */
            ptrace(PTRACE_GETREGS, child_pid, NULL, register_data);
            syscall_id = register_data->orig_rax;
            if (syscall_id > 311) /* we know only 311 sys calls */
                continue;
            if (!same_call) {
                /* every system call is trapped twice */
                /* once on entry and once on exit. process it only once */
                is_last_syscall_blocked = 0;
                syscall_info[syscall_id].handler(child_pid);
                same_call = 1;
            } else {
                if (is_last_syscall_blocked) {
                    register_data->rax = -EACCES;
                    ptrace(PTRACE_SETREGS, child_pid, NULL, register_data);
                }
                same_call = 0;
            }
        }
        ptrace(PTRACE_SYSCALL, child_pid, NULL, NULL);
        free(register_data);
    }
    return 0;
}

char* get_default_config_file() {
    /*
      check for .fendrc in current dir or in home dir
      exit if not found.
    */
    char *config_path = (char*) malloc (CHAR_BUFFER_SIZE);
    strncpy(config_path, "./.fendrc", sizeof("./.fendrc"));
    config_path[sizeof("./.fendrc")] = '\0';
    // check for ./.fendrc or ~/.fendrc if none is found exit.
    if (access(config_path, F_OK) != -1)
        return config_path;
    fend_print("Couldn't get file at: %s\n", config_path);
    char *home_dir = getenv("HOME");
    strncpy(config_path, home_dir, CHAR_BUFFER_SIZE);
    strncat(config_path, "/.fendrc", sizeof("./fendrc"));
    if (access(config_path, F_OK) != -1)
        return config_path;
    printf("Must provide a config file.\n");
    exit(0);
}

int main(int argc, char **argv) {
    char *config_file_path = NULL;
    char **command_to_run = NULL;
    pid_t child_pid;

    if (strcmp(argv[1], "-c") != 0) {
        /* look for default config file */
        config_file_path = get_default_config_file();
        command_to_run = argv + 1;
    } else {
        config_file_path = argv[2];
        command_to_run = argv + 3;
    }

    number_of_sandbox_rules = load_configuration_file(config_file_path);
    fend_print("loaded %d rules from :%s\n", 
               number_of_sandbox_rules, config_file_path);

    /* create a child to run given command */
    child_pid = fork();
    if (child_pid == 0) { /* inside child */
        run_child(command_to_run);
    } else if (child_pid > 0) { /* inside parent */
        trace_child(child_pid);
    } else {
        fend_print("fork() call failed. Exiting.\n");
    }

    return 0;
}
