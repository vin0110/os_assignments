#include "fend_syscalls.h"

/* Copyright 2016 <Amit Barv>
   This file contains system call handlers for most of the
   system calls which do file I/O.
   This is not exhaustive list
*/

fend_syscall_info syscall_info[] = {
    {"read", 0, 3, fend_syscall_read_handler},
    {"write", 1, 3, fend_syscall_write_handler},
    {"open", 2, 3, fend_syscall_open_handler},
    {"close", 3, 1, fend_syscall_close_handler},
    {"stat", 4, 2, fend_syscall_stat_handler},
    {"fstat", 5, 2, fend_syscall_fstat_handler},
    {"lstat", 6, 2, fend_syscall_lstat_handler},
    {"poll", 7, 3, fend_syscall_poll_handler},
    {"lseek", 8, 3, fend_syscall_lseek_handler},
    {"mmap", 9, 6, fend_syscall_mmap_handler},
    {"mprotect", 10, 3, fend_syscall_mprotect_handler},
    {"munmap", 11, 1, fend_syscall_munmap_handler},
    {"brk", 12, 1, fend_syscall_brk_handler},
    {"rt_sigaction", 13, 3, fend_syscall_rt_sigaction_handler},
    {"rt_sigprocmask", 14, 3, fend_syscall_rt_sigprocmask_handler},
    {"sigreturn", 15, 1, fend_syscall_sigreturn_handler},
    {"ioctl", 16, 3, fend_syscall_ioctl_handler},
    {"pread64", 17, 4, fend_syscall_pread64_handler},
    {"pwrite64", 18, 4, fend_syscall_pwrite64_handler},
    {"readv", 19, 3, fend_syscall_readv_handler},
    {"writev", 20, 3, fend_syscall_writev_handler},
    {"access", 21, 2, fend_syscall_access_handler},
    {"pipe", 22, 1, fend_syscall_pipe_handler},
    {"select", 23, 5, fend_syscall_select_handler},
    {"sched_yield", 24, 0, fend_syscall_sched_yield_handler},
    {"mremap", 25, 5, fend_syscall_mremap_handler},
    {"msync", 26, 3, fend_syscall_msync_handler},
    {"mincore", 27, 3, fend_syscall_mincore_handler},
    {"madvise", 28, 3, fend_syscall_madvise_handler},
    {"shmget", 29, 3, fend_syscall_shmget_handler},
    {"shmat", 30, 3, fend_syscall_shmat_handler},
    {"shmctl", 31, 3, fend_syscall_shmctl_handler},
    {"dup", 32, 2, fend_syscall_dup_handler},
    {"dup2", 33, 2, fend_syscall_dup2_handler},
    {"pause", 34, 0, fend_syscall_pause_handler},
    {"nanosleep", 35, 2, fend_syscall_nanosleep_handler},
    {"getitimer", 36, 2, fend_syscall_getitimer_handler},
    {"alarm", 37, 1, fend_syscall_alarm_handler},
    {"setitimer", 38, 3, fend_syscall_setitimer_handler},
    {"getpid", 39, 0, fend_syscall_getpid_handler},
    {"sendfile", 40, 4, fend_syscall_sendfile_handler},
    {"socketcall", 41, 2, fend_syscall_socketcall_handler},
    {"connect", 42, 3, fend_syscall_connect_handler},
    {"accept", 43, 3, fend_syscall_accept_handler},
    {"sendto", 44, 6, fend_syscall_sendto_handler},
    {"recvfrom", 45, 6, fend_syscall_recvfrom_handler},
    {"sendmsg", 46, 3, fend_syscall_sendmsg_handler},
    {"recvmsg", 47, 3, fend_syscall_recvmsg_handler},
    {"shutdown", 48, 2, fend_syscall_shutdown_handler},
    {"bind", 49, 3, fend_syscall_bind_handler},
    {"listen", 50, 2, fend_syscall_listen_handler},
    {"getsockname", 51, 3, fend_syscall_getsockname_handler},
    {"getpeername", 52, 3, fend_syscall_getpeername_handler},
    {"socketpair", 53, 4, fend_syscall_socketpair_handler},
    {"setsockopt", 54, 5, fend_syscall_setsockopt_handler},
    {"getsockopt", 55, 5, fend_syscall_getsockopt_handler},
    {"clone", 56, 4, fend_syscall_clone_handler},
    {"fork", 57, 0, fend_syscall_fork_handler},
    {"vfork", 58, 0, fend_syscall_vfork_handler},
    {"execve", 59, 3, fend_syscall_execve_handler},
    {"exit", 60, 1, fend_syscall_exit_handler},
    {"wait4", 61, 4, fend_syscall_wait4_handler},
    {"kill", 62, 2, fend_syscall_kill_handler},
    {"uname", 63, 1, fend_syscall_uname_handler},
    {"semget", 64, 3, fend_syscall_semget_handler},
    {"semop", 65, 3, fend_syscall_semop_handler},
    {"semctl", 66, 4, fend_syscall_semctl_handler},
    {"shmdt", 67, 1, fend_syscall_shmdt_handler},
    {"msgget", 68, 2, fend_syscall_msgget_handler},
    {"msgsnd", 69, 4, fend_syscall_msgsnd_handler},
    {"msgrcv", 70, 5, fend_syscall_msgrcv_handler},
    {"msgctl", 71, 3, fend_syscall_msgctl_handler},
    {"fcntl", 72, 3, fend_syscall_fcntl_handler},
    {"flock", 73, 2, fend_syscall_flock_handler},
    {"fsync", 74, 1, fend_syscall_fsync_handler},
    {"fdatasync", 75, 1, fend_syscall_fdatasync_handler},
    {"truncate", 76, 2, fend_syscall_truncate_handler},
    {"ftruncate", 77, 2, fend_syscall_ftruncate_handler},
    {"getdents", 78, 3, fend_syscall_getdents_handler},
    {"getcwd", 79, 2, fend_syscall_getcwd_handler},
    {"chdir", 80, 1, fend_syscall_chdir_handler},
    {"fchdir", 81, 1, fend_syscall_fchdir_handler},
    {"rename", 82, 2, fend_syscall_rename_handler},
    {"mkdir", 83, 2, fend_syscall_mkdir_handler},
    {"rmdir", 84, 1, fend_syscall_rmdir_handler},
    {"creat", 85, 2, fend_syscall_creat_handler},
    {"link", 86, 2, fend_syscall_link_handler},
    {"unlink", 87, 1, fend_syscall_unlink_handler},
    {"symlink", 88, 2, fend_syscall_symlink_handler},
    {"readlink", 89, 3, fend_syscall_readlink_handler},
    {"chmod", 90, 2, fend_syscall_chmod_handler},
    {"fchmod", 91, 2, fend_syscall_fchmod_handler},
    {"chown", 92, 3, fend_syscall_chown_handler},
    {"fchown", 93, 3, fend_syscall_fchown_handler},
    {"lchown", 94, 3, fend_syscall_lchown_handler},
    {"umask", 95, 1, fend_syscall_umask_handler},
    {"gettimeofday", 96, 2, fend_syscall_gettimeofday_handler},
    {"getrlimit", 97, 2, fend_syscall_getrlimit_handler},
    {"getrusage", 98, 2, fend_syscall_getrusage_handler},
    {"sysinfo", 99, 1, fend_syscall_sysinfo_handler},
    {"times", 100, 1, fend_syscall_times_handler},
    {"ptrace", 101, 4, fend_syscall_ptrace_handler},
    {"getuid", 102, 0, fend_syscall_getuid_handler},
    {"syslog", 103, 3, fend_syscall_syslog_handler},
    {"getgid", 104, 0, fend_syscall_getgid_handler},
    {"setuid", 105, 1, fend_syscall_setuid_handler},
    {"setgid", 106, 1, fend_syscall_setgid_handler},
    {"geteuid", 107, 0, fend_syscall_geteuid_handler},
    {"getegid", 108, 0, fend_syscall_getegid_handler},
    {"setpgid", 109, 2, fend_syscall_setpgid_handler},
    {"getppid", 110, 0, fend_syscall_getppid_handler},
    {"getpgrp", 111, 0, fend_syscall_getpgrp_handler},
    {"setsid", 112, 0, fend_syscall_setsid_handler},
    {"setreuid", 113, 2, fend_syscall_setreuid_handler},
    {"setregid", 114, 2, fend_syscall_setregid_handler},
    {"getgroups", 115, 2, fend_syscall_getgroups_handler},
    {"setgroups", 116, 2, fend_syscall_setgroups_handler},
    {"setresuid", 117, 3, fend_syscall_setresuid_handler},
    {"getresuid", 118, 3, fend_syscall_getresuid_handler},
    {"setresgid", 119, 3, fend_syscall_setresgid_handler},
    {"getresgid", 120, 3, fend_syscall_getresgid_handler},
    {"getpgid", 121, 1, fend_syscall_getpgid_handler},
    {"setfsuid", 122, 1, fend_syscall_setfsuid_handler},
    {"setfsgid", 123, 1, fend_syscall_setfsgid_handler},
    {"getsid", 124, 1, fend_syscall_getsid_handler},
    {"capget", 125, 2, fend_syscall_capget_handler},
    {"capset", 126, 2, fend_syscall_capset_handler},
    {"rt_sigpending", 127, 2, fend_syscall_rt_sigpending_handler},
    {"rt_sigtimedwait", 128, 4, fend_syscall_rt_sigtimedwait_handler},
    {"rt_sigqueueinfo", 129, 3, fend_syscall_rt_sigqueueinfo_handler},
    {"rt_sigsuspend", 130, 2, fend_syscall_rt_sigsuspend_handler},
    {"sigaltstack", 131, 2, fend_syscall_sigaltstack_handler},
    {"utime", 132, 2, fend_syscall_utime_handler},
    {"mknod", 133, 3, fend_syscall_mknod_handler},
    {"uselib", 134, 1, fend_syscall_uselib_handler},
    {"personality", 135, 1, fend_syscall_personality_handler},
    {"ustat", 136, 2, fend_syscall_ustat_handler},
    {"statfs", 137, 2, fend_syscall_statfs_handler},
    {"fstatfs", 138, 2, fend_syscall_fstatfs_handler},
    {"sysfs", 139, 3, fend_syscall_sysfs_handler},
    {"getpriority", 140, 2, fend_syscall_getpriority_handler},
    {"setpriority", 141, 3, fend_syscall_setpriority_handler},
    {"sched_setparam", 142, 2, fend_syscall_sched_setparam_handler},
    {"sched_getparam", 143, 2, fend_syscall_sched_getparam_handler},
    {"sched_setscheduler", 144, 3, fend_syscall_sched_setscheduler_handler},
    {"sched_getscheduler", 145, 1, fend_syscall_sched_getscheduler_handler},
    {"sched_get_priority_max", 146, 1, fend_syscall_sched_get_priority_max_handler},
    {"sched_get_priority_min", 147, 1, fend_syscall_sched_get_priority_min_handler},
    {"sched_rr_get_interval", 148, 2, fend_syscall_sched_rr_get_interval_handler},
    {"mlock", 149, 2, fend_syscall_mlock_handler},
    {"munlock", 150, 2, fend_syscall_munlock_handler},
    {"mlockall", 151, 1, fend_syscall_mlockall_handler},
    {"munlockall", 152, 0, fend_syscall_munlockall_handler},
    {"vhangup", 153, 0, fend_syscall_vhangup_handler},
    {"modify_ldt", 154, 3, fend_syscall_modify_ldt_handler},
    {"pivot_root", 155, 2, fend_syscall_pivot_root_handler},
    {"sysctl", 156, 1, fend_syscall_sysctl_handler},
    {"prctl", 157, 5, fend_syscall_prctl_handler},
    {"arch_prctl", 158, 3, fend_syscall_arch_prctl_handler},
    {"adjtimex", 159, 1, fend_syscall_adjtimex_handler},
    {"setrlimit", 160, 2, fend_syscall_setrlimit_handler},
    {"chroot", 161, 1, fend_syscall_chroot_handler},
    {"sync", 162, 0, fend_syscall_sync_handler},
    {"acct", 163, 1, fend_syscall_acct_handler},
    {"settimeofday", 164, 2, fend_syscall_settimeofday_handler},
    {"mount", 165, 5, fend_syscall_mount_handler},
    {"umount2", 166, 2, fend_syscall_umount2_handler},
    {"swapon", 167, 2, fend_syscall_swapon_handler},
    {"swapoff", 168, 1, fend_syscall_swapoff_handler},
    {"reboot", 169, 4, fend_syscall_reboot_handler},
    {"sethostname", 170, 2, fend_syscall_sethostname_handler},
    {"setdomainname", 171, 2, fend_syscall_setdomainname_handler},
    {"iopl", 172, 2, fend_syscall_iopl_handler},
    {"ioperm", 173, 3, fend_syscall_ioperm_handler},
    {"create_module", 174, 1, fend_syscall_create_module_handler},
    {"init_module", 175, 3, fend_syscall_init_module_handler},
    {"delete_module", 176, 2, fend_syscall_delete_module_handler},
    {"get_kernel_syms", 177, 1, fend_syscall_get_kernel_syms_handler},
    {"query_module", 178, 1, fend_syscall_query_module_handler},
    {"quotactl", 179, 4, fend_syscall_quotactl_handler},
    {"nfsservctl", 180, 1, fend_syscall_nfsservctl_handler},
    {"getpmsg", 181, 1, fend_syscall_getpmsg_handler},
    {"putpmsg", 182, 1, fend_syscall_putpmsg_handler},
    {"afs_syscall", 183, 1, fend_syscall_afs_syscall_handler},
    {"tuxcall", 184, 1, fend_syscall_tuxcall_handler},
    {"security", 185, 1, fend_syscall_security_handler},
    {"gettid", 186, 0, fend_syscall_gettid_handler},
    {"readahead", 187, 3, fend_syscall_readahead_handler},
    {"setxattr", 188, 5, fend_syscall_setxattr_handler},
    {"lsetxattr", 189, 5, fend_syscall_lsetxattr_handler},
    {"fsetxattr", 190, 5, fend_syscall_fsetxattr_handler},
    {"getxattr", 191, 4, fend_syscall_getxattr_handler},
    {"lgetxattr", 192, 4, fend_syscall_lgetxattr_handler},
    {"fgetxattr", 193, 4, fend_syscall_fgetxattr_handler},
    {"listxattr", 194, 3, fend_syscall_listxattr_handler},
    {"llistxattr", 195, 3, fend_syscall_llistxattr_handler},
    {"flistxattr", 196, 3, fend_syscall_flistxattr_handler},
    {"removexattr", 197, 2, fend_syscall_removexattr_handler},
    {"lremovexattr", 198, 2, fend_syscall_lremovexattr_handler},
    {"fremovexattr", 199, 2, fend_syscall_fremovexattr_handler},
    {"tkill", 200, 2, fend_syscall_tkill_handler},
    {"time", 201, 1, fend_syscall_time_handler},
    {"futex", 202, 6, fend_syscall_futex_handler},
    {"sched_setaffinity", 203, 3, fend_syscall_sched_setaffinity_handler},
    {"sched_getaffinity", 204, 3, fend_syscall_sched_getaffinity_handler},
    {"set_thread_area", 205, 2, fend_syscall_set_thread_area_handler},
    {"io_setup", 206, 2, fend_syscall_io_setup_handler},
    {"io_destroy", 207, 1, fend_syscall_io_destroy_handler},
    {"io_getevents", 208, 4, fend_syscall_io_getevents_handler},
    {"io_submit", 209, 3, fend_syscall_io_submit_handler},
    {"io_cancel", 210, 3, fend_syscall_io_cancel_handler},
    {"get_thread_area", 211, 2, fend_syscall_get_thread_area_handler},
    {"lookup_dcookie", 212, 3, fend_syscall_lookup_dcookie_handler},
    {"epoll_create", 213, 1, fend_syscall_epoll_create_handler},
    {"epoll_ctl_old", 214, 1, fend_syscall_epoll_ctl_old_handler},
    {"epoll_wait_old", 215, 1, fend_syscall_epoll_wait_old_handler},
    {"remap_file_pages", 216, 5, fend_syscall_remap_file_pages_handler},
    {"getdents64", 217, 3, fend_syscall_getdents64_handler},
    {"set_tid_address", 218, 1, fend_syscall_set_tid_address_handler},
    {"restart_syscall", 219, 0, fend_syscall_restart_syscall_handler},
    {"semtimedop", 220, 4, fend_syscall_semtimedop_handler},
    {"fadvise64", 221, 4, fend_syscall_fadvise64_handler},
    {"timer_create", 222, 3, fend_syscall_timer_create_handler},
    {"timer_settime", 223, 4, fend_syscall_timer_settime_handler},
    {"timer_gettime", 224, 2, fend_syscall_timer_gettime_handler},
    {"timer_getoverrun", 225, 1, fend_syscall_timer_getoverrun_handler},
    {"timer_delete", 226, 1, fend_syscall_timer_delete_handler},
    {"clock_settime", 227, 2, fend_syscall_clock_settime_handler},
    {"clock_gettime", 228, 2, fend_syscall_clock_gettime_handler},
    {"clock_getres", 229, 2, fend_syscall_clock_getres_handler},
    {"clock_nanosleep", 230, 4, fend_syscall_clock_nanosleep_handler},
    {"exit_group", 231, 1, fend_syscall_exit_group_handler},
    {"epoll_wait", 232, 4, fend_syscall_epoll_wait_handler},
    {"epoll_ctl", 233, 4, fend_syscall_epoll_ctl_handler},
    {"tgkill", 234, 3, fend_syscall_tgkill_handler},
    {"utimes", 235, 2, fend_syscall_utimes_handler},
    {"vserver", 236, 1, fend_syscall_vserver_handler},
    {"mbind", 237, 6, fend_syscall_mbind_handler},
    {"set_mempolicy", 238, 3, fend_syscall_set_mempolicy_handler},
    {"get_mempolicy", 239, 5, fend_syscall_get_mempolicy_handler},
    {"mq_open", 240, 4, fend_syscall_mq_open_handler},
    {"mq_unlink", 241, 1, fend_syscall_mq_unlink_handler},
    {"mq_timedsend", 242, 5, fend_syscall_mq_timedsend_handler},
    {"mq_timedreceive", 243, 5, fend_syscall_mq_timedreceive_handler},
    {"mq_notify", 244, 2, fend_syscall_mq_notify_handler},
    {"mq_getsetattr", 245, 3, fend_syscall_mq_getsetattr_handler},
    {"kexec_load", 246, 4, fend_syscall_kexec_load_handler},
    {"waitid", 247, 5, fend_syscall_waitid_handler},
    {"add_key", 248, 4, fend_syscall_add_key_handler},
    {"request_key", 249, 4, fend_syscall_request_key_handler},
    {"keyctl", 250, 5, fend_syscall_keyctl_handler},
    {"ioprio_set", 251, 3, fend_syscall_ioprio_set_handler},
    {"ioprio_get", 252, 2, fend_syscall_ioprio_get_handler},
    {"inotify_init", 253, 0, fend_syscall_inotify_init_handler},
    {"inotify_add_watch", 254, 3, fend_syscall_inotify_add_watch_handler},
    {"inotify_rm_watch", 255, 2, fend_syscall_inotify_rm_watch_handler},
    {"migrate_pages", 256, 4, fend_syscall_migrate_pages_handler},
    {"openat", 257, 4, fend_syscall_openat_handler},
    {"mkdirat", 258, 3, fend_syscall_mkdirat_handler},
    {"mknodat", 259, 4, fend_syscall_mknodat_handler},
    {"fchownat", 260, 5, fend_syscall_fchownat_handler},
    {"futimesat", 261, 3, fend_syscall_futimesat_handler},
    {"newfstatat", 262, 4, fend_syscall_newfstatat_handler},
    {"unlinkat", 263, 3, fend_syscall_unlinkat_handler},
    {"renameat", 264, 4, fend_syscall_renameat_handler},
    {"linkat", 265, 5, fend_syscall_linkat_handler},
    {"symlinkat", 266, 3, fend_syscall_symlinkat_handler},
    {"readlinkat", 267, 4, fend_syscall_readlinkat_handler},
    {"fchmodat", 268, 3, fend_syscall_fchmodat_handler},
    {"faccessat", 269, 3, fend_syscall_faccessat_handler},
    {"pselect6", 270, 6, fend_syscall_pselect6_handler},
    {"ppoll", 271, 5, fend_syscall_ppoll_handler},
    {"unshare", 272, 1, fend_syscall_unshare_handler},
    {"set_robust_list", 273, 2, fend_syscall_set_robust_list_handler},
    {"get_robust_list", 274, 3, fend_syscall_get_robust_list_handler},
    {"splice", 275, 6, fend_syscall_splice_handler},
    {"tee", 276, 4, fend_syscall_tee_handler},
    {"sync_file_range", 277, 4, fend_syscall_sync_file_range_handler},
    {"vmsplice", 278, 4, fend_syscall_vmsplice_handler},
    {"move_pages", 279, 6, fend_syscall_move_pages_handler},
    {"utimensat", 280, 4, fend_syscall_utimensat_handler},
    {"epoll_pwait", 281, 6, fend_syscall_epoll_pwait_handler},
    {"signalfd", 282, 3, fend_syscall_signalfd_handler},
    {"timerfd_create", 283, 2, fend_syscall_timerfd_create_handler},
    {"eventfd", 284, 1, fend_syscall_eventfd_handler},
    {"fallocate", 285, 4, fend_syscall_fallocate_handler},
    {"timerfd_settime", 286, 4, fend_syscall_timerfd_settime_handler},
    {"timerfd_gettime", 287, 2, fend_syscall_timerfd_gettime_handler},
    {"accept4", 288, 4, fend_syscall_accept4_handler},
    {"signalfd4", 289, 4, fend_syscall_signalfd4_handler},
    {"eventfd2", 290, 2, fend_syscall_eventfd2_handler},
    {"epoll_create1", 291, 1, fend_syscall_epoll_create1_handler},
    {"dup3", 292, 3, fend_syscall_dup3_handler},
    {"pipe2", 293, 2, fend_syscall_pipe2_handler},
    {"inotify_init1", 294, 1, fend_syscall_inotify_init1_handler},
    {"preadv", 295, 5, fend_syscall_preadv_handler},
    {"pwritev", 296, 5, fend_syscall_pwritev_handler},
    {"rt_tgsigqueueinfo", 297, 4, fend_syscall_rt_tgsigqueueinfo_handler},
    {"perf_event_open", 298, 5, fend_syscall_perf_event_open_handler},
    {"recvmmsg", 299, 5, fend_syscall_recvmmsg_handler},
    {"fanotify_init", 300, 2, fend_syscall_fanotify_init_handler},
    {"fanotify_mark", 301, 5, fend_syscall_fanotify_mark_handler},
    {"prlimit64", 302, 4, fend_syscall_prlimit64_handler},
    {"name_to_handle_at", 303, 5, fend_syscall_name_to_handle_at_handler},
    {"open_by_handle_at", 304, 5, fend_syscall_open_by_handle_at_handler},
    {"clock_adjtime", 305, 2, fend_syscall_clock_adjtime_handler},
    {"syncfs", 306, 1, fend_syscall_syncfs_handler},
    {"sendmmsg", 307, 4, fend_syscall_sendmmsg_handler},
    {"setns", 308, 2, fend_syscall_setns_handler},
    {"getcpu", 309, 3, fend_syscall_getcpu_handler},
    {"process_vm_readv", 310, 6, fend_syscall_process_vm_readv_handler},
    {"process_vm_writev", 311, 6, fend_syscall_process_vm_writev_handler},
};



/* Utility functions */
int is_absolute_path(char *filename) {
    return filename[0] == '/';
}

int has_end_of_string(char *buffer, int buffer_size) {
    char *ptr = buffer + buffer_size - 1;
    while (*ptr != '\0' && ptr != buffer)
        ptr--;
    if (*ptr != '\0')
        return 0;
    return 1;
}

char* get_argument_as_string(long start_position,
                             pid_t child_pid) {
    char *argument = (char*) malloc (MAX_FILENAME_LEN);
    long word;
    int read_counter = 0;
    while (1) {
        word = ptrace(PTRACE_PEEKDATA, child_pid,
                      start_position + read_counter, NULL);
        if (errno != 0 || read_counter >= MAX_FILENAME_LEN - 1 || word == -1)
            break;
        memcpy(argument + read_counter, &word, sizeof(word));
        read_counter += sizeof(word);
        if (has_end_of_string(argument, read_counter))
            break;
    }
    if (read_counter == 0)
        argument = "NULL";
    else if (read_counter >= MAX_FILENAME_LEN)
        argument = "....";
    else
        argument[read_counter] = '\0';
    return argument;
}

char* get_filename_from_fd(int fd, pid_t child_pid) {
    char *filename = (char*) malloc (MAX_FILENAME_LEN);
    char link[1024];
    snprintf(link, sizeof(link), "/proc/%d/fd/%d", child_pid, fd);
    readlink(link, filename, 1024);
    return filename;
}

char* get_child_curr_working_dir(pid_t child_pid) {
    char *filename = (char*) malloc (MAX_FILENAME_LEN);
    char link[1024];
    snprintf(link, sizeof(link), "/proc/%d/cwd", child_pid);
    readlink(link, filename, 1024);    
    return filename;
}

long get_argument_register (int argument_number,
                            pid_t child_pid,
                            struct user_regs_struct regs) {
    switch (argument_number) {
    case 1: return regs.rdi;
    case 2: return regs.rsi;
    case 3: return regs.rdx;
    case 4: return regs.r10;
    case 5: return regs.r8;
    case 6: return regs.r9;
    default: return -1;
    }
}

/* Sometimes memory location where string should be stored contains
   actual NULL as string */
char* get_canonical_file_path(char *filename) {
    if (filename == NULL || strcmp(filename, "NULL") == 0)
        return NULL;
    char *full_path = (char*) malloc (MAX_FILENAME_LEN);
    realpath(filename, full_path);
    return full_path;
}


char* combine_file_paths(char* path1, char* path2) {
    char *fullpath = (char*) malloc (MAX_FILENAME_LEN);
    if (*path2 == '.')
        path2++;
    snprintf(fullpath, MAX_FILENAME_LEN, "%s/%s", path1, path2);
    return fullpath;
}


/* Function to skip current system call:
   This function will set orig_rax to 35, 35 is nanosleep call.
   So setting orig_rax to 35 will make this call fail due to invalid
   arguments. No need to jump or skip this instruction
*/
void redirect_to_invalid_call(pid_t child_pid,
                              struct user_regs_struct *regs) {
    regs->orig_rax = 35; /* nanosleep() */
}

/*
  This call will set return value to EACCESS. glibc takes care of
  figuring out that return value is negative and does corresponding
  changes to errno and return value.
  This call should be used when skipping a system call
*/
void set_err_data(struct user_regs_struct *regs) {
    regs->rax = -EACCES;
}

/* This call does the job of chaning the call number, sets error data
   and throws an error before skipping the call.
   If any customization is required directly use 'redirect_to_invalid_call'
   and 'set_err_data'.
   Also if you are using this method then make sure you dont use
   PTRACE_SETARGS after this method!!!
*/
void skip_call_with_error(pid_t child_pid,
                          struct user_regs_struct *regs) {
    redirect_to_invalid_call(child_pid, regs);
    ptrace(PTRACE_SETREGS, child_pid, NULL, regs);
    is_last_syscall_blocked = 1;
}


int allow_or_deny_calls(char *filename,
                        int required_permissions,
                        pid_t child_pid) {
    struct user_regs_struct regs;
    int sandbox_permissions = get_access_bit(filename);
    /* Get open call access bits */
    ptrace(PTRACE_GETREGS, child_pid, NULL, &regs);    
    fend_print("for [%s] sandbox permsission are %d, required_permission are %d\n",
               filename, sandbox_permissions, required_permissions);
    /* TODO: Need to check this if condition */
    if ((sandbox_permissions & required_permissions) != required_permissions) {
        skip_call_with_error(child_pid, &regs);
        return -1;
    }
    return 0;
}

/*
  Common functions for getting filename from fd or reading filename
  from memory. Simply call these functions from syscall specific
  handler function.
*/
char* fend_read_syscall_filename_from_fd(pid_t child_pid, int arg_number) {
    int fd;
    char *filename;
    struct user_regs_struct regs;
    ptrace(PTRACE_GETREGS, child_pid, NULL, &regs);
    fd = get_argument_register(arg_number, child_pid, regs);
    if (fd >= 3)
        filename = get_canonical_file_path(get_filename_from_fd(fd, child_pid));
    else
        filename = NULL;
    return filename;
}


/* same as fend_file_name_common but doesn't give cnanonical path */
char* fend_read_syscall_filename(pid_t child_pid, int arg_number) {
    char *filename;
    struct user_regs_struct regs;
    ptrace(PTRACE_GETREGS, child_pid, NULL, &regs);
    long start_location = get_argument_register(arg_number,
                                                child_pid,
                                                regs);
    filename = get_argument_as_string(start_location, child_pid);
    /* filename might not be a full path */
    return filename;
}

/* only use this for those system calls which take full file path */
char* fend_read_syscall_canonical_filename(pid_t child_pid, int arg_number) {
    return get_canonical_file_path(
        fend_read_syscall_filename(child_pid, arg_number));
}


/* A utility function for all '_at_' calls to give filepath */
char* get_effective_at_path(pid_t child_pid,
                            int fd_arg_number,
                            int relative_path_arg_number) {
    char *filename;
    char *relative_dir;
    struct user_regs_struct regs;
    ptrace(PTRACE_GETREGS, child_pid, NULL, &regs);
    int fd = get_argument_register(fd_arg_number, child_pid, regs);
    filename = fend_read_syscall_filename(child_pid, 
                                          relative_path_arg_number);

    if (!is_absolute_path(filename)) {
        if (fd == AT_FDCWD) {
            relative_dir = get_child_curr_working_dir(child_pid);
        } else {
            relative_dir = fend_read_syscall_filename_from_fd(
                child_pid, fd_arg_number);
        }
        if (relative_dir == NULL)
            return NULL; /* probably fd is illegal, return w/o doing anything */
        filename = combine_file_paths(relative_dir, filename);
    }
    return filename;
}

/* Generic call handler: this does the tasks required for most 
   calls, but in special cases write own code in handler functions */
void generic_call_handler(char *syscall_name,
                          char *filename, 
                          int required_permissions,
                          pid_t child_pid) {
    if (filename == NULL)
        return; /* probably fd is illegal, return w/o doing anything */
    int allowed = allow_or_deny_calls(filename, 
                                      required_permissions, child_pid);
    if (allowed == -1) {
        fend_print("[%s] call blocked for file [%s]\n", 
                   syscall_name, filename);
    }

}

char* absolute_path_check(char *filename, pid_t child_pid) {
    if (!is_absolute_path(filename)) {
        /* If filename is an absolute path then don't need to do this 
           get childs working dir stuff */
        char * cwd = get_child_curr_working_dir(child_pid);
        filename = combine_file_paths(cwd, filename);
    }
    return filename;
}

/* Specific function for each system call */
/*  syscall: close */
void fend_syscall_close_handler(pid_t child_pid) {
    /* No need to process anything here, if access was not allowed
       then calling close doesn't make any sense. */
}

/* TODO: check notes of mkdir_handler same case sneeds to be handled
   for open, rm etc */
/*  syscall: open */
void fend_syscall_open_handler(pid_t child_pid) {
    char * filename = fend_read_syscall_canonical_filename(child_pid, 1);
    /* Get open call access bits */
    struct user_regs_struct regs;
    ptrace(PTRACE_GETREGS, child_pid, NULL, &regs);
    int open_flags = get_argument_register(2, child_pid, regs);
    int required_permissions = 0;
    if (open_flags & O_CREAT) {
        required_permissions |= FEND_WRITE;
    } 
    if (open_flags & O_RDWR) {
        required_permissions |= FEND_READ;
        required_permissions |= FEND_WRITE;
    }
/* O_RDONLY needs to be tested differently */
    if ((open_flags & O_ACCMODE) == 0) {
        required_permissions |= FEND_READ;
    }
    if (open_flags & O_WRONLY) {
        required_permissions |= FEND_WRITE;
    }
    generic_call_handler("open", filename,
                         required_permissions, child_pid);
}

/* syscall: read */
void fend_syscall_read_handler(pid_t child_pid) {
    char * filename = fend_read_syscall_filename_from_fd(child_pid, 1);
    generic_call_handler("read", filename, 0, child_pid);
}

/* syscall: write */
void fend_syscall_write_handler(pid_t child_pid) {
    char * filename = fend_read_syscall_filename_from_fd(child_pid, 1);
    generic_call_handler("write", filename, 0, child_pid);
}

/* syscall: stat */
void fend_syscall_stat_handler(pid_t child_pid) {
    /* for some reason stat call is giving seg fault
       I wil check it out later */
}

/* syscall: fstat */
void fend_syscall_fstat_handler(pid_t child_pid) {
    /* Stat calls should always work */
}

/* syscall: lstat */
void fend_syscall_lstat_handler(pid_t child_pid) {
}

/* syscall: poll */
void fend_syscall_poll_handler(pid_t child_pid) {
}

/* syscall: lseek */
void fend_syscall_lseek_handler(pid_t child_pid) {
}

/* syscall: mmap */
void fend_syscall_mmap_handler(pid_t child_pid) {
    char * filename = fend_read_syscall_filename_from_fd(child_pid, 5);
    generic_call_handler("mmap", filename, FEND_WRITE|FEND_READ, child_pid);
}

/* syscall: mprotect */
void fend_syscall_mprotect_handler(pid_t child_pid) {
}

/* syscall: munmap */
void fend_syscall_munmap_handler(pid_t child_pid) {
}

/* syscall: brk */
void fend_syscall_brk_handler(pid_t child_pid) {
}

/* syscall: rt */
void fend_syscall_rt_sigaction_handler(pid_t child_pid) {
}

/* syscall: rt */
void fend_syscall_rt_sigprocmask_handler(pid_t child_pid) {
}

/* syscall: sigreturn */
void fend_syscall_sigreturn_handler(pid_t child_pid) {
}

/* syscall: ioctl */
void fend_syscall_ioctl_handler(pid_t child_pid) {
}

/* syscall: pread64 */
void fend_syscall_pread64_handler(pid_t child_pid) {
}

/* syscall: pwrite64 */
void fend_syscall_pwrite64_handler(pid_t child_pid) {
}

/* syscall: readv */
void fend_syscall_readv_handler(pid_t child_pid) {
}

/* syscall: writev */
void fend_syscall_writev_handler(pid_t child_pid) {
}

/* syscall: access */
void fend_syscall_access_handler(pid_t child_pid) {
    /* access call should always work */
}

/* syscall: pipe */
void fend_syscall_pipe_handler(pid_t child_pid) {
}

/* syscall: select */
void fend_syscall_select_handler(pid_t child_pid) {
}

/* syscall: sched */
void fend_syscall_sched_yield_handler(pid_t child_pid) {
}

/* syscall: mremap */
void fend_syscall_mremap_handler(pid_t child_pid) {
}

/* syscall: msync */
void fend_syscall_msync_handler(pid_t child_pid) {
}

/* syscall: mincore */
void fend_syscall_mincore_handler(pid_t child_pid) {
}

/* syscall: madvise */
void fend_syscall_madvise_handler(pid_t child_pid) {
}

/* syscall: shmget */
void fend_syscall_shmget_handler(pid_t child_pid) {
}

/* syscall: shmat */
void fend_syscall_shmat_handler(pid_t child_pid) {
}

/* syscall: shmctl */
void fend_syscall_shmctl_handler(pid_t child_pid) {
}

/* syscall: dup */
void fend_syscall_dup_handler(pid_t child_pid) {
}

/* syscall: dup2 */
void fend_syscall_dup2_handler(pid_t child_pid) {
}

/* syscall: pause */
void fend_syscall_pause_handler(pid_t child_pid) {
}

/* syscall: nanosleep */
void fend_syscall_nanosleep_handler(pid_t child_pid) {
}

/* syscall: getitimer */
void fend_syscall_getitimer_handler(pid_t child_pid) {
}

/* syscall: alarm */
void fend_syscall_alarm_handler(pid_t child_pid) {
}

/* syscall: setitimer */
void fend_syscall_setitimer_handler(pid_t child_pid) {
}

/* syscall: getpid */
void fend_syscall_getpid_handler(pid_t child_pid) {
}

/* syscall: sendfile */
void fend_syscall_sendfile_handler(pid_t child_pid) {
}

/* syscall: socketcall */
void fend_syscall_socketcall_handler(pid_t child_pid) {
}

/* syscall: connect */
void fend_syscall_connect_handler(pid_t child_pid) {
}

/* syscall: accept */
void fend_syscall_accept_handler(pid_t child_pid) {
}

/* syscall: sendto */
void fend_syscall_sendto_handler(pid_t child_pid) {
}

/* syscall: recvfrom */
void fend_syscall_recvfrom_handler(pid_t child_pid) {
}

/* syscall: sendmsg */
void fend_syscall_sendmsg_handler(pid_t child_pid) {
}

/* syscall: recvmsg */
void fend_syscall_recvmsg_handler(pid_t child_pid) {
}

/* syscall: shutdown */
void fend_syscall_shutdown_handler(pid_t child_pid) {
}

/* syscall: bind */
void fend_syscall_bind_handler(pid_t child_pid) {
}

/* syscall: listen */
void fend_syscall_listen_handler(pid_t child_pid) {
}

/* syscall: getsockname */
void fend_syscall_getsockname_handler(pid_t child_pid) {
}

/* syscall: getpeername */
void fend_syscall_getpeername_handler(pid_t child_pid) {
}

/* syscall: socketpair */
void fend_syscall_socketpair_handler(pid_t child_pid) {
}

/* syscall: setsockopt */
void fend_syscall_setsockopt_handler(pid_t child_pid) {
}

/* syscall: getsockopt */
void fend_syscall_getsockopt_handler(pid_t child_pid) {
}

/* syscall: clone */
void fend_syscall_clone_handler(pid_t child_pid) {
}

/* syscall: fork */
void fend_syscall_fork_handler(pid_t child_pid) {
}

/* syscall: vfork */
void fend_syscall_vfork_handler(pid_t child_pid) {
}

/* syscall: execve */
void fend_syscall_execve_handler(pid_t child_pid) {
    char * filename = fend_read_syscall_canonical_filename(child_pid, 1);
    generic_call_handler("execve", filename, 0, child_pid);
}

/* syscall: exit */
void fend_syscall_exit_handler(pid_t child_pid) {
}

/* syscall: wait4 */
void fend_syscall_wait4_handler(pid_t child_pid) {
}

/* syscall: kill */
void fend_syscall_kill_handler(pid_t child_pid) {
}

/* syscall: uname */
void fend_syscall_uname_handler(pid_t child_pid) {
}

/* syscall: semget */
void fend_syscall_semget_handler(pid_t child_pid) {
}

/* syscall: semop */
void fend_syscall_semop_handler(pid_t child_pid) {
}

/* syscall: semctl */
void fend_syscall_semctl_handler(pid_t child_pid) {
}

/* syscall: shmdt */
void fend_syscall_shmdt_handler(pid_t child_pid) {
}

/* syscall: msgget */
void fend_syscall_msgget_handler(pid_t child_pid) {
}

/* syscall: msgsnd */
void fend_syscall_msgsnd_handler(pid_t child_pid) {
}

/* syscall: msgrcv */
void fend_syscall_msgrcv_handler(pid_t child_pid) {
}

/* syscall: msgctl */
void fend_syscall_msgctl_handler(pid_t child_pid) {
}

/* syscall: fcntl */
void fend_syscall_fcntl_handler(pid_t child_pid) {
}

/* syscall: flock */
void fend_syscall_flock_handler(pid_t child_pid) {
}

/* syscall: fsync */
void fend_syscall_fsync_handler(pid_t child_pid) {
}

/* syscall: fdatasync */
void fend_syscall_fdatasync_handler(pid_t child_pid) {
}

/* syscall: truncate */
void fend_syscall_truncate_handler(pid_t child_pid) {
    char * filename = 
        absolute_path_check(
            fend_read_syscall_filename(child_pid, 1), child_pid);
    generic_call_handler("truncate", filename, FEND_EXEC, child_pid);
}


/* syscall: ftruncate */
void fend_syscall_ftruncate_handler(pid_t child_pid) {
}

/* syscall: getdents */
void fend_syscall_getdents_handler(pid_t child_pid) {
}

/* syscall: getcwd */
void fend_syscall_getcwd_handler(pid_t child_pid) {
}

/* syscall: chdir */
void fend_syscall_chdir_handler(pid_t child_pid) {
}

/* syscall: fchdir */
void fend_syscall_fchdir_handler(pid_t child_pid) {
}

/* syscall: rename */
void fend_syscall_rename_handler(pid_t child_pid) {
    char * filename = fend_read_syscall_canonical_filename(child_pid, 1);
    generic_call_handler("rename", filename, FEND_WRITE, child_pid);
}

/* syscall: mkdir */
/*handling mkdir is bit different. if absolute path is not given
then mkdir will try to create the directory in current working directory
now since we are tracking child we need to get cwd of the child!! so we 
readlink at /proc/<child-pid>cwd to get cwd of child append dir naem to
that and then use that path for further processing. this scenario is true
for all system calls which work without absolute pathnames i.e. which try
to use file/dir in current dir if absolute path is not given */
void fend_syscall_mkdir_handler(pid_t child_pid) {
    char * filename = 
        absolute_path_check(
            fend_read_syscall_filename(child_pid, 1), child_pid);
    generic_call_handler("mkdir", filename, FEND_WRITE, child_pid);
}

/* syscall: rmdir */
void fend_syscall_rmdir_handler(pid_t child_pid) {
    char * filename = 
        absolute_path_check(
            fend_read_syscall_filename(child_pid, 1), child_pid);
    generic_call_handler("rmdir", filename, FEND_WRITE, child_pid);
}

/* syscall: creat */
void fend_syscall_creat_handler(pid_t child_pid) {
    char * filename = 
        absolute_path_check(
            fend_read_syscall_filename(child_pid, 1), child_pid);
    generic_call_handler("creat", filename, FEND_WRITE, child_pid);
}

/* syscall: link */
void fend_syscall_link_handler(pid_t child_pid) {
}

/* syscall: unlink */
void fend_syscall_unlink_handler(pid_t child_pid) {
    char * filename = 
        absolute_path_check(
            fend_read_syscall_filename(child_pid, 1), child_pid);
    generic_call_handler("unlink", filename, FEND_WRITE, child_pid); 
}

/* syscall: symlink */
void fend_syscall_symlink_handler(pid_t child_pid) {
    char * filename = 
        absolute_path_check(
            fend_read_syscall_filename(child_pid, 2), child_pid);
    generic_call_handler("symlink", filename, FEND_WRITE, child_pid); 
}

/* syscall: readlink */
void fend_syscall_readlink_handler(pid_t child_pid) {
}

/* syscall: chmod */
void fend_syscall_chmod_handler(pid_t child_pid) {
    char * filename = 
        absolute_path_check(
            fend_read_syscall_filename(child_pid, 1), child_pid);
    generic_call_handler("chmod", filename, FEND_WRITE, child_pid); 
}

/* syscall: fchmod */
void fend_syscall_fchmod_handler(pid_t child_pid) {
}

/* syscall: chown */
void fend_syscall_chown_handler(pid_t child_pid) {
}

/* syscall: fchown */
void fend_syscall_fchown_handler(pid_t child_pid) {
}

/* syscall: lchown */
void fend_syscall_lchown_handler(pid_t child_pid) {
}

/* syscall: umask */
void fend_syscall_umask_handler(pid_t child_pid) {
}

/* syscall: gettimeofday */
void fend_syscall_gettimeofday_handler(pid_t child_pid) {
}

/* syscall: getrlimit */
void fend_syscall_getrlimit_handler(pid_t child_pid) {
}

/* syscall: getrusage */
void fend_syscall_getrusage_handler(pid_t child_pid) {
}

/* syscall: sysinfo */
void fend_syscall_sysinfo_handler(pid_t child_pid) {
}

/* syscall: times */
void fend_syscall_times_handler(pid_t child_pid) {
}

/* syscall: ptrace */
void fend_syscall_ptrace_handler(pid_t child_pid) {
}

/* syscall: getuid */
void fend_syscall_getuid_handler(pid_t child_pid) {
}

/* syscall: syslog */
void fend_syscall_syslog_handler(pid_t child_pid) {
}

/* syscall: getgid */
void fend_syscall_getgid_handler(pid_t child_pid) {
}

/* syscall: setuid */
void fend_syscall_setuid_handler(pid_t child_pid) {
}

/* syscall: setgid */
void fend_syscall_setgid_handler(pid_t child_pid) {
}

/* syscall: geteuid */
void fend_syscall_geteuid_handler(pid_t child_pid) {
}

/* syscall: getegid */
void fend_syscall_getegid_handler(pid_t child_pid) {
}

/* syscall: setpgid */
void fend_syscall_setpgid_handler(pid_t child_pid) {
}

/* syscall: getppid */
void fend_syscall_getppid_handler(pid_t child_pid) {
}

/* syscall: getpgrp */
void fend_syscall_getpgrp_handler(pid_t child_pid) {
}

/* syscall: setsid */
void fend_syscall_setsid_handler(pid_t child_pid) {
}

/* syscall: setreuid */
void fend_syscall_setreuid_handler(pid_t child_pid) {
}

/* syscall: setregid */
void fend_syscall_setregid_handler(pid_t child_pid) {
}

/* syscall: getgroups */
void fend_syscall_getgroups_handler(pid_t child_pid) {
}

/* syscall: setgroups */
void fend_syscall_setgroups_handler(pid_t child_pid) {
}

/* syscall: setresuid */
void fend_syscall_setresuid_handler(pid_t child_pid) {
}

/* syscall: getresuid */
void fend_syscall_getresuid_handler(pid_t child_pid) {
}

/* syscall: setresgid */
void fend_syscall_setresgid_handler(pid_t child_pid) {
}

/* syscall: getresgid */
void fend_syscall_getresgid_handler(pid_t child_pid) {
}

/* syscall: getpgid */
void fend_syscall_getpgid_handler(pid_t child_pid) {
}

/* syscall: setfsuid */
void fend_syscall_setfsuid_handler(pid_t child_pid) {
}

/* syscall: setfsgid */
void fend_syscall_setfsgid_handler(pid_t child_pid) {
}

/* syscall: getsid */
void fend_syscall_getsid_handler(pid_t child_pid) {
}

/* syscall: capget */
void fend_syscall_capget_handler(pid_t child_pid) {
}

/* syscall: capset */
void fend_syscall_capset_handler(pid_t child_pid) {
}

/* syscall: rt */
void fend_syscall_rt_sigpending_handler(pid_t child_pid) {
}

/* syscall: rt */
void fend_syscall_rt_sigtimedwait_handler(pid_t child_pid) {
}

/* syscall: rt */
void fend_syscall_rt_sigqueueinfo_handler(pid_t child_pid) {
}

/* syscall: rt */
void fend_syscall_rt_sigsuspend_handler(pid_t child_pid) {
}

/* syscall: sigaltstack */
void fend_syscall_sigaltstack_handler(pid_t child_pid) {
}

/* syscall: utime */
void fend_syscall_utime_handler(pid_t child_pid) {
}

/* syscall: mknod */
void fend_syscall_mknod_handler(pid_t child_pid) {
    char * filename = 
        absolute_path_check(
            fend_read_syscall_filename(child_pid, 1), child_pid);
    generic_call_handler("mknod", filename, FEND_WRITE, child_pid); 
}

/* syscall: uselib */
void fend_syscall_uselib_handler(pid_t child_pid) {
}

/* syscall: personality */
void fend_syscall_personality_handler(pid_t child_pid) {
}

/* syscall: ustat */
void fend_syscall_ustat_handler(pid_t child_pid) {
}

/* syscall: statfs */
void fend_syscall_statfs_handler(pid_t child_pid) {
}

/* syscall: fstatfs */
void fend_syscall_fstatfs_handler(pid_t child_pid) {
}

/* syscall: sysfs */
void fend_syscall_sysfs_handler(pid_t child_pid) {
}

/* syscall: getpriority */
void fend_syscall_getpriority_handler(pid_t child_pid) {
}

/* syscall: setpriority */
void fend_syscall_setpriority_handler(pid_t child_pid) {
}

/* syscall: sched */
void fend_syscall_sched_setparam_handler(pid_t child_pid) {
}

/* syscall: sched */
void fend_syscall_sched_getparam_handler(pid_t child_pid) {
}

/* syscall: sched */
void fend_syscall_sched_setscheduler_handler(pid_t child_pid) {
}

/* syscall: sched */
void fend_syscall_sched_getscheduler_handler(pid_t child_pid) {
}

/* syscall: sched */
void fend_syscall_sched_get_priority_max_handler(pid_t child_pid) {
}

/* syscall: sched */
void fend_syscall_sched_get_priority_min_handler(pid_t child_pid) {
}

/* syscall: sched */
void fend_syscall_sched_rr_get_interval_handler(pid_t child_pid) {
}

/* syscall: mlock */
void fend_syscall_mlock_handler(pid_t child_pid) {
}

/* syscall: munlock */
void fend_syscall_munlock_handler(pid_t child_pid) {
}

/* syscall: mlockall */
void fend_syscall_mlockall_handler(pid_t child_pid) {
}

/* syscall: munlockall */
void fend_syscall_munlockall_handler(pid_t child_pid) {
}

/* syscall: vhangup */
void fend_syscall_vhangup_handler(pid_t child_pid) {
}

/* syscall: modify */
void fend_syscall_modify_ldt_handler(pid_t child_pid) {
}

/* syscall: pivot */
void fend_syscall_pivot_root_handler(pid_t child_pid) {
}

/* syscall: sysctl */
void fend_syscall_sysctl_handler(pid_t child_pid) {
}

/* syscall: prctl */
void fend_syscall_prctl_handler(pid_t child_pid) {
}

/* syscall: arch */
void fend_syscall_arch_prctl_handler(pid_t child_pid) {
}

/* syscall: adjtimex */
void fend_syscall_adjtimex_handler(pid_t child_pid) {
}

/* syscall: setrlimit */
void fend_syscall_setrlimit_handler(pid_t child_pid) {
}

/* syscall: chroot */
void fend_syscall_chroot_handler(pid_t child_pid) {
}

/* syscall: sync */
void fend_syscall_sync_handler(pid_t child_pid) {
}

/* syscall: acct */
void fend_syscall_acct_handler(pid_t child_pid) {
}

/* syscall: settimeofday */
void fend_syscall_settimeofday_handler(pid_t child_pid) {
}

/* syscall: mount */
void fend_syscall_mount_handler(pid_t child_pid) {
}

/* syscall: umount2 */
void fend_syscall_umount2_handler(pid_t child_pid) {
}

/* syscall: swapon */
void fend_syscall_swapon_handler(pid_t child_pid) {
}

/* syscall: swapoff */
void fend_syscall_swapoff_handler(pid_t child_pid) {
}

/* syscall: reboot */
void fend_syscall_reboot_handler(pid_t child_pid) {
}

/* syscall: sethostname */
void fend_syscall_sethostname_handler(pid_t child_pid) {
}

/* syscall: setdomainname */
void fend_syscall_setdomainname_handler(pid_t child_pid) {
}

/* syscall: iopl */
void fend_syscall_iopl_handler(pid_t child_pid) {
}

/* syscall: ioperm */
void fend_syscall_ioperm_handler(pid_t child_pid) {
}

/* syscall: create */
void fend_syscall_create_module_handler(pid_t child_pid) {
}

/* syscall: init */
void fend_syscall_init_module_handler(pid_t child_pid) {
}

/* syscall: delete */
void fend_syscall_delete_module_handler(pid_t child_pid) {
}

/* syscall: get */
void fend_syscall_get_kernel_syms_handler(pid_t child_pid) {
}

/* syscall: query */
void fend_syscall_query_module_handler(pid_t child_pid) {
}

/* syscall: quotactl */
void fend_syscall_quotactl_handler(pid_t child_pid) {
}

/* syscall: nfsservctl */
void fend_syscall_nfsservctl_handler(pid_t child_pid) {
}

/* syscall: getpmsg */
void fend_syscall_getpmsg_handler(pid_t child_pid) {
}

/* syscall: putpmsg */
void fend_syscall_putpmsg_handler(pid_t child_pid) {
}

/* syscall: afs */
void fend_syscall_afs_syscall_handler(pid_t child_pid) {
}

/* syscall: tuxcall */
void fend_syscall_tuxcall_handler(pid_t child_pid) {
}

/* syscall: security */
void fend_syscall_security_handler(pid_t child_pid) {
}

/* syscall: gettid */
void fend_syscall_gettid_handler(pid_t child_pid) {
}

/* syscall: readahead */
void fend_syscall_readahead_handler(pid_t child_pid) {
}

/* syscall: setxattr */
void fend_syscall_setxattr_handler(pid_t child_pid) {
}

/* syscall: lsetxattr */
void fend_syscall_lsetxattr_handler(pid_t child_pid) {
}

/* syscall: fsetxattr */
void fend_syscall_fsetxattr_handler(pid_t child_pid) {
}

/* syscall: getxattr */
void fend_syscall_getxattr_handler(pid_t child_pid) {
}

/* syscall: lgetxattr */
void fend_syscall_lgetxattr_handler(pid_t child_pid) {
}

/* syscall: fgetxattr */
void fend_syscall_fgetxattr_handler(pid_t child_pid) {
}

/* syscall: listxattr */
void fend_syscall_listxattr_handler(pid_t child_pid) {
}

/* syscall: llistxattr */
void fend_syscall_llistxattr_handler(pid_t child_pid) {
}

/* syscall: flistxattr */
void fend_syscall_flistxattr_handler(pid_t child_pid) {
}

/* syscall: removexattr */
void fend_syscall_removexattr_handler(pid_t child_pid) {
}

/* syscall: lremovexattr */
void fend_syscall_lremovexattr_handler(pid_t child_pid) {
}

/* syscall: fremovexattr */
void fend_syscall_fremovexattr_handler(pid_t child_pid) {
}

/* syscall: tkill */
void fend_syscall_tkill_handler(pid_t child_pid) {
}

/* syscall: time */
void fend_syscall_time_handler(pid_t child_pid) {
}

/* syscall: futex */
void fend_syscall_futex_handler(pid_t child_pid) {
}

/* syscall: sched */
void fend_syscall_sched_setaffinity_handler(pid_t child_pid) {
}

/* syscall: sched */
void fend_syscall_sched_getaffinity_handler(pid_t child_pid) {
}

/* syscall: set */
void fend_syscall_set_thread_area_handler(pid_t child_pid) {
}

/* syscall: io */
void fend_syscall_io_setup_handler(pid_t child_pid) {
}

/* syscall: io */
void fend_syscall_io_destroy_handler(pid_t child_pid) {
}

/* syscall: io */
void fend_syscall_io_getevents_handler(pid_t child_pid) {
}

/* syscall: io */
void fend_syscall_io_submit_handler(pid_t child_pid) {
}

/* syscall: io */
void fend_syscall_io_cancel_handler(pid_t child_pid) {
}

/* syscall: get */
void fend_syscall_get_thread_area_handler(pid_t child_pid) {
}

/* syscall: lookup */
void fend_syscall_lookup_dcookie_handler(pid_t child_pid) {
}

/* syscall: epoll */
void fend_syscall_epoll_create_handler(pid_t child_pid) {
}

/* syscall: epoll */
void fend_syscall_epoll_ctl_old_handler(pid_t child_pid) {
}

/* syscall: epoll */
void fend_syscall_epoll_wait_old_handler(pid_t child_pid) {
}

/* syscall: remap */
void fend_syscall_remap_file_pages_handler(pid_t child_pid) {
}

/* syscall: getdents64 */
void fend_syscall_getdents64_handler(pid_t child_pid) {
}

/* syscall: set */
void fend_syscall_set_tid_address_handler(pid_t child_pid) {
}

/* syscall: restart */
void fend_syscall_restart_syscall_handler(pid_t child_pid) {
}

/* syscall: semtimedop */
void fend_syscall_semtimedop_handler(pid_t child_pid) {
}

/* syscall: fadvise64 */
void fend_syscall_fadvise64_handler(pid_t child_pid) {
}

/* syscall: timer */
void fend_syscall_timer_create_handler(pid_t child_pid) {
}

/* syscall: timer */
void fend_syscall_timer_settime_handler(pid_t child_pid) {
}

/* syscall: timer */
void fend_syscall_timer_gettime_handler(pid_t child_pid) {
}

/* syscall: timer */
void fend_syscall_timer_getoverrun_handler(pid_t child_pid) {
}

/* syscall: timer */
void fend_syscall_timer_delete_handler(pid_t child_pid) {
}

/* syscall: clock */
void fend_syscall_clock_settime_handler(pid_t child_pid) {
}

/* syscall: clock */
void fend_syscall_clock_gettime_handler(pid_t child_pid) {
}

/* syscall: clock */
void fend_syscall_clock_getres_handler(pid_t child_pid) {
}

/* syscall: clock */
void fend_syscall_clock_nanosleep_handler(pid_t child_pid) {
}

/* syscall: exit */
void fend_syscall_exit_group_handler(pid_t child_pid) {
}

/* syscall: epoll */
void fend_syscall_epoll_wait_handler(pid_t child_pid) {
}

/* syscall: epoll */
void fend_syscall_epoll_ctl_handler(pid_t child_pid) {
}

/* syscall: tgkill */
void fend_syscall_tgkill_handler(pid_t child_pid) {
}

/* syscall: utimes */
void fend_syscall_utimes_handler(pid_t child_pid) {
}

/* syscall: vserver */
void fend_syscall_vserver_handler(pid_t child_pid) {
}

/* syscall: mbind */
void fend_syscall_mbind_handler(pid_t child_pid) {
}

/* syscall: set */
void fend_syscall_set_mempolicy_handler(pid_t child_pid) {
}

/* syscall: get */
void fend_syscall_get_mempolicy_handler(pid_t child_pid) {
}

/* syscall: mq */
void fend_syscall_mq_open_handler(pid_t child_pid) {
}

/* syscall: mq */
void fend_syscall_mq_unlink_handler(pid_t child_pid) {
}

/* syscall: mq */
void fend_syscall_mq_timedsend_handler(pid_t child_pid) {
}

/* syscall: mq */
void fend_syscall_mq_timedreceive_handler(pid_t child_pid) {
}

/* syscall: mq */
void fend_syscall_mq_notify_handler(pid_t child_pid) {
}

/* syscall: mq */
void fend_syscall_mq_getsetattr_handler(pid_t child_pid) {
}

/* syscall: kexec */
void fend_syscall_kexec_load_handler(pid_t child_pid) {
}

/* syscall: waitid */
void fend_syscall_waitid_handler(pid_t child_pid) {
}

/* syscall: add */
void fend_syscall_add_key_handler(pid_t child_pid) {
}

/* syscall: request */
void fend_syscall_request_key_handler(pid_t child_pid) {
}

/* syscall: keyctl */
void fend_syscall_keyctl_handler(pid_t child_pid) {
}

/* syscall: ioprio */
void fend_syscall_ioprio_set_handler(pid_t child_pid) {
}

/* syscall: ioprio */
void fend_syscall_ioprio_get_handler(pid_t child_pid) {
}

/* syscall: inotify */
void fend_syscall_inotify_init_handler(pid_t child_pid) {
}

/* syscall: inotify */
void fend_syscall_inotify_add_watch_handler(pid_t child_pid) {
}

/* syscall: inotify */
void fend_syscall_inotify_rm_watch_handler(pid_t child_pid) {
}

/* syscall: migrate */
void fend_syscall_migrate_pages_handler(pid_t child_pid) {
}

/* syscall: openat */
void fend_syscall_openat_handler(pid_t child_pid) {
    char *filename = get_effective_at_path(child_pid, 1, 2);    
    struct user_regs_struct regs;
    int open_flags;
    int required_permissions = 0;
    ptrace(PTRACE_GETREGS, child_pid, NULL, &regs);
    /* Get openat call access bits */
    open_flags = get_argument_register(3, child_pid, regs);
    if (open_flags & O_CREAT) {
        required_permissions |= FEND_WRITE;
    } 
    if (open_flags & O_RDWR) {
        required_permissions |= FEND_READ;
        required_permissions |= FEND_WRITE;
    }
    if (open_flags & O_RDONLY) {
        required_permissions |= FEND_READ;
    }
    if (open_flags & O_WRONLY) {
        required_permissions |= FEND_WRITE;
    }
    generic_call_handler("openat", filename, required_permissions, child_pid);
    free(filename);
}

/* syscall: mkdirat */
void fend_syscall_mkdirat_handler(pid_t child_pid) {
    char *filename = get_effective_at_path(child_pid, 1, 2);
    generic_call_handler("mkdirat", filename, FEND_WRITE, child_pid);
    free(filename);
}

/* syscall: mknodat */
void fend_syscall_mknodat_handler(pid_t child_pid) {
    char *filename = get_effective_at_path(child_pid, 1, 2);
    generic_call_handler("mknodat", filename, FEND_WRITE, child_pid);
}

/* syscall: fchownat */
void fend_syscall_fchownat_handler(pid_t child_pid) {
}

/* syscall: futimesat */
void fend_syscall_futimesat_handler(pid_t child_pid) {
}

/* syscall: newfstatat */
void fend_syscall_newfstatat_handler(pid_t child_pid) {
}

/* syscall: unlinkat */
void fend_syscall_unlinkat_handler(pid_t child_pid) {
    char *filename = get_effective_at_path(child_pid, 1, 2);
    generic_call_handler("unlinkat", filename, FEND_WRITE, child_pid);
}

/* syscall: renameat */
void fend_syscall_renameat_handler(pid_t child_pid) {
    char *filename = get_effective_at_path(child_pid, 1, 2);
    generic_call_handler("renameat", filename, FEND_WRITE, child_pid);
}

/* syscall: linkat */
void fend_syscall_linkat_handler(pid_t child_pid) {
}

/* syscall: symlinkat */
void fend_syscall_symlinkat_handler(pid_t child_pid) {
}

/* syscall: readlinkat */
void fend_syscall_readlinkat_handler(pid_t child_pid) {
}

/* syscall: fchmodat */
void fend_syscall_fchmodat_handler(pid_t child_pid) {
}

/* syscall: faccessat */
void fend_syscall_faccessat_handler(pid_t child_pid) {
}

/* syscall: pselect6 */
void fend_syscall_pselect6_handler(pid_t child_pid) {
}

/* syscall: ppoll */
void fend_syscall_ppoll_handler(pid_t child_pid) {
}

/* syscall: unshare */
void fend_syscall_unshare_handler(pid_t child_pid) {
}

/* syscall: set */
void fend_syscall_set_robust_list_handler(pid_t child_pid) {
}

/* syscall: get */
void fend_syscall_get_robust_list_handler(pid_t child_pid) {
}

/* syscall: splice */
void fend_syscall_splice_handler(pid_t child_pid) {
}

/* syscall: tee */
void fend_syscall_tee_handler(pid_t child_pid) {
}

/* syscall: sync */
void fend_syscall_sync_file_range_handler(pid_t child_pid) {
}

/* syscall: vmsplice */
void fend_syscall_vmsplice_handler(pid_t child_pid) {
}

/* syscall: move */
void fend_syscall_move_pages_handler(pid_t child_pid) {
}

/* syscall: utimensat */
void fend_syscall_utimensat_handler(pid_t child_pid) {
}

/* syscall: epoll */
void fend_syscall_epoll_pwait_handler(pid_t child_pid) {
}

/* syscall: signalfd */
void fend_syscall_signalfd_handler(pid_t child_pid) {
}

/* syscall: timerfd */
void fend_syscall_timerfd_create_handler(pid_t child_pid) {
}

/* syscall: eventfd */
void fend_syscall_eventfd_handler(pid_t child_pid) {
}

/* syscall: fallocate */
void fend_syscall_fallocate_handler(pid_t child_pid) {
}

/* syscall: timerfd */
void fend_syscall_timerfd_settime_handler(pid_t child_pid) {
}

/* syscall: timerfd */
void fend_syscall_timerfd_gettime_handler(pid_t child_pid) {
}

/* syscall: accept4 */
void fend_syscall_accept4_handler(pid_t child_pid) {
}

/* syscall: signalfd4 */
void fend_syscall_signalfd4_handler(pid_t child_pid) {
}

/* syscall: eventfd2 */
void fend_syscall_eventfd2_handler(pid_t child_pid) {
}

/* syscall: epoll */
void fend_syscall_epoll_create1_handler(pid_t child_pid) {
}

/* syscall: dup3 */
void fend_syscall_dup3_handler(pid_t child_pid) {
}

/* syscall: pipe2 */
void fend_syscall_pipe2_handler(pid_t child_pid) {
}

/* syscall: inotify */
void fend_syscall_inotify_init1_handler(pid_t child_pid) {
}

/* syscall: preadv */
void fend_syscall_preadv_handler(pid_t child_pid) {
}

/* syscall: pwritev */
void fend_syscall_pwritev_handler(pid_t child_pid) {
}

/* syscall: rt */
void fend_syscall_rt_tgsigqueueinfo_handler(pid_t child_pid) {
}

/* syscall: perf */
void fend_syscall_perf_event_open_handler(pid_t child_pid) {
}

/* syscall: recvmmsg */
void fend_syscall_recvmmsg_handler(pid_t child_pid) {
}

/* syscall: fanotify */
void fend_syscall_fanotify_init_handler(pid_t child_pid) {
}

/* syscall: fanotify */
void fend_syscall_fanotify_mark_handler(pid_t child_pid) {
}

/* syscall: prlimit64 */
void fend_syscall_prlimit64_handler(pid_t child_pid) {
}

/* syscall: name */
void fend_syscall_name_to_handle_at_handler(pid_t child_pid) {
}

/* syscall: open */
void fend_syscall_open_by_handle_at_handler(pid_t child_pid) {
}

/* syscall: clock */
void fend_syscall_clock_adjtime_handler(pid_t child_pid) {
}

/* syscall: syncfs */
void fend_syscall_syncfs_handler(pid_t child_pid) {
}

/* syscall: sendmmsg */
void fend_syscall_sendmmsg_handler(pid_t child_pid) {
}

/* syscall: setns */
void fend_syscall_setns_handler(pid_t child_pid) {
}

/* syscall: getcpu */
void fend_syscall_getcpu_handler(pid_t child_pid) {
}

/* syscall: process */
void fend_syscall_process_vm_readv_handler(pid_t child_pid) {
}

/* syscall: process */
void fend_syscall_process_vm_writev_handler(pid_t child_pid) {
}

/* syscall: getrandom */
void fend_syscall_getrandom_handler(pid_t child_pid) {
}

