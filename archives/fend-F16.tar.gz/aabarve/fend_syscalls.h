/* Copyright 2016 <Amit Barve>
   Table for information of all system calls -
   structure contains:
   call name as char[],
   call ID as int,
   number of arguments as int,
   function pointer of a function which will be called to handle that call
*/

#ifndef FEND_SYSCALLS_H_
#define FEND_SYSCALLS_H_

#include<sys/ptrace.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/user.h>
#include<sys/reg.h>
#include<errno.h>
#include<fcntl.h>
#include<libgen.h>
#include<asm/unistd_64.h>
#include "./fend.h"

#define MAX_FILENAME_LEN 1024
#define FEND_READ 4
#define FEND_WRITE 2
#define FEND_EXEC 1

typedef struct fend_syscall_info {
  char *syscall_name;
  int syscall_id;
  int argument_count;
  void (*handler)(pid_t);
}fend_syscall_info;

extern fend_syscall_info syscall_info[];
extern int is_last_syscall_blocked;

/* Utility functions */
int 
is_absolute_path(char *filename);

int 
has_end_of_string(char *buffer, int buffer_size);

char* 
get_argument_as_string(long start_position,
                             pid_t child_pid);

char* 
get_filename_from_fd(int fd, pid_t child_pid);

char* 
get_child_curr_working_dir(pid_t child_pid);

long 
get_argument_register (int argument_number,
                            pid_t child_pid,
                            struct user_regs_struct regs);

char* 
get_canonical_file_path(char *filename);

char*
combine_file_paths(char* path1, char* path2);

void 
redirect_to_invalid_call(pid_t child_pid,
                         struct user_regs_struct *regs);

void 
set_err_data(struct user_regs_struct *regs);

void 
skip_call_with_error(pid_t child_pid,
                     struct user_regs_struct *regs);

int 
allow_or_deny_calls(char *filename,
                    int required_permissions,
                    pid_t child_pid);

/* Function declarations for all system calls */
void fend_syscall_close_handler(pid_t child_pid);

void fend_syscall_open_handler(pid_t child_pid);

void fend_syscall_read_handler(pid_t child_pid);

void fend_syscall_write_handler(pid_t child_pid);

void fend_syscall_stat_handler(pid_t child_pid);

void fend_syscall_fstat_handler(pid_t child_pid);

void fend_syscall_lstat_handler(pid_t child_pid);

void fend_syscall_poll_handler(pid_t child_pid);

void fend_syscall_lseek_handler(pid_t child_pid);

void fend_syscall_mmap_handler(pid_t child_pid);

void fend_syscall_mprotect_handler(pid_t child_pid);

void fend_syscall_munmap_handler(pid_t child_pid);

void fend_syscall_brk_handler(pid_t child_pid);

void fend_syscall_rt_sigaction_handler(pid_t child_pid);

void fend_syscall_rt_sigprocmask_handler(pid_t child_pid);

void fend_syscall_sigreturn_handler(pid_t child_pid);

void fend_syscall_ioctl_handler(pid_t child_pid);

void fend_syscall_pread64_handler(pid_t child_pid);

void fend_syscall_pwrite64_handler(pid_t child_pid);

void fend_syscall_readv_handler(pid_t child_pid);

void fend_syscall_writev_handler(pid_t child_pid);

void fend_syscall_access_handler(pid_t child_pid);

void fend_syscall_pipe_handler(pid_t child_pid);

void fend_syscall_select_handler(pid_t child_pid);

void fend_syscall_sched_yield_handler(pid_t child_pid);

void fend_syscall_mremap_handler(pid_t child_pid);

void fend_syscall_msync_handler(pid_t child_pid);

void fend_syscall_mincore_handler(pid_t child_pid);

void fend_syscall_madvise_handler(pid_t child_pid);

void fend_syscall_shmget_handler(pid_t child_pid);

void fend_syscall_shmat_handler(pid_t child_pid);

void fend_syscall_shmctl_handler(pid_t child_pid);

void fend_syscall_dup_handler(pid_t child_pid);

void fend_syscall_dup2_handler(pid_t child_pid);

void fend_syscall_pause_handler(pid_t child_pid);

void fend_syscall_nanosleep_handler(pid_t child_pid);

void fend_syscall_getitimer_handler(pid_t child_pid);

void fend_syscall_alarm_handler(pid_t child_pid);

void fend_syscall_setitimer_handler(pid_t child_pid);

void fend_syscall_getpid_handler(pid_t child_pid);

void fend_syscall_sendfile_handler(pid_t child_pid);

void fend_syscall_socketcall_handler(pid_t child_pid);

void fend_syscall_connect_handler(pid_t child_pid);

void fend_syscall_accept_handler(pid_t child_pid);

void fend_syscall_sendto_handler(pid_t child_pid);

void fend_syscall_recvfrom_handler(pid_t child_pid);

void fend_syscall_sendmsg_handler(pid_t child_pid);

void fend_syscall_recvmsg_handler(pid_t child_pid);

void fend_syscall_shutdown_handler(pid_t child_pid);

void fend_syscall_bind_handler(pid_t child_pid);

void fend_syscall_listen_handler(pid_t child_pid);

void fend_syscall_getsockname_handler(pid_t child_pid);

void fend_syscall_getpeername_handler(pid_t child_pid);

void fend_syscall_socketpair_handler(pid_t child_pid);

void fend_syscall_setsockopt_handler(pid_t child_pid);

void fend_syscall_getsockopt_handler(pid_t child_pid);

void fend_syscall_clone_handler(pid_t child_pid);

void fend_syscall_fork_handler(pid_t child_pid);

void fend_syscall_vfork_handler(pid_t child_pid);

void fend_syscall_execve_handler(pid_t child_pid);

void fend_syscall_exit_handler(pid_t child_pid);

void fend_syscall_wait4_handler(pid_t child_pid);

void fend_syscall_kill_handler(pid_t child_pid);

void fend_syscall_uname_handler(pid_t child_pid);

void fend_syscall_semget_handler(pid_t child_pid);

void fend_syscall_semop_handler(pid_t child_pid);

void fend_syscall_semctl_handler(pid_t child_pid);

void fend_syscall_shmdt_handler(pid_t child_pid);

void fend_syscall_msgget_handler(pid_t child_pid);

void fend_syscall_msgsnd_handler(pid_t child_pid);

void fend_syscall_msgrcv_handler(pid_t child_pid);

void fend_syscall_msgctl_handler(pid_t child_pid);

void fend_syscall_fcntl_handler(pid_t child_pid);

void fend_syscall_flock_handler(pid_t child_pid);

void fend_syscall_fsync_handler(pid_t child_pid);

void fend_syscall_fdatasync_handler(pid_t child_pid);

void fend_syscall_truncate_handler(pid_t child_pid);

void fend_syscall_ftruncate_handler(pid_t child_pid);

void fend_syscall_getdents_handler(pid_t child_pid);

void fend_syscall_getcwd_handler(pid_t child_pid);

void fend_syscall_chdir_handler(pid_t child_pid);

void fend_syscall_fchdir_handler(pid_t child_pid);

void fend_syscall_rename_handler(pid_t child_pid);

void fend_syscall_mkdir_handler(pid_t child_pid);

void fend_syscall_rmdir_handler(pid_t child_pid);

void fend_syscall_creat_handler(pid_t child_pid);

void fend_syscall_link_handler(pid_t child_pid);

void fend_syscall_unlink_handler(pid_t child_pid);

void fend_syscall_symlink_handler(pid_t child_pid);

void fend_syscall_readlink_handler(pid_t child_pid);

void fend_syscall_chmod_handler(pid_t child_pid);

void fend_syscall_fchmod_handler(pid_t child_pid);

void fend_syscall_chown_handler(pid_t child_pid);

void fend_syscall_fchown_handler(pid_t child_pid);

void fend_syscall_lchown_handler(pid_t child_pid);

void fend_syscall_umask_handler(pid_t child_pid);

void fend_syscall_gettimeofday_handler(pid_t child_pid);

void fend_syscall_getrlimit_handler(pid_t child_pid);

void fend_syscall_getrusage_handler(pid_t child_pid);

void fend_syscall_sysinfo_handler(pid_t child_pid);

void fend_syscall_times_handler(pid_t child_pid);

void fend_syscall_ptrace_handler(pid_t child_pid);

void fend_syscall_getuid_handler(pid_t child_pid);

void fend_syscall_syslog_handler(pid_t child_pid);

void fend_syscall_getgid_handler(pid_t child_pid);

void fend_syscall_setuid_handler(pid_t child_pid);

void fend_syscall_setgid_handler(pid_t child_pid);

void fend_syscall_geteuid_handler(pid_t child_pid);

void fend_syscall_getegid_handler(pid_t child_pid);

void fend_syscall_setpgid_handler(pid_t child_pid);

void fend_syscall_getppid_handler(pid_t child_pid);

void fend_syscall_getpgrp_handler(pid_t child_pid);

void fend_syscall_setsid_handler(pid_t child_pid);

void fend_syscall_setreuid_handler(pid_t child_pid);

void fend_syscall_setregid_handler(pid_t child_pid);

void fend_syscall_getgroups_handler(pid_t child_pid);

void fend_syscall_setgroups_handler(pid_t child_pid);

void fend_syscall_setresuid_handler(pid_t child_pid);

void fend_syscall_getresuid_handler(pid_t child_pid);

void fend_syscall_setresgid_handler(pid_t child_pid);

void fend_syscall_getresgid_handler(pid_t child_pid);

void fend_syscall_getpgid_handler(pid_t child_pid);

void fend_syscall_setfsuid_handler(pid_t child_pid);

void fend_syscall_setfsgid_handler(pid_t child_pid);

void fend_syscall_getsid_handler(pid_t child_pid);

void fend_syscall_capget_handler(pid_t child_pid);

void fend_syscall_capset_handler(pid_t child_pid);

void fend_syscall_rt_sigpending_handler(pid_t child_pid);

void fend_syscall_rt_sigtimedwait_handler(pid_t child_pid);

void fend_syscall_rt_sigqueueinfo_handler(pid_t child_pid);

void fend_syscall_rt_sigsuspend_handler(pid_t child_pid);

void fend_syscall_sigaltstack_handler(pid_t child_pid);

void fend_syscall_utime_handler(pid_t child_pid);

void fend_syscall_mknod_handler(pid_t child_pid);

void fend_syscall_uselib_handler(pid_t child_pid);

void fend_syscall_personality_handler(pid_t child_pid);

void fend_syscall_ustat_handler(pid_t child_pid);

void fend_syscall_statfs_handler(pid_t child_pid);

void fend_syscall_fstatfs_handler(pid_t child_pid);

void fend_syscall_sysfs_handler(pid_t child_pid);

void fend_syscall_getpriority_handler(pid_t child_pid);

void fend_syscall_setpriority_handler(pid_t child_pid);

void fend_syscall_sched_setparam_handler(pid_t child_pid);

void fend_syscall_sched_getparam_handler(pid_t child_pid);

void fend_syscall_sched_setscheduler_handler(pid_t child_pid);

void fend_syscall_sched_getscheduler_handler(pid_t child_pid);

void fend_syscall_sched_get_priority_max_handler(pid_t child_pid);

void fend_syscall_sched_get_priority_min_handler(pid_t child_pid);

void fend_syscall_sched_rr_get_interval_handler(pid_t child_pid);

void fend_syscall_mlock_handler(pid_t child_pid);

void fend_syscall_munlock_handler(pid_t child_pid);

void fend_syscall_mlockall_handler(pid_t child_pid);

void fend_syscall_munlockall_handler(pid_t child_pid);

void fend_syscall_vhangup_handler(pid_t child_pid);

void fend_syscall_modify_ldt_handler(pid_t child_pid);

void fend_syscall_pivot_root_handler(pid_t child_pid);

void fend_syscall_sysctl_handler(pid_t child_pid);

void fend_syscall_prctl_handler(pid_t child_pid);

void fend_syscall_arch_prctl_handler(pid_t child_pid);

void fend_syscall_adjtimex_handler(pid_t child_pid);

void fend_syscall_setrlimit_handler(pid_t child_pid);

void fend_syscall_chroot_handler(pid_t child_pid);

void fend_syscall_sync_handler(pid_t child_pid);

void fend_syscall_acct_handler(pid_t child_pid);

void fend_syscall_settimeofday_handler(pid_t child_pid);

void fend_syscall_mount_handler(pid_t child_pid);

void fend_syscall_umount2_handler(pid_t child_pid);

void fend_syscall_swapon_handler(pid_t child_pid);

void fend_syscall_swapoff_handler(pid_t child_pid);

void fend_syscall_reboot_handler(pid_t child_pid);

void fend_syscall_sethostname_handler(pid_t child_pid);

void fend_syscall_setdomainname_handler(pid_t child_pid);

void fend_syscall_iopl_handler(pid_t child_pid);

void fend_syscall_ioperm_handler(pid_t child_pid);

void fend_syscall_create_module_handler(pid_t child_pid);

void fend_syscall_init_module_handler(pid_t child_pid);

void fend_syscall_delete_module_handler(pid_t child_pid);

void fend_syscall_get_kernel_syms_handler(pid_t child_pid);

void fend_syscall_query_module_handler(pid_t child_pid);

void fend_syscall_quotactl_handler(pid_t child_pid);

void fend_syscall_nfsservctl_handler(pid_t child_pid);

void fend_syscall_getpmsg_handler(pid_t child_pid);

void fend_syscall_putpmsg_handler(pid_t child_pid);

void fend_syscall_afs_syscall_handler(pid_t child_pid);

void fend_syscall_tuxcall_handler(pid_t child_pid);

void fend_syscall_security_handler(pid_t child_pid);

void fend_syscall_gettid_handler(pid_t child_pid);

void fend_syscall_readahead_handler(pid_t child_pid);

void fend_syscall_setxattr_handler(pid_t child_pid);

void fend_syscall_lsetxattr_handler(pid_t child_pid);

void fend_syscall_fsetxattr_handler(pid_t child_pid);

void fend_syscall_getxattr_handler(pid_t child_pid);

void fend_syscall_lgetxattr_handler(pid_t child_pid);

void fend_syscall_fgetxattr_handler(pid_t child_pid);

void fend_syscall_listxattr_handler(pid_t child_pid);

void fend_syscall_llistxattr_handler(pid_t child_pid);

void fend_syscall_flistxattr_handler(pid_t child_pid);

void fend_syscall_removexattr_handler(pid_t child_pid);

void fend_syscall_lremovexattr_handler(pid_t child_pid);

void fend_syscall_fremovexattr_handler(pid_t child_pid);

void fend_syscall_tkill_handler(pid_t child_pid);

void fend_syscall_time_handler(pid_t child_pid);

void fend_syscall_futex_handler(pid_t child_pid);

void fend_syscall_sched_setaffinity_handler(pid_t child_pid);

void fend_syscall_sched_getaffinity_handler(pid_t child_pid);

void fend_syscall_set_thread_area_handler(pid_t child_pid);

void fend_syscall_io_setup_handler(pid_t child_pid);

void fend_syscall_io_destroy_handler(pid_t child_pid);

void fend_syscall_io_getevents_handler(pid_t child_pid);

void fend_syscall_io_submit_handler(pid_t child_pid);

void fend_syscall_io_cancel_handler(pid_t child_pid);

void fend_syscall_get_thread_area_handler(pid_t child_pid);

void fend_syscall_lookup_dcookie_handler(pid_t child_pid);

void fend_syscall_epoll_create_handler(pid_t child_pid);

void fend_syscall_epoll_ctl_old_handler(pid_t child_pid);

void fend_syscall_epoll_wait_old_handler(pid_t child_pid);

void fend_syscall_remap_file_pages_handler(pid_t child_pid);

void fend_syscall_getdents64_handler(pid_t child_pid);

void fend_syscall_set_tid_address_handler(pid_t child_pid);

void fend_syscall_restart_syscall_handler(pid_t child_pid);

void fend_syscall_semtimedop_handler(pid_t child_pid);

void fend_syscall_fadvise64_handler(pid_t child_pid);

void fend_syscall_timer_create_handler(pid_t child_pid);

void fend_syscall_timer_settime_handler(pid_t child_pid);

void fend_syscall_timer_gettime_handler(pid_t child_pid);

void fend_syscall_timer_getoverrun_handler(pid_t child_pid);

void fend_syscall_timer_delete_handler(pid_t child_pid);

void fend_syscall_clock_settime_handler(pid_t child_pid);

void fend_syscall_clock_gettime_handler(pid_t child_pid);

void fend_syscall_clock_getres_handler(pid_t child_pid);

void fend_syscall_clock_nanosleep_handler(pid_t child_pid);

void fend_syscall_exit_group_handler(pid_t child_pid);

void fend_syscall_epoll_wait_handler(pid_t child_pid);

void fend_syscall_epoll_ctl_handler(pid_t child_pid);

void fend_syscall_tgkill_handler(pid_t child_pid);

void fend_syscall_utimes_handler(pid_t child_pid);

void fend_syscall_vserver_handler(pid_t child_pid);

void fend_syscall_mbind_handler(pid_t child_pid);

void fend_syscall_set_mempolicy_handler(pid_t child_pid);

void fend_syscall_get_mempolicy_handler(pid_t child_pid);

void fend_syscall_mq_open_handler(pid_t child_pid);

void fend_syscall_mq_unlink_handler(pid_t child_pid);

void fend_syscall_mq_timedsend_handler(pid_t child_pid);

void fend_syscall_mq_timedreceive_handler(pid_t child_pid);

void fend_syscall_mq_notify_handler(pid_t child_pid);

void fend_syscall_mq_getsetattr_handler(pid_t child_pid);

void fend_syscall_kexec_load_handler(pid_t child_pid);

void fend_syscall_waitid_handler(pid_t child_pid);

void fend_syscall_add_key_handler(pid_t child_pid);

void fend_syscall_request_key_handler(pid_t child_pid);

void fend_syscall_keyctl_handler(pid_t child_pid);

void fend_syscall_ioprio_set_handler(pid_t child_pid);

void fend_syscall_ioprio_get_handler(pid_t child_pid);

void fend_syscall_inotify_init_handler(pid_t child_pid);

void fend_syscall_inotify_add_watch_handler(pid_t child_pid);

void fend_syscall_inotify_rm_watch_handler(pid_t child_pid);

void fend_syscall_migrate_pages_handler(pid_t child_pid);

void fend_syscall_openat_handler(pid_t child_pid);

void fend_syscall_mkdirat_handler(pid_t child_pid);

void fend_syscall_mknodat_handler(pid_t child_pid);

void fend_syscall_fchownat_handler(pid_t child_pid);

void fend_syscall_futimesat_handler(pid_t child_pid);

void fend_syscall_newfstatat_handler(pid_t child_pid);

void fend_syscall_unlinkat_handler(pid_t child_pid);

void fend_syscall_renameat_handler(pid_t child_pid);

void fend_syscall_linkat_handler(pid_t child_pid);

void fend_syscall_symlinkat_handler(pid_t child_pid);

void fend_syscall_readlinkat_handler(pid_t child_pid);

void fend_syscall_fchmodat_handler(pid_t child_pid);

void fend_syscall_faccessat_handler(pid_t child_pid);

void fend_syscall_pselect6_handler(pid_t child_pid);

void fend_syscall_ppoll_handler(pid_t child_pid);

void fend_syscall_unshare_handler(pid_t child_pid);

void fend_syscall_set_robust_list_handler(pid_t child_pid);

void fend_syscall_get_robust_list_handler(pid_t child_pid);

void fend_syscall_splice_handler(pid_t child_pid);

void fend_syscall_tee_handler(pid_t child_pid);

void fend_syscall_sync_file_range_handler(pid_t child_pid);

void fend_syscall_vmsplice_handler(pid_t child_pid);

void fend_syscall_move_pages_handler(pid_t child_pid);

void fend_syscall_utimensat_handler(pid_t child_pid);

void fend_syscall_epoll_pwait_handler(pid_t child_pid);

void fend_syscall_signalfd_handler(pid_t child_pid);

void fend_syscall_timerfd_create_handler(pid_t child_pid);

void fend_syscall_eventfd_handler(pid_t child_pid);

void fend_syscall_fallocate_handler(pid_t child_pid);

void fend_syscall_timerfd_settime_handler(pid_t child_pid);

void fend_syscall_timerfd_gettime_handler(pid_t child_pid);

void fend_syscall_accept4_handler(pid_t child_pid);

void fend_syscall_signalfd4_handler(pid_t child_pid);

void fend_syscall_eventfd2_handler(pid_t child_pid);

void fend_syscall_epoll_create1_handler(pid_t child_pid);

void fend_syscall_dup3_handler(pid_t child_pid);

void fend_syscall_pipe2_handler(pid_t child_pid);

void fend_syscall_inotify_init1_handler(pid_t child_pid);

void fend_syscall_preadv_handler(pid_t child_pid);

void fend_syscall_pwritev_handler(pid_t child_pid);

void fend_syscall_rt_tgsigqueueinfo_handler(pid_t child_pid);

void fend_syscall_perf_event_open_handler(pid_t child_pid);

void fend_syscall_recvmmsg_handler(pid_t child_pid);

void fend_syscall_fanotify_init_handler(pid_t child_pid);

void fend_syscall_fanotify_mark_handler(pid_t child_pid);

void fend_syscall_prlimit64_handler(pid_t child_pid);

void fend_syscall_name_to_handle_at_handler(pid_t child_pid);

void fend_syscall_open_by_handle_at_handler(pid_t child_pid);

void fend_syscall_clock_adjtime_handler(pid_t child_pid);

void fend_syscall_syncfs_handler(pid_t child_pid);

void fend_syscall_sendmmsg_handler(pid_t child_pid);

void fend_syscall_setns_handler(pid_t child_pid);

void fend_syscall_getcpu_handler(pid_t child_pid);

void fend_syscall_process_vm_readv_handler(pid_t child_pid);

void fend_syscall_process_vm_writev_handler(pid_t child_pid);

void fend_syscall_getrandom_handler(pid_t child_pid);


#endif  // FEND_SYSCALLS_H_

