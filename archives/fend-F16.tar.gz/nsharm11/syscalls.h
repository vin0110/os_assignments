// The part of code is inspired by https://github.com/nelhage/ministrace
#define SYSCALL_MAXARGS 6
enum argtype {
    ARG_INT,
    ARG_PTR,
    ARG_STR
};

struct syscall_entry {
    const char *name;
    int nargs;
    int args[SYSCALL_MAXARGS];
};
