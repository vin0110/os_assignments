#include "sandbox.h"
#include "callbacks.h"
#include<unistd.h>
#include<sys/stat.h>
#include<stdio.h>
#include<stdlib.h>

int main(int argc, char **argv)
{
int fd,size;
//char path[FILEPATH_LENGTH];
char * dirpath, filepath[FILEPATH_LENGTH];

char template[] = "/tmp/tmpdir.XXXXXX";
dirpath = mkdtemp (template);
sprintf(filepath,"%s/fileXXXXXX",dirpath);
fd = mkstemp(filepath);

//sprintf(path,"/proc/self/fd/%d",fd);

//size = readlink(path,filepath,FILEPATH_LENGTH);
//if(size<0)
//{
//	return 1;
//}
//filepath[size]='\0';
chmod(filepath,0);
chmod(dirpath,0);

sandbox_init(argc,argv,fd,filepath,dirpath);
for(;;)
{
sandbox_run();
}

chmod(filepath,777);
chmod(dirpath,777);

remove(filepath);
remove(dirpath);
return 0;
}
