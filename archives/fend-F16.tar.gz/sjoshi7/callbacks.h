#ifndef _CALLBACKS_H_
#define _CALLBACKS_H_

#include<sys/user.h>
#include<unistd.h>
#include "sandbox.h"
#define CONFIG_FILE_LINE_LENGTH 1024
#define FILEPATH_LENGTH 4096
#define FILENAME_LENGTH 255

extern void exec_callback(struct sandbox *, struct user_regs_struct);
extern void open_callback(struct sandbox * , struct user_regs_struct);
extern void stat_callback(struct sandbox *, struct user_regs_struct);
extern void fstat_callback(struct sandbox *, struct user_regs_struct);
extern void read_callback(struct sandbox *, struct user_regs_struct);
extern void write_callback(struct sandbox *, struct user_regs_struct);
extern void mkdir_callback(struct sandbox *, struct user_regs_struct);
extern void openat_callback(struct sandbox *, struct user_regs_struct);
extern void fchdir_callback(struct sandbox *, struct user_regs_struct);
extern void unlinkat_callback(struct sandbox *, struct user_regs_struct);
extern void unlink_callback(struct sandbox *, struct user_regs_struct);
extern void creat_callback(struct sandbox *, struct user_regs_struct);

#endif /*_CALLBACKS_H_ */


