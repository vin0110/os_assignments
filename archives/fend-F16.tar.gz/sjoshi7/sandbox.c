#include "sandbox.h"
#include<stdio.h>
#include<asm/unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<err.h>
#include<sys/ptrace.h>
#include<sys/user.h>
#include "callbacks.h"
#include<string.h>
#include<errno.h>
#include<pwd.h>

char config[CONFIG_FILE_LENGTH];
struct sandbox sandb;

struct sandbox_syscall sandbox_syscalls[] = {
  {__NR_execve,          "exec",exec_callback},
  {__NR_read,            "read",read_callback},
  {__NR_write,           "write", write_callback},
  {__NR_exit,            "exit", NULL},
  {__NR_brk,             "break", NULL},
  {__NR_mmap,            "mmap", NULL},
  {__NR_access,          "access", NULL},
  {__NR_open,            "open", open_callback},
  {__NR_openat,          "openat",openat_callback},
  {__NR_fstat,           "fstat", fstat_callback},
  {__NR_stat, 		 "stat", stat_callback},
  {__NR_lstat,           "lstat",stat_callback},
  {__NR_newfstatat,      "newfstatat",open_callback},
  {__NR_rmdir,           "rmdir",mkdir_callback},
  {__NR_mkdir,           "mkdir",mkdir_callback},
  {__NR_close,           "close", NULL},
  {__NR_mprotect,        "mprotect", NULL},
  {__NR_munmap,          "munmpap", NULL},
  {__NR_arch_prctl,      "arch_p", NULL},
  {__NR_exit_group,      "exit_group", NULL},
  {__NR_getdents,        "getdents", NULL},
  {__NR_fchdir,          "fchdir",fchdir_callback},
  {__NR_unlinkat,        "unlinkat",unlinkat_callback},
  {__NR_unlink, 	 "unlink", unlink_callback},
  {__NR_creat, 		 "creat",creat_callback}
};


void  sandbox_init(int argc, char **argv,int fd, char * tfilepath, char * tdirpath)
{
	int argptr=1;

	int x;
        x=getopt(argc,argv,"c:");
        if (x==-1)
        {
                strcpy(config,".fendrc");
        }
        else
        {
                switch(x)
                {
                        case 'c':
                                if(optind<=argc)
                                {
                                strcpy(config,argv[optind-1]);
                                break;
                                }
                        case ':':
                                strcpy(config,argv[optind-1]);
                        case '?':
                                break;
                }
        }
	if(access(config,F_OK)==-1)
	{
		sprintf(config,"%s/.fendrc",getpwuid(getuid())->pw_dir);
		if(access(config,F_OK)==-1)
		{
			err(EXIT_FAILURE,"[SANDBOX] Must provide config file.");
		}
	}


	if(argc==1 || optind==argc)
	{
		exit(EXIT_SUCCESS);
	}

	argptr = optind;
	pid_t childpid;

	childpid = fork();

	if(childpid>=0)
	{	

		if(childpid==0)
		{
			//printf("in child\n");
			if(ptrace(PTRACE_TRACEME,0,NULL,NULL)<0) {
				err(EXIT_FAILURE, "[SANDBOX] Failed to traceme");
			}
			if(execvp(argv[argptr],&argv[argptr])==-1) {
				err(EXIT_FAILURE, "[SANDBOX] Failed to exec");
			}
		}
		else
		{
		
			int status;
			sandb.child = childpid;
			strcpy(sandb.configfile,config);
			sandb.tempfiledesc = fd;
			strcpy(sandb.tempfilepath,tfilepath);
			strcpy(sandb.tempdirpath,tdirpath);
			wait(&status);
			if(WIFEXITED(status))
       			{
                		//printf("After child exited the status is: %d\n", WEXITSTATUS(status));
                		exit(EXIT_SUCCESS);
        		}

			if(WIFSTOPPED(status))
		        {
                	sandbox_handle_syscall();
        		}

		}
	}
	else
	{
		err(EXIT_FAILURE, "[SANDBOX] Failed to fork");
	}
}

void sandbox_run()
{
	int status;
	if(ptrace(PTRACE_SYSCALL, sandb.child, NULL, NULL)<0) {
		err(EXIT_FAILURE, "[SANDBOX] Failed to syscall");
	}

        wait(&status);

	if(WIFEXITED(status))
	{
		//printf("After child exited the status is: %d\n", WEXITSTATUS(status));
		exit(EXIT_SUCCESS);
	}
	
	if(WIFSTOPPED(status))
	{
		//printf("stopped because: %d\n",WSTOPSIG(status));
		sandbox_handle_syscall();
	}
}


void sandbox_handle_syscall()
{
	 struct user_regs_struct regs; 
	 if(ptrace(PTRACE_GETREGS, sandb.child, NULL, &regs)) {
		err(EXIT_FAILURE, "[SANDBOX] Failed to getregs");
	 }

	/*printf("regs.orig_rax = %llu\n",regs.orig_rax);
	printf("regs.rax = %llu\n",regs.rax);
	printf("regs.rdi = %llu\n",regs.rdi);*/
         int i;
                for(i=0;i<25;i++)
                {
                        if(regs.orig_rax==sandbox_syscalls[i].syscall)
                        {
                                //printf("stopped for : %s with number %llu\n",sandbox_syscalls[i].name,regs.orig_rax);
				if(sandbox_syscalls[i].callback != NULL)
				{
					sandbox_syscalls[i].callback(&sandb,regs);
				}
                        }
                }
}

