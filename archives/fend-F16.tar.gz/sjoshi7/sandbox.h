#ifndef _SANDBOX_H_
#define _SANDBOX_H_
#define CONFIG_FILE_LENGTH 1024
#include<unistd.h>

struct sandbox {
pid_t child;
char configfile[CONFIG_FILE_LENGTH];
int tempfiledesc;
char tempfilepath[CONFIG_FILE_LENGTH];
char tempdirpath[CONFIG_FILE_LENGTH];
};

struct sandbox_syscall {
int syscall;
char name[10];
void (*callback)(); 
};


extern void sandbox_init(int argc, char **argv, int fd, char * tfilepath, char * tdirpath);
extern void sandbox_run();
extern void sandbox_handle_syscall();

#endif /*_SANDBOX_H_*/
