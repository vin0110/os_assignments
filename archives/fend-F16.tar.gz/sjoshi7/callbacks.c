#include "callbacks.h"
#include <stdio.h>
#include<sys/user.h>
#include<unistd.h>
#include<string.h>
#include<glob.h>
#include<errno.h>
#include "sandbox.h"
#include<sys/ptrace.h>
#include<stdlib.h>
#include<limits.h>
#include<regex.h>
#include<fcntl.h>
#include<sys/stat.h>

int openee=0,openatee=0, statee=0, fchdiree=0, readee=0, writeee=0, mkdiree=0, unlinkatee=0,fstatee=0, create=0, unlinkee=0;
char filepath[FILEPATH_LENGTH];// parentpath[FILEPATH_LENGTH];
char * get_filepath_from_fd(pid_t , unsigned long long , char *);
void  match_pattern(const char *, char *,char *);
void * readstr(pid_t , unsigned long long,char * , int );
void deny(struct sandbox *sandb, unsigned long long, int  );
void replace(struct sandbox *sandb, unsigned long long, char * );

int flag = 1;
void deny(struct sandbox *sandb, unsigned long long location, int dir)
{
	int i;
	if(dir==1)
	{
		 for(i=0;i<strlen(sandb->tempdirpath);i++)
	         {
                	ptrace(PTRACE_POKEDATA,sandb->child,(location+i),sandb->tempdirpath[i]);
       		 } 

	}
	else
	{
		for(i=0;i<strlen(sandb->tempfilepath);i++)
		{
			ptrace(PTRACE_POKEDATA,sandb->child,(location+i),sandb->tempfilepath[i]);
		}
	}
}

void replace(struct sandbox *sandb, unsigned long long location, char * pathname)
{
        int i;
        for(i=0;i<strlen(pathname);i++)
        {
                ptrace(PTRACE_POKEDATA,sandb->child,(location+i),pathname[i]);
        }
}


void exec_callback(struct sandbox * sandb, struct user_regs_struct regs)
{
	//printf("\t In exec: %llu\n",regs.rsi);
	//printf("\t In exec rdx is: %llu\n", regs.rdx);
        /*char* filename;
        filename = readstr(sandb->child,regs.rsi);
        printf("%s\n",filename);
        char permission[4];
        match_pattern(sandb->configfile,filename,permission);
        if(permission[2]!='1')
        {
                printf("no exec permission\n");
                regs.orig_rax = -1;
                errno = EACCES;
                ptrace(PTRACE_SETREGS,sandb->child,0,&regs);
        }*/
}

void open_callback(struct sandbox * sandb, struct user_regs_struct regs)
{
	//printf("regs.rsi is: %llu\t",regs.rsi);
	if(openee==0)
	{
	memset(filepath,'\0',FILEPATH_LENGTH);
	readstr(sandb->child,regs.rdi,filepath,AT_FDCWD);
	char permission[4];
	//check if file has correct permissions.
	match_pattern(sandb->configfile,filepath,permission);

	if(strcmp(permission,"000")==0 ||(regs.rsi==0 && permission[0]!='1')||((regs.rsi == 2 || regs.rsi==578 || regs.rsi==1090) && (strcmp(permission,"110")!=0 && strcmp(permission,"111")!=0)) || ((regs.rsi==577 || regs.rsi==1089) && permission[1]!='1'))	
	{
		errno = EACCES;
		deny(sandb,regs.rdi,0);
		openee=1;

	}
	}
	else
	{	
		replace(sandb,regs.rdi,filepath);
		openee=0;
	}
}



void openat_callback(struct sandbox * sandb, struct user_regs_struct regs)
{
	if(openatee==0)
	{
	memset(filepath,'\0',FILEPATH_LENGTH);
	//flag=0;
	readstr(sandb->child,regs.rsi,filepath,regs.rdi);
	//flag=1;
	//printf("filepath: %s\n",filepath);
	char permission[4];
	match_pattern(sandb->configfile, filepath, permission);
	 if(strcmp(permission,"000")==0 ||(regs.rsi==0 && permission[0]!='1')||((regs.rsi == 2 || regs.rsi==578 || regs.rsi==1090) && (strcmp(permission,"110")!=0 && strcmp(permission,"111")!=0)) || ((regs.rsi==577 || regs.rsi==1089) && permission[1]!='1'))
        {
                //printf("no open permission\n");
                //regs.orig_rax = 500;
                //regs.rdi=-1;
                errno = EACCES;
		deny(sandb,regs.rsi,0);
		openatee=1;
                //ptrace(PTRACE_SETREGS,sandb->child,0,&regs);
        }
	}
	else
	{
		replace(sandb,regs.rsi,filepath);
		openatee=0;
	}
}

void stat_callback(struct sandbox * sandb, struct user_regs_struct regs) 
{	
	if(statee==0)
	{
        readstr(sandb->child,regs.rdi,filepath,AT_FDCWD);
	char permission[4];
	//Matching only path obtained from call: remove to emulate UNIX
	match_pattern(sandb->configfile,filepath,permission);
	//printf("filepath: %s\n",filepath);
	//printf("perm: %s\n",permission);
	if(permission[0]!='1')
	{
		//printf("perm: %s\n",permission);
		errno=EACCES;
		deny(sandb,regs.rdi,0);
		statee=1;	
	}
	}
	else
	{
		replace(sandb,regs.rdi,filepath);
		statee=0;
	}
}

void fchdir_callback(struct sandbox *sandb, struct user_regs_struct regs)
{
	if(fchdiree==0)
	{
        get_filepath_from_fd(sandb->child,regs.rdi,filepath);
        char permission[4];
        match_pattern(sandb->configfile,filepath,permission);
        if(permission[2]!='1')
        {
        errno = EACCES;
	deny(sandb,regs.rdi,0);
	fchdiree=1;
	}
	}
	else
	{
		replace(sandb,regs.rdi,filepath);
		fchdiree=0;
	}

}
//@todo must reference this!
void *readstr(pid_t pid, unsigned long long location, char * filename,int dirfd)
{
	char path[FILEPATH_LENGTH];
	char buffer[FILEPATH_LENGTH];
	memset(buffer,'\0',FILEPATH_LENGTH);
	int done = 1;
	int len=0,i;
	for (len = 0; len < FILEPATH_LENGTH-sizeof(long)+1 && done!=0; len += sizeof(long))
	{
		long *target = (long*) &buffer[len];
		* target =  ptrace(PTRACE_PEEKTEXT, pid, location, NULL);
		location=location+sizeof(long);
		for (i = len; i < len+sizeof(long); i++)
		{
			if (!buffer[i])
			{
				done = 0;
				break;
			}
		}
	}
	/*if(flag==0)
	{
	printf("buffer: %s\n",buffer);
	}*/
	if(dirfd==AT_FDCWD)
	{
		/*if(flag==0)
		{
		printf("dirfd = AT_FDCWD\n");
		}*/
		realpath(buffer,path);
	}
	else
	{
		/*if(flag==0)
		{
		printf("not current dir, dir is: %d\n",dirfd);
		}*/
		get_filepath_from_fd(pid,dirfd,filename);
		/*if(flag==0)
		{
		printf("%s\n",filename);
		}*/
		strcat(filename,"/");
		strcat(filename,buffer);
		/*if(flag==0)
                {
                printf("%s\n",filename);
                }*/
		return;
		//realpath(path,filename);
		//memset(filename,'\0',FILEPATH_LENGTH);		
	}
	strcpy(filename,path);
}
	


void read_callback(struct sandbox * sandb, struct user_regs_struct regs)
{
	if(readee==0)
	{
	get_filepath_from_fd(sandb->child,regs.rdi,filepath);
	char permission[4];
	match_pattern(sandb->configfile,filepath,permission);
	if(permission[0]!='1')
        {
        errno = EACCES;
	deny(sandb,regs.rdi,0);
	readee=1;
        }
	} 
	else
	{
		replace(sandb,regs.rdi,filepath);
		readee=0;
	}
}

void write_callback(struct sandbox * sandb, struct user_regs_struct regs)
{
	if(writeee==0)
	{
	get_filepath_from_fd(sandb->child,regs.rdi,filepath);
	char permission[4];
	match_pattern(sandb->configfile,filepath,permission);
	if(permission[1]!='1')
	{
	//printf("no write permission\n");
	//regs.orig_rax = 500;
	//regs.rax=-1;
	//regs.rdi=-1;
	errno = EACCES;
	deny(sandb,regs.rdi,0);
	writeee=1;
	//ptrace(PTRACE_SETREGS,sandb->child,0,&regs);
	}
	}
	else
	{
		replace(sandb,regs.rdi,filepath);
		writeee=0;
	}
}


void creat_callback(struct sandbox * sandb, struct user_regs_struct regs)
{
	if(create==0)
        {
        readstr(sandb->child,regs.rdi,filepath,AT_FDCWD);
        char permission[4];
        match_pattern(sandb->configfile,filepath,permission);
	if(strcmp(permission,"000")==0 ||(regs.rsi==256 && (strcmp(permission,"100")!=0)) ||(regs.rsi==128 && strcmp(permission,"010")!=0)||(regs.rsi==64 && strcmp(permission,"001")!=0)||(regs.rsi==320 && strcmp(permission,"101")!=0)||(regs.rsi==384 && strcmp(permission,"110")!=0)||(regs.rsi==192 && strcmp(permission,"011")!=0) || (regs.rsi==448 && strcmp(permission,"111")!=0))
        {
        errno = EACCES;
        deny(sandb,regs.rdi,0);
        create=1;
        }
        }
        else
        {
                replace(sandb,regs.rdi,filepath);
                create=0;
        }

}


void fstat_callback(struct sandbox * sandb, struct user_regs_struct regs)//Same as stat but filename is obtained from filedescriptor
{
	if(fstatee==0)
	{
	get_filepath_from_fd(sandb->child,regs.rdi, filepath);
	char permission[4];

	match_pattern(sandb->configfile,filepath,permission);
	if(permission[2]!='1')
	{
		errno=EACCES;
		deny(sandb,regs.rdi,0);
		fstatee=1;
	}
	}
	else
	{
		replace(sandb,regs.rdi,filepath);
		fstatee=0;
	}	
}

//@todo fstatat

void mkdir_callback(struct sandbox *sandb, struct user_regs_struct regs)
{
	if(mkdiree==0)
	{
	readstr(sandb->child,regs.rdi,filepath,AT_FDCWD);
	char permission[4];

	match_pattern(sandb->configfile,filepath,permission);
	if(permission[2]!='1' || permission[1]!='1')
	{
		errno=EACCES;
		deny(sandb,regs.rdi,0);
		mkdiree=1;
	}
	
	}
	else
	{
		replace(sandb,regs.rdi,filepath);
		mkdiree=0;
	}
} 

void unlinkat_callback(struct sandbox *sandb, struct user_regs_struct regs)
{
	if(unlinkatee==0)
	{
	//flag = 0;
        readstr(sandb->child,regs.rsi,filepath,AT_FDCWD);
	//flag = 1;
	//printf("filepath: %s\n",filepath);
        //memset(parentpath,'\0',FILEPATH_LENGTH);
        char permission[4];
        /*char * str = strdup(filepath);
        char * word=NULL, * next=NULL;
        word = strtok(str,"/");
        next = strtok(NULL,"/");
        if(next!=NULL)
        {
                strcat(parentpath,"/");
                strcat(parentpath,word);
                match_pattern(sandb->configfile,parentpath,permission);
                if(permission[2]!='1')
                {
                        //regs.orig_rax = 500;
                        errno = EACCES;
			deny(sandb,regs.rdi,0);
			unlinkatee=1;
                        //ptrace(PTRACE_SETREGS,sandb->child,0,&regs);
                        return;
                }
        }
        word = next;
        while(word!=NULL)
        {
		next = strtok(NULL,"/");
                if(next==NULL)
                {
                        strcat(parentpath,"/");
			strcat(parentpath,word);
			match_pattern(sandb->configfile,parentpath,permission);
			 if(permission[2]!='1' || permission[1]!='1')
                	 { 
                		//regs.orig_rax = 500;
                		errno = EACCES;
				deny(sandb,regs.rdi,0);
				unlinkatee=1;
                		//ptrace(PTRACE_SETREGS,sandb->child,0,&regs);
                		return;
                	 }

                }
                strcat(parentpath,"/");
                strcat(parentpath,word);
                match_pattern(sandb->configfile,parentpath,permission);
                if(permission[2]!='1')
                {
                //regs.orig_rax = 500;
                errno = EACCES;
		deny(sandb,regs.rdi,0);
		unlinkatee=1;
                //ptrace(PTRACE_SETREGS,sandb->child,0,&regs);
                return;
                }
                word = next;
        }*/
	match_pattern(sandb->configfile, filepath, permission);
	//printf("filepath: %s\n",filepath);
	//printf("permission: %s\n",permission);
	if(permission[2]!='1' || permission[1]!=1)
	{
		errno = EACCES;
		deny(sandb,regs.rsi,0);
		unlinkatee = 1;
		return;
	}
	}
	else
	{
		replace(sandb,regs.rsi,filepath);
		unlinkatee=0;
	}
}

void unlink_callback(struct sandbox *sandb, struct user_regs_struct regs)
{
        if(unlinkee==0)
        {
        readstr(sandb->child,regs.rdi,filepath,AT_FDCWD);
        //memset(parentpath,'\0',FILEPATH_LENGTH);
        char permission[4];
	
	match_pattern(sandb->configfile, filepath, permission);
        if(permission[1]!=1)
        {
                errno = EACCES;
                deny(sandb,regs.rdi,0);
                unlinkatee = 1;
                return;
        }
	}
	else
	{
		replace(sandb,regs.rdi,filepath);
		unlinkee=0;
	}
}


char* get_filepath_from_fd(pid_t pid, unsigned long long fd, char * filepath)
{
	char path[FILEPATH_LENGTH];
        char *basec;
        sprintf(path,"/proc/%u/fd/%llu",pid,fd);
        int size = readlink(path,filepath,FILEPATH_LENGTH);
        filepath[size]='\0';
	return;
}

void  match_pattern(const char * configfile, char * filename, char * permptr)
{	
 	FILE* file = fopen(configfile,"r");
        char s[CONFIG_FILE_LINE_LENGTH];
	strcpy(permptr,"111");
	char backupperm[3];

	if(strcmp(filename,".")==0 || strcmp(filename,"..")==0)
	{
		return;
	}
        while(fgets(s,CONFIG_FILE_LINE_LENGTH,file))
        {
		regex_t regex;
		if(regcomp(&regex,"[.a-zA-Z0-9]",0)){
        		err(EXIT_FAILURE,"[Callbacks] : Regex not compiled.\n");
		}
		if(regexec(&regex,s,0,NULL,0)==REG_NOMATCH)
		{
        	continue;
		}

                char* str=NULL, *saveptr=NULL, *temp=NULL;
                char pattern[FILEPATH_LENGTH];
		char permission[4];

                int i;
                for(i=1,str=s ; i<=2; i++,str=NULL)
                {
                        temp = strtok_r(str, " ", &saveptr);
                        switch(i)
                        {
                                case 1:
                                strncpy(permission,temp,3);
				permission[3]='\0';

                                case 2:
                                strcpy(pattern,temp);
                        }
                }
	
		if(pattern[strlen(pattern)-1]=='\n')
                {
                pattern[strlen(pattern)-1]='\0';
                }
                //printf("pattern is: %s and permission is: %s\n",pattern,permission);
		
		if(strcmp(filename,pattern)==0)
		{
			strcpy(backupperm,permission);
		}
		//backupperm[3]='\0';

                glob_t globbuf;
                globbuf.gl_offs = 1;
                glob(pattern,GLOB_DOOFFS,NULL,&globbuf);
                for(i=1;i<=globbuf.gl_pathc;i++)
                {
                if(strcmp(filename,globbuf.gl_pathv[i])==0 /*|| strstr(globbuf.gl_pathv[i],filename)!=NULL*/)
                {
                        //printf("\t Match found with : %s\n",pattern);
			strncpy(permptr,permission,4);
			//globfree(&globbuf);
			//return;
                }
                }
		//permptr[3]='\0';
		if(globbuf.gl_pathc==0)
		{
			//printf("using backup permission: %s\n",backupperm);
			strcpy(permptr,backupperm);
		}
		permptr[3]='\0';
                globfree(&globbuf);
        }
}



