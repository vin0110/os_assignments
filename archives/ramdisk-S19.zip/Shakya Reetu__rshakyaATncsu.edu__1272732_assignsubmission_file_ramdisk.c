/*
  FUSE: Filesystem in Userspace
  Copyright (C) 2001-2007  Miklos Szeredi <miklos@szeredi.hu>
  This program can be distributed under the terms of the GNU GPL.
  See the file COPYING.
*/

/** @file
 *  ramdisk.c
 */


#define FUSE_USE_VERSION 26

#include <fuse.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <stddef.h>
#include <assert.h>
#include <sys/stat.h>
#include <libgen.h>
#define MAX 512

long int in_memory = 0;
long int unused_mem = 0;
char filename[MAX];
FILE *fp;

typedef struct fsNode {
    char path[MAX];
	char file_type[1]; // "d" for directory, "f" for file
	mode_t mode;
	size_t size;
	uid_t uid;
	gid_t gid;
	struct fsNode *next;
	char *data;
} fsNode;

fsNode* lookup(fsNode *head, const char *path) 
{
	fsNode *p = head;
	while(p != NULL && strcmp(path, p->path) != 0) {
		p = p->next;
	}
	
	if(p != NULL) {
		return p;
	} else {
		return NULL;
	}
}

void addNode(fsNode *head, fsNode *n)
{
	n->next = NULL;
	if (head != NULL) {
		fsNode *p = head;
		while(p->next != NULL) {
			p = p->next;
		}
		p->next = n;
	}
	else {
		head = n;
	}
}

fsNode *head;

static int ramdisk_getattr(const char *path, struct stat *stbuf)
{
	memset(stbuf, 0, sizeof(struct stat));
	fsNode *node = lookup(head, path);
	
	if(node == NULL) {
		return -ENOENT;
	}
	else {
		if(strcmp(node->file_type, "d")) {
			stbuf->st_mode = S_IFDIR | node->mode;
			stbuf->st_nlink = 2;
		}else if(strcmp(node->file_type, "f")) {
			stbuf->st_mode = S_IFREG | node->mode;
			stbuf->st_nlink = 1;
			stbuf->st_size = node->size;
		}
		return 0;
	}
}

static int ramdisk_readdir(const char *path, void *buf, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi)
{
	(void) offset;
	(void) fi;
	filler(buf, ".", NULL, 0);
	filler(buf, "..", NULL, 0);
	
	fsNode *node = head;
	char *nodePath;
	while(node != NULL ) {
		nodePath = (char *)malloc(strlen(node->path));
		strcpy(nodePath, node->path);
		char *parentPath = dirname(nodePath);
		if((strcmp(node->path, path) != 0)
			&& (strcmp(parentPath, node->path) == 0)) {
				strcpy(nodePath, node->path);
				filler(buf, basename(nodePath), NULL, 0);
		}
		node = node->next;
	}
	return 0;
}

static int ramdisk_open(const char *path, struct fuse_file_info *fi)
{
	fsNode *node = lookup(head, path);
	if (node == NULL ) {
		return -ENOENT;
	}
    return 0;
}

static int ramdisk_read(const char *path, char *buf, size_t size, off_t offset, struct fuse_file_info *fi)
{
	size_t len;
	(void) fi;
	fsNode *node = lookup(head, path);
	
	if(node == NULL || strcmp(node->file_type, "d") == 0 ) {
		return -ENOENT;
	}
	
	len = node->size;
	if (len == 0) { 
	    return 0; 
	}
	if (offset < len) {
		if (offset + size > len) {
			size = len - offset;
		}
		memcpy(buf, node->data + offset, size);
	} else {
		size = 0;
	}
	return size;
}

static int ramdisk_write(const char *path, const char *buf,
           size_t size, off_t offset, struct fuse_file_info *fi) 
{
	fsNode *node = head;
	while(node != NULL && strcmp(path, node->path) != 0) {
		node = node->next;
	}
	
	if(node != NULL && size != 0) {
		node->data = (char*)realloc(node->data, size + offset);
		memcpy(node->data + offset, buf, size);
		node->size = offset + size;
		return size;
	} else {
		return -ENOENT;
	}
}

static int ramdisk_opendir(const char *path, struct fuse_file_info *fi)
{
	fsNode *node = lookup(head, path);
	if (node == NULL ) {
		return -ENOENT;
	}
    if(node != NULL && (strcmp(node->file_type, "d") != 0)) {
		return -ENOTDIR;
	}
	return 0;
}

static int ramdisk_mkdir(const char *path, mode_t mode)
{
	if(unused_mem < sizeof(fsNode)) {
		return -ENOSPC;
	}
	
	fsNode *dirNode = (fsNode *)malloc(sizeof(fsNode));
	unused_mem = in_memory - sizeof(fsNode);
	strcpy(dirNode->path, path);
	strcpy(dirNode->file_type, "d");
	dirNode->mode = mode;
	dirNode->size = 0;
	struct fuse_context *fcntx = fuse_get_context();
	dirNode->uid = fcntx->uid;
	dirNode->gid = fcntx->gid;
	dirNode->next = NULL;
	dirNode->data = NULL;
	addNode(head, dirNode);
	return 0;
}

static int ramdisk_rmdir(const char *path)
{
	fsNode *p = head;
	fsNode *prev = p;
	fsNode *curr = NULL;
	fsNode *prev_found = NULL;
	char *cp_path;
	while(p != NULL) {
		cp_path = (char*)malloc(MAX*10);
		strcpy(cp_path, p->path);
		char *dir = dirname(cp_path);
		if(strcmp(p->path, path)) {
			curr = p;
			prev_found = prev;
		} else if (strcmp(dir, path)) {
			return -errno;
		}	
	}
	if (curr != NULL) {
		prev_found->next = curr->next;
		unused_mem += sizeof(fsNode);
		return 0;
	}
	else {
		return -ENOENT;
	}
}

static int ramdisk_unlink(const char* path)
{
	fsNode *node = lookup(head, path);
	fsNode *p = head;
	fsNode *prev = p;
	fsNode *curr = NULL;
	fsNode *prev_found = NULL;
	if (node != NULL) {
		unused_mem = unused_mem + node->size;
		unused_mem += sizeof(node);
	}
	
	while(p != NULL) {
		if(strcmp(p->path, path)) {
			curr = p;
			prev_found = prev;
		} 
		prev = p;
        p = p->next;		
	}
	if (curr != NULL) {
		prev_found->next = curr->next;
		return 0;
	}
	else {
		return -ENOENT;
	}
	
}

static int ramdisk_create(const char * path, mode_t mode, struct fuse_file_info *fi)
{
	if(unused_mem < sizeof(fsNode)) {
		return -ENOSPC;
	}
	
	fsNode *node = (fsNode *)malloc(sizeof(fsNode));
	strcpy(node->path, path);
	strcpy(node->file_type, "f");
	node->mode = mode;
	node->size = 0;
	struct fuse_context *fcntx = fuse_get_context();
	node->uid = fcntx->uid;
	node->gid = fcntx->gid;
	node->next = NULL;
	node->data = NULL;
	addNode(head, node);
	unused_mem = in_memory - sizeof(fsNode);
	return 0;	
}

static int ramdisk_rename( const char *source, const char *dest) 
{
	fsNode *node = lookup(head, source);
	if (node != NULL) {
		strcpy(node->path, dest);
		return 0;
	} else {
		return -ENOENT;
	}
}

static struct fuse_operations ramdisk_oper = {
	.getattr	= ramdisk_getattr,
	.readdir	= ramdisk_readdir,
	.open		= ramdisk_open,
	.read		= ramdisk_read,
	.write      = ramdisk_write,
	.opendir    = ramdisk_opendir,
	.mkdir      = ramdisk_mkdir,
	.rmdir      = ramdisk_rmdir,
	.unlink     = ramdisk_unlink,
	.create     = ramdisk_create,
	.rename     = ramdisk_rename,
	
};

int main(int argc, char *argv[])
{
	if (argc < 3) {
		printf("Few arguments!\n");
		printf("Usage: ramdisk <mount_point> <size in MB>\n");
		return -1;
	} 
	else if (argc > 4) {
		printf("Too many arguments!\n");
	    printf("Usage: ramdisk <mount_point> <size in MB> [<filename>]\n");
		return -1;
	}
	
	in_memory = (long)atol(argv[2]);
	in_memory = in_memory * 1000000;
	unused_mem = in_memory;
	
	// build the file system node
	fsNode *root = (fsNode *)malloc(sizeof(fsNode));
	strcpy(root->path, "/");
	strcpy(root->file_type, "d");
	root->mode = 0777;
	struct fuse_context *fcntx = fuse_get_context();
	root->uid = fcntx->uid;
	root->gid = fcntx->gid;
	root->next = NULL;
	root->data = NULL;
	head = root;
	
	if (argc == 4) {
		//isPersistent = true;
		strcpy(filename, argv[3]);
		fp = fopen(filename, "r");
		fsNode *perNode = (fsNode*)malloc(sizeof(fsNode));
		char fpath[MAX];
		char ftype[1];
		mode_t fmode;
		uid_t fuid;
		gid_t fgid;
		size_t fsize;
		char t[10];
		if (fp != NULL) {
			while(!feof(fp)) {
				fscanf(fp, "%s", fpath);
				if(lookup(head, fpath) != NULL) {
					break;
				}
				
				strcpy(perNode->path, fpath); //path
				fscanf(fp, "%s", ftype);  //type
				strcpy(perNode->file_type, ftype);
				fscanf(fp, "%s", t);  //mode
				fmode = atoi(t);
				perNode->mode = fmode;
				fscanf(fp, "%s", t);  //size
				fsize = atoi(t);
				perNode->size = fsize;
				fscanf(fp, "%s", t);  //uid
				fuid = atoi(t);
				perNode->uid = fuid;
				fscanf(fp, "%s", t); //gid
				fgid = atoi(t);
				perNode->gid = fgid;
				
				if (strcmp(ftype, "d")) { //is a directory
				    perNode->data = NULL;
				} else if(strcmp(ftype, "f")) { //is a file
					perNode->data = (char*)malloc(perNode->size);
					fseek(fp, 1, SEEK_CUR);
					fread(perNode->data, 1, perNode->size, fp);
				}
				
				addNode(head, perNode);
			}
		}
	}
	
	argc = 2;
	return fuse_main(argc, argv, &ramdisk_oper, NULL);
}
